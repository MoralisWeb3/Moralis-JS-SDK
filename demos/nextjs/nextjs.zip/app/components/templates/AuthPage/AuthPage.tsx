import { Authentication } from '../../modules';

const AuthPage = () => {
  return <Authentication />;
};

export default AuthPage;
