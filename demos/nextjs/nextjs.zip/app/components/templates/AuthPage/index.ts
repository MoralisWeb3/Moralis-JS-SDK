export { default as AuthPage } from './AuthPage';
