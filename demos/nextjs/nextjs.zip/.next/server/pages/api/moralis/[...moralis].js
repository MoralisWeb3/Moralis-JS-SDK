"use strict";
(() => {
var exports = {};
exports.id = 128;
exports.ids = [128];
exports.modules = {

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 17115:
/***/ ((module) => {

module.exports = require("@ethersproject/abstract-signer");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 72382:
/***/ ((module) => {

module.exports = require("@ethersproject/base64");

/***/ }),

/***/ 91551:
/***/ ((module) => {

module.exports = require("@ethersproject/basex");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 31642:
/***/ ((module) => {

module.exports = require("@ethersproject/hdnode");

/***/ }),

/***/ 66553:
/***/ ((module) => {

module.exports = require("@ethersproject/json-wallets");

/***/ }),

/***/ 73262:
/***/ ((module) => {

module.exports = require("@ethersproject/keccak256");

/***/ }),

/***/ 61601:
/***/ ((module) => {

module.exports = require("@ethersproject/logger");

/***/ }),

/***/ 95640:
/***/ ((module) => {

module.exports = require("@ethersproject/properties");

/***/ }),

/***/ 90399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 10721:
/***/ ((module) => {

module.exports = require("@ethersproject/random");

/***/ }),

/***/ 60996:
/***/ ((module) => {

module.exports = require("@ethersproject/rlp");

/***/ }),

/***/ 19441:
/***/ ((module) => {

module.exports = require("@ethersproject/sha2");

/***/ }),

/***/ 38518:
/***/ ((module) => {

module.exports = require("@ethersproject/signing-key");

/***/ }),

/***/ 76693:
/***/ ((module) => {

module.exports = require("@ethersproject/solidity");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 10954:
/***/ ((module) => {

module.exports = require("@ethersproject/transactions");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 47152:
/***/ ((module) => {

module.exports = require("@ethersproject/wallet");

/***/ }),

/***/ 73230:
/***/ ((module) => {

module.exports = require("@ethersproject/web");

/***/ }),

/***/ 20896:
/***/ ((module) => {

module.exports = require("@ethersproject/wordlists");

/***/ }),

/***/ 67831:
/***/ ((module) => {

module.exports = require("@solana/web3.js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 57567:
/***/ ((module) => {

module.exports = require("ethereumjs-util");

/***/ }),

/***/ 25502:
/***/ ((module) => {

module.exports = require("eventemitter3");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ }),

/***/ 51358:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _moralisweb3_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(51283);
/* harmony import */ var _moralisweb3_next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_moralisweb3_next__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_moralisweb3_next__WEBPACK_IMPORTED_MODULE_0__.MoralisNextApi)({
    apiKey: process.env.MORALIS_API_KEY || "",
    authentication: {
        domain: "amazing.dapp",
        uri: process.env.NEXTAUTH_URL || "",
        timeout: 120
    }
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [225,283], () => (__webpack_exec__(51358)));
module.exports = __webpack_exports__;

})();