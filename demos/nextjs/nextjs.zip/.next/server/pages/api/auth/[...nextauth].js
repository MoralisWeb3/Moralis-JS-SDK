"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 35604:
/***/ ((module) => {

module.exports = require("@ethersproject/abstract-provider");

/***/ }),

/***/ 17115:
/***/ ((module) => {

module.exports = require("@ethersproject/abstract-signer");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 72382:
/***/ ((module) => {

module.exports = require("@ethersproject/base64");

/***/ }),

/***/ 91551:
/***/ ((module) => {

module.exports = require("@ethersproject/basex");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 31642:
/***/ ((module) => {

module.exports = require("@ethersproject/hdnode");

/***/ }),

/***/ 66553:
/***/ ((module) => {

module.exports = require("@ethersproject/json-wallets");

/***/ }),

/***/ 73262:
/***/ ((module) => {

module.exports = require("@ethersproject/keccak256");

/***/ }),

/***/ 61601:
/***/ ((module) => {

module.exports = require("@ethersproject/logger");

/***/ }),

/***/ 10721:
/***/ ((module) => {

module.exports = require("@ethersproject/random");

/***/ }),

/***/ 60996:
/***/ ((module) => {

module.exports = require("@ethersproject/rlp");

/***/ }),

/***/ 19441:
/***/ ((module) => {

module.exports = require("@ethersproject/sha2");

/***/ }),

/***/ 38518:
/***/ ((module) => {

module.exports = require("@ethersproject/signing-key");

/***/ }),

/***/ 76693:
/***/ ((module) => {

module.exports = require("@ethersproject/solidity");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 47152:
/***/ ((module) => {

module.exports = require("@ethersproject/wallet");

/***/ }),

/***/ 20896:
/***/ ((module) => {

module.exports = require("@ethersproject/wordlists");

/***/ }),

/***/ 50599:
/***/ ((module) => {

module.exports = require("@noble/ed25519");

/***/ }),

/***/ 72933:
/***/ ((module) => {

module.exports = require("@noble/hashes/hmac");

/***/ }),

/***/ 91982:
/***/ ((module) => {

module.exports = require("@noble/hashes/sha256");

/***/ }),

/***/ 33750:
/***/ ((module) => {

module.exports = require("@noble/hashes/sha512");

/***/ }),

/***/ 82725:
/***/ ((module) => {

module.exports = require("@noble/secp256k1");

/***/ }),

/***/ 47362:
/***/ ((module) => {

module.exports = require("@solana/buffer-layout");

/***/ }),

/***/ 39084:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9848:
/***/ ((module) => {

module.exports = require("bech32");

/***/ }),

/***/ 95361:
/***/ ((module) => {

module.exports = require("bigint-buffer");

/***/ }),

/***/ 32961:
/***/ ((module) => {

module.exports = require("bn.js");

/***/ }),

/***/ 36771:
/***/ ((module) => {

module.exports = require("borsh");

/***/ }),

/***/ 30390:
/***/ ((module) => {

module.exports = require("bs58");

/***/ }),

/***/ 60871:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 8447:
/***/ ((module) => {

module.exports = require("bufferutil");

/***/ }),

/***/ 50999:
/***/ ((module) => {

module.exports = require("create-hash");

/***/ }),

/***/ 17003:
/***/ ((module) => {

module.exports = require("ethereum-cryptography/keccak");

/***/ }),

/***/ 8005:
/***/ ((module) => {

module.exports = require("ethereum-cryptography/secp256k1");

/***/ }),

/***/ 25502:
/***/ ((module) => {

module.exports = require("eventemitter3");

/***/ }),

/***/ 71239:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 78306:
/***/ ((module) => {

module.exports = require("jayson/lib/client/browser");

/***/ }),

/***/ 60468:
/***/ ((module) => {

module.exports = require("js-sha3");

/***/ }),

/***/ 74809:
/***/ ((module) => {

module.exports = require("node-fetch");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 60059:
/***/ ((module) => {

module.exports = require("rlp");

/***/ }),

/***/ 67201:
/***/ ((module) => {

module.exports = require("rpc-websockets");

/***/ }),

/***/ 68913:
/***/ ((module) => {

module.exports = require("superstruct");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 67838:
/***/ ((module) => {

module.exports = require("utf-8-validate");

/***/ }),

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 13685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 24404:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 51837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
// EXTERNAL MODULE: ../../packages/next/lib/index.js
var lib = __webpack_require__(51283);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].ts


/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    providers: [
        (0,lib.MoralisNextAuthProvider)()
    ],
    callbacks: {
        async jwt ({ token , user  }) {
            if (user) {
                token.user = user;
            }
            return token;
        },
        async session ({ session , token  }) {
            session.user = token.user;
            return session;
        }
    },
    pages: {
        signIn: "/signin"
    }
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [164,283], () => (__webpack_exec__(51837)));
module.exports = __webpack_exports__;

})();