"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 1541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 7613:
/***/ ((module) => {

module.exports = require("@noble/ed25519");

/***/ }),

/***/ 2933:
/***/ ((module) => {

module.exports = require("@noble/hashes/hmac");

/***/ }),

/***/ 9168:
/***/ ((module) => {

module.exports = require("@noble/hashes/sha256");

/***/ }),

/***/ 3750:
/***/ ((module) => {

module.exports = require("@noble/hashes/sha512");

/***/ }),

/***/ 2725:
/***/ ((module) => {

module.exports = require("@noble/secp256k1");

/***/ }),

/***/ 7362:
/***/ ((module) => {

module.exports = require("@solana/buffer-layout");

/***/ }),

/***/ 9084:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5361:
/***/ ((module) => {

module.exports = require("bigint-buffer");

/***/ }),

/***/ 2961:
/***/ ((module) => {

module.exports = require("bn.js");

/***/ }),

/***/ 6771:
/***/ ((module) => {

module.exports = require("borsh");

/***/ }),

/***/ 390:
/***/ ((module) => {

module.exports = require("bs58");

/***/ }),

/***/ 871:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 999:
/***/ ((module) => {

module.exports = require("create-hash");

/***/ }),

/***/ 7003:
/***/ ((module) => {

module.exports = require("ethereum-cryptography/keccak");

/***/ }),

/***/ 8005:
/***/ ((module) => {

module.exports = require("ethereum-cryptography/secp256k1");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 5502:
/***/ ((module) => {

module.exports = require("eventemitter3");

/***/ }),

/***/ 8306:
/***/ ((module) => {

module.exports = require("jayson/lib/client/browser");

/***/ }),

/***/ 468:
/***/ ((module) => {

module.exports = require("js-sha3");

/***/ }),

/***/ 4809:
/***/ ((module) => {

module.exports = require("node-fetch");

/***/ }),

/***/ 59:
/***/ ((module) => {

module.exports = require("rlp");

/***/ }),

/***/ 7201:
/***/ ((module) => {

module.exports = require("rpc-websockets");

/***/ }),

/***/ 8913:
/***/ ((module) => {

module.exports = require("superstruct");

/***/ }),

/***/ 497:
/***/ ((module) => {

module.exports = require("web3-eth-abi");

/***/ }),

/***/ 4300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 3685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 9297:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth/providers/credentials"
const credentials_namespaceObject = require("next-auth/providers/credentials");
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_namespaceObject);
// EXTERNAL MODULE: ../../packages/moralis/lib/index.js
var lib = __webpack_require__(924);
;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].ts



// For more information on each option (and a full list of options) go to
// https://next-auth.js.org/configuration/options
/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    providers: [
        credentials_default()({
            name: "MoralisAuth",
            credentials: {
                message: {
                    label: "Message",
                    type: "text",
                    placeholder: "0x0"
                },
                signature: {
                    label: "Signature",
                    type: "text",
                    placeholder: "0x0"
                }
            },
            async authorize (credentials) {
                try {
                    const { message , signature  } = credentials;
                    await lib/* default.start */.Z.start({
                        apiKey: process.env.MORALIS_API_KEY
                    });
                    const { address , profileId , expirationTime , uri  } = (await lib/* default.Auth.verify */.Z.Auth.verify({
                        message,
                        signature,
                        network: "evm"
                    })).raw;
                    const nextAuthUrl = process.env.NEXTAUTH_URL;
                    if (uri !== nextAuthUrl) {
                        return null;
                    }
                    const user = {
                        address,
                        profileId,
                        expirationTime,
                        signature
                    };
                    return user;
                } catch (e) {
                    // eslint-disable-next-line no-console
                    console.error(e);
                    return null;
                }
            }
        }), 
    ],
    callbacks: {
        async jwt ({ token , user  }) {
            if (user) {
                token.user = user;
            }
            return token;
        },
        async session ({ session , token  }) {
            session.expires = token.user.expirationTime;
            session.user = token.user;
            return session;
        }
    },
    session: {
        strategy: "jwt"
    },
    pages: {
        signIn: "/signin"
    }
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [146,924], () => (__webpack_exec__(9297)));
module.exports = __webpack_exports__;

})();