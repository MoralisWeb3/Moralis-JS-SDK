"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 17115:
/***/ ((module) => {

module.exports = require("@ethersproject/abstract-signer");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 72382:
/***/ ((module) => {

module.exports = require("@ethersproject/base64");

/***/ }),

/***/ 91551:
/***/ ((module) => {

module.exports = require("@ethersproject/basex");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 31642:
/***/ ((module) => {

module.exports = require("@ethersproject/hdnode");

/***/ }),

/***/ 66553:
/***/ ((module) => {

module.exports = require("@ethersproject/json-wallets");

/***/ }),

/***/ 73262:
/***/ ((module) => {

module.exports = require("@ethersproject/keccak256");

/***/ }),

/***/ 61601:
/***/ ((module) => {

module.exports = require("@ethersproject/logger");

/***/ }),

/***/ 95640:
/***/ ((module) => {

module.exports = require("@ethersproject/properties");

/***/ }),

/***/ 90399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 10721:
/***/ ((module) => {

module.exports = require("@ethersproject/random");

/***/ }),

/***/ 60996:
/***/ ((module) => {

module.exports = require("@ethersproject/rlp");

/***/ }),

/***/ 19441:
/***/ ((module) => {

module.exports = require("@ethersproject/sha2");

/***/ }),

/***/ 38518:
/***/ ((module) => {

module.exports = require("@ethersproject/signing-key");

/***/ }),

/***/ 76693:
/***/ ((module) => {

module.exports = require("@ethersproject/solidity");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 10954:
/***/ ((module) => {

module.exports = require("@ethersproject/transactions");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 47152:
/***/ ((module) => {

module.exports = require("@ethersproject/wallet");

/***/ }),

/***/ 73230:
/***/ ((module) => {

module.exports = require("@ethersproject/web");

/***/ }),

/***/ 20896:
/***/ ((module) => {

module.exports = require("@ethersproject/wordlists");

/***/ }),

/***/ 67831:
/***/ ((module) => {

module.exports = require("@solana/web3.js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 57567:
/***/ ((module) => {

module.exports = require("ethereumjs-util");

/***/ }),

/***/ 25502:
/***/ ((module) => {

module.exports = require("eventemitter3");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ }),

/***/ 51837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
// EXTERNAL MODULE: ../../packages/next/lib/index.js
var lib = __webpack_require__(51283);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].ts


/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    providers: [
        (0,lib.MoralisNextAuthProvider)()
    ],
    callbacks: {
        async jwt ({ token , user  }) {
            if (user) {
                token.user = user;
            }
            return token;
        },
        async session ({ session , token  }) {
            session.user = token.user;
            return session;
        }
    },
    pages: {
        signIn: "/signin"
    }
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [225,283], () => (__webpack_exec__(51837)));
module.exports = __webpack_exports__;

})();