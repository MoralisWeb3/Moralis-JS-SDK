"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 5075:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _app_components_layouts_Default__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83555);
/* harmony import */ var _app_components_elements_Meta__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77069);
/* harmony import */ var _app_components_templates__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91343);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);





const User = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_app_components_layouts_Default__WEBPACK_IMPORTED_MODULE_1__/* .Default */ .g, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_elements_Meta__WEBPACK_IMPORTED_MODULE_2__/* .Meta */ .h, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_templates__WEBPACK_IMPORTED_MODULE_3__/* .UserPage */ .Y, {})
        ]
    });
};
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_4__.getSession)(context);
    if (!session) {
        return {
            redirect: {
                destination: "/signin",
                permanent: false
            }
        };
    }
    return {
        props: {
            session
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);


/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 35604:
/***/ ((module) => {

module.exports = require("@ethersproject/abstract-provider");

/***/ }),

/***/ 17115:
/***/ ((module) => {

module.exports = require("@ethersproject/abstract-signer");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 72382:
/***/ ((module) => {

module.exports = require("@ethersproject/base64");

/***/ }),

/***/ 91551:
/***/ ((module) => {

module.exports = require("@ethersproject/basex");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 31642:
/***/ ((module) => {

module.exports = require("@ethersproject/hdnode");

/***/ }),

/***/ 66553:
/***/ ((module) => {

module.exports = require("@ethersproject/json-wallets");

/***/ }),

/***/ 73262:
/***/ ((module) => {

module.exports = require("@ethersproject/keccak256");

/***/ }),

/***/ 61601:
/***/ ((module) => {

module.exports = require("@ethersproject/logger");

/***/ }),

/***/ 10721:
/***/ ((module) => {

module.exports = require("@ethersproject/random");

/***/ }),

/***/ 60996:
/***/ ((module) => {

module.exports = require("@ethersproject/rlp");

/***/ }),

/***/ 19441:
/***/ ((module) => {

module.exports = require("@ethersproject/sha2");

/***/ }),

/***/ 38518:
/***/ ((module) => {

module.exports = require("@ethersproject/signing-key");

/***/ }),

/***/ 76693:
/***/ ((module) => {

module.exports = require("@ethersproject/solidity");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 47152:
/***/ ((module) => {

module.exports = require("@ethersproject/wallet");

/***/ }),

/***/ 20896:
/***/ ((module) => {

module.exports = require("@ethersproject/wordlists");

/***/ }),

/***/ 50599:
/***/ ((module) => {

module.exports = require("@noble/ed25519");

/***/ }),

/***/ 72933:
/***/ ((module) => {

module.exports = require("@noble/hashes/hmac");

/***/ }),

/***/ 91982:
/***/ ((module) => {

module.exports = require("@noble/hashes/sha256");

/***/ }),

/***/ 33750:
/***/ ((module) => {

module.exports = require("@noble/hashes/sha512");

/***/ }),

/***/ 82725:
/***/ ((module) => {

module.exports = require("@noble/secp256k1");

/***/ }),

/***/ 47362:
/***/ ((module) => {

module.exports = require("@solana/buffer-layout");

/***/ }),

/***/ 39084:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9848:
/***/ ((module) => {

module.exports = require("bech32");

/***/ }),

/***/ 95361:
/***/ ((module) => {

module.exports = require("bigint-buffer");

/***/ }),

/***/ 32961:
/***/ ((module) => {

module.exports = require("bn.js");

/***/ }),

/***/ 36771:
/***/ ((module) => {

module.exports = require("borsh");

/***/ }),

/***/ 30390:
/***/ ((module) => {

module.exports = require("bs58");

/***/ }),

/***/ 60871:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 8447:
/***/ ((module) => {

module.exports = require("bufferutil");

/***/ }),

/***/ 50999:
/***/ ((module) => {

module.exports = require("create-hash");

/***/ }),

/***/ 17003:
/***/ ((module) => {

module.exports = require("ethereum-cryptography/keccak");

/***/ }),

/***/ 8005:
/***/ ((module) => {

module.exports = require("ethereum-cryptography/secp256k1");

/***/ }),

/***/ 25502:
/***/ ((module) => {

module.exports = require("eventemitter3");

/***/ }),

/***/ 71239:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 78306:
/***/ ((module) => {

module.exports = require("jayson/lib/client/browser");

/***/ }),

/***/ 60468:
/***/ ((module) => {

module.exports = require("js-sha3");

/***/ }),

/***/ 41649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 74809:
/***/ ((module) => {

module.exports = require("node-fetch");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 60059:
/***/ ((module) => {

module.exports = require("rlp");

/***/ }),

/***/ 67201:
/***/ ((module) => {

module.exports = require("rpc-websockets");

/***/ }),

/***/ 68913:
/***/ ((module) => {

module.exports = require("superstruct");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 67838:
/***/ ((module) => {

module.exports = require("utf-8-validate");

/***/ }),

/***/ 8906:
/***/ ((module) => {

module.exports = require("wagmi");

/***/ }),

/***/ 74738:
/***/ ((module) => {

module.exports = require("wagmi/connectors/injected");

/***/ }),

/***/ 79035:
/***/ ((module) => {

module.exports = require("wagmi/connectors/metaMask");

/***/ }),

/***/ 61556:
/***/ ((module) => {

module.exports = require("wagmi/connectors/walletConnect");

/***/ }),

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 13685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 24404:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,157,466,555,343], () => (__webpack_exec__(5075)));
module.exports = __webpack_exports__;

})();