"use strict";
exports.id = 924;
exports.ids = [924];
exports.modules = {

/***/ 3296:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisApiUtils = void 0;
var core_1 = __webpack_require__(4243);
var ApiConfigSetup_1 = __webpack_require__(705);
var MoralisApiUtils = /** @class */ (function (_super) {
    __extends(MoralisApiUtils, _super);
    function MoralisApiUtils(core) {
        return _super.call(this, MoralisApiUtils.moduleName, core) || this;
    }
    MoralisApiUtils.create = function (core) {
        return new MoralisApiUtils(core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault());
    };
    MoralisApiUtils.prototype.setup = function () {
        ApiConfigSetup_1.ApiConfigSetup.register(this.core.config);
    };
    MoralisApiUtils.prototype.start = function () {
        // Nothing...
    };
    MoralisApiUtils.moduleName = 'api';
    return MoralisApiUtils;
}(core_1.Module));
exports.MoralisApiUtils = MoralisApiUtils;
//# sourceMappingURL=MoralisApiUtils.js.map

/***/ }),

/***/ 5139:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ApiConfig = void 0;
exports.ApiConfig = {
    apiKey: {
        name: 'apiKey',
        defaultValue: null,
    },
};
//# sourceMappingURL=ApiConfig.js.map

/***/ }),

/***/ 705:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ApiConfigSetup = void 0;
var ApiConfig_1 = __webpack_require__(5139);
var ApiConfigSetup = /** @class */ (function () {
    function ApiConfigSetup() {
    }
    ApiConfigSetup.register = function (config) {
        if (!config.hasKey(ApiConfig_1.ApiConfig.apiKey)) {
            config.registerKey(ApiConfig_1.ApiConfig.apiKey);
        }
    };
    return ApiConfigSetup;
}());
exports.ApiConfigSetup = ApiConfigSetup;
//# sourceMappingURL=ApiConfigSetup.js.map

/***/ }),

/***/ 4217:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(5139), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 3107:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.isNotFoundError = void 0;
var core_1 = __webpack_require__(4243);
function isNotFoundError(e) {
    var _a;
    if ((0, core_1.isMoralisError)(e)) {
        if (((_a = e.details) === null || _a === void 0 ? void 0 : _a.status) === 404) {
            return true;
        }
        if (e.code === core_1.ApiErrorCode.NOT_FOUND) {
            return true;
        }
    }
    return false;
}
exports.isNotFoundError = isNotFoundError;
//# sourceMappingURL=isNotFoundError.js.map

/***/ }),

/***/ 3520:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(4217), exports);
__exportStar(__webpack_require__(3368), exports);
__exportStar(__webpack_require__(8733), exports);
__exportStar(__webpack_require__(3296), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 4870:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ApiPaginatedResultAdapter = void 0;
var core_1 = __webpack_require__(4243);
var ApiResultAdapter_1 = __webpack_require__(8392);
/**
 * The adapter for a paginated API result.
 */
var ApiPaginatedResultAdapter = /** @class */ (function (_super) {
    __extends(ApiPaginatedResultAdapter, _super);
    function ApiPaginatedResultAdapter(data, adapter, jsonAdapter, params, nextHandler) {
        var _this = _super.call(this, data, adapter, jsonAdapter, params) || this;
        _this.nextHandler = nextHandler;
        /**
         * Checks an existence of the next page.
         *
         * @returns `true` if a next page exists, otherwise `false`.
         */
        _this.hasNext = function () {
            return !!_this.nextHandler;
        };
        /**
         * Gets a next page of the paginated result.
         *
         * @returns a new instance of a paginated adapter.
         */
        _this.next = function () {
            if (!_this.nextHandler) {
                throw new core_1.MoralisApiError({
                    code: core_1.ApiErrorCode.PAGE_LIMIT_EXCEEDED,
                    message: 'Page limit exceeded! Before call this method check an existence of the next page by .hasNext() method.',
                });
            }
            return _this.nextHandler();
        };
        return _this;
    }
    Object.defineProperty(ApiPaginatedResultAdapter.prototype, "pagination", {
        /**
         * @returns an info about pagination.
         */
        get: function () {
            return {
                total: this.data.total,
                page: this.data.page,
                pageSize: this.data.page_size,
                cursor: this.data.cursor,
            };
        },
        enumerable: false,
        configurable: true
    });
    return ApiPaginatedResultAdapter;
}(ApiResultAdapter_1.ApiResultAdapter));
exports.ApiPaginatedResultAdapter = ApiPaginatedResultAdapter;
//# sourceMappingURL=ApiPaginatedResultAdapter.js.map

/***/ }),

/***/ 8392:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ApiResultAdapter = exports.ApiFormatType = void 0;
var core_1 = __webpack_require__(4243);
// TODO: make part of core config? The challenge in that case is to make sure it is Typed correctly
var ApiFormatType;
(function (ApiFormatType) {
    // Return the data directly, as is provided by the API
    ApiFormatType["RAW"] = "raw";
    // Return the formatted result of all moralis DataTypes
    ApiFormatType["JSON"] = "JSON";
    // Return class with moralis DataTypes and format functions
    ApiFormatType["NORMAL"] = "normal";
})(ApiFormatType = exports.ApiFormatType || (exports.ApiFormatType = {}));
/**
 * The adapter for the API result.
 */
var ApiResultAdapter = /** @class */ (function () {
    function ApiResultAdapter(data, adapter, jsonAdapter, params) {
        this.data = data;
        this.adapter = adapter;
        this.jsonAdapter = jsonAdapter;
        this.params = params;
    }
    Object.defineProperty(ApiResultAdapter.prototype, "raw", {
        /**
         * @returns a raw data from the API.
         */
        get: function () {
            return this.data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ApiResultAdapter.prototype, "result", {
        /**
         * @returns the result adapted into SDK types.
         */
        get: function () {
            return this.adapter(this.data, this.params);
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @returns the result in the JSON format.
     */
    ApiResultAdapter.prototype.toJSON = function () {
        return this.jsonAdapter(this.result);
    };
    /**
     * Format the result to a specific format.
     */
    ApiResultAdapter.prototype.format = function (formatType) {
        if (formatType === ApiFormatType.RAW) {
            return this.raw;
        }
        if (formatType === ApiFormatType.JSON) {
            return this.toJSON();
        }
        if (formatType === ApiFormatType.NORMAL) {
            return this.result;
        }
        throw new core_1.MoralisApiError({
            code: core_1.ApiErrorCode.GENERIC_API_ERROR,
            message: 'provided formatType not supported',
        });
    };
    return ApiResultAdapter;
}());
exports.ApiResultAdapter = ApiResultAdapter;
//# sourceMappingURL=ApiResultAdapter.js.map

/***/ }),

/***/ 4154:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createEndpoint = exports.createEndpointFactory = exports.EndpointBodyType = void 0;
var EndpointBodyType;
(function (EndpointBodyType) {
    EndpointBodyType["PROPERTY"] = "property";
    EndpointBodyType["BODY"] = "body";
})(EndpointBodyType = exports.EndpointBodyType || (exports.EndpointBodyType = {}));
function createEndpointFactory(factory) {
    return factory;
}
exports.createEndpointFactory = createEndpointFactory;
function createEndpoint(endpoint) {
    if (!endpoint.method) {
        endpoint.method = 'get';
    }
    if (!endpoint.bodyType) {
        endpoint.bodyType = EndpointBodyType.PROPERTY;
    }
    return endpoint;
}
exports.createEndpoint = createEndpoint;
//# sourceMappingURL=Endpoint.js.map

/***/ }),

/***/ 5886:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EndpointParamsReader = void 0;
var Endpoint_1 = __webpack_require__(4154);
var EndpointParamsReader = /** @class */ (function () {
    function EndpointParamsReader(endpoint) {
        this.endpoint = endpoint;
    }
    EndpointParamsReader.prototype.isBodyParam = function (param) {
        if (this.endpoint.method === 'get') {
            return false;
        }
        if (!this.endpoint.bodyParams || this.endpoint.bodyParams.length === 0) {
            return false;
        }
        return this.endpoint.bodyParams.includes(param);
    };
    EndpointParamsReader.prototype.isUrlParam = function (param) {
        return !!this.endpoint.urlParams && this.endpoint.urlParams.includes(param);
    };
    EndpointParamsReader.prototype.getSearchParams = function (params) {
        var _this = this;
        return Object.keys(params).reduce(function (result, key) {
            var _a;
            var paramKey = key;
            if (!params[paramKey] || _this.isBodyParam(key) || _this.isUrlParam(key)) {
                return result;
            }
            return __assign(__assign({}, result), (_a = {}, _a[key] = params[paramKey], _a));
        }, {});
    };
    EndpointParamsReader.prototype.getBodyParams = function (params) {
        var _this = this;
        if (this.endpoint.bodyType === Endpoint_1.EndpointBodyType.BODY && this.endpoint.bodyParams) {
            // TODO: delete `as unknown`
            var paramName = this.endpoint.bodyParams[0];
            return params[paramName];
        }
        return Object.keys(params).reduce(function (result, key) {
            var _a;
            // TODO: delete `as unknown`
            var paramName = key;
            if (!params[paramName] || !_this.isBodyParam(key)) {
                return result;
            }
            if (_this.endpoint.bodyType === Endpoint_1.EndpointBodyType.PROPERTY) {
                return __assign(__assign({}, result), (_a = {}, _a[key] = params[paramName], _a));
            }
            return result;
        }, {});
    };
    return EndpointParamsReader;
}());
exports.EndpointParamsReader = EndpointParamsReader;
//# sourceMappingURL=EndpointParamsReader.js.map

/***/ }),

/***/ 1555:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EndpointResolver = void 0;
var core_1 = __webpack_require__(4243);
var ApiConfig_1 = __webpack_require__(5139);
var isNotFoundError_1 = __webpack_require__(3107);
var ApiResultAdapter_1 = __webpack_require__(8392);
var EndpointParamsReader_1 = __webpack_require__(5886);
var getCommonHeaders_1 = __webpack_require__(599);
var EndpointResolver = /** @class */ (function () {
    function EndpointResolver(endpoint, baseUrl, config, requestController, paramsReader) {
        var _this = this;
        this.endpoint = endpoint;
        this.baseUrl = baseUrl;
        this.config = config;
        this.requestController = requestController;
        this.paramsReader = paramsReader;
        // TODO: error handler to ApiError
        this.get = function (params) { return __awaiter(_this, void 0, void 0, function () {
            var url, apiParams, searchParams, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.createUrl(params);
                        apiParams = this.endpoint.parseParams(params);
                        searchParams = this.paramsReader.getSearchParams(apiParams);
                        return [4 /*yield*/, this.requestController.get(url, searchParams, {
                                headers: this.createHeaders(),
                            })];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, new ApiResultAdapter_1.ApiResultAdapter(result, this.endpoint.apiToResult, this.endpoint.resultToJson, params)];
                }
            });
        }); };
        this.post = function (params) { return __awaiter(_this, void 0, void 0, function () {
            var url, apiParams, searchParams, bodyParams, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.createUrl(params);
                        apiParams = this.endpoint.parseParams(params);
                        searchParams = this.paramsReader.getSearchParams(apiParams);
                        bodyParams = this.paramsReader.getBodyParams(apiParams);
                        return [4 /*yield*/, this.requestController.post(url, searchParams, bodyParams, {
                                headers: this.createHeaders(),
                            })];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, new ApiResultAdapter_1.ApiResultAdapter(result, this.endpoint.apiToResult, this.endpoint.resultToJson, params)];
                }
            });
        }); };
        this.put = function (params) { return __awaiter(_this, void 0, void 0, function () {
            var url, apiParams, searchParams, bodyParams, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.createUrl(params);
                        apiParams = this.endpoint.parseParams(params);
                        searchParams = this.paramsReader.getSearchParams(apiParams);
                        bodyParams = this.paramsReader.getBodyParams(apiParams);
                        return [4 /*yield*/, this.requestController.put(url, searchParams, bodyParams, {
                                headers: this.createHeaders(),
                            })];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, new ApiResultAdapter_1.ApiResultAdapter(result, this.endpoint.apiToResult, this.endpoint.resultToJson, params)];
                }
            });
        }); };
        this.delete = function (params) { return __awaiter(_this, void 0, void 0, function () {
            var url, apiParams, searchParams, bodyParams, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.createUrl(params);
                        apiParams = this.endpoint.parseParams(params);
                        searchParams = this.paramsReader.getSearchParams(apiParams);
                        bodyParams = this.paramsReader.getBodyParams(apiParams);
                        return [4 /*yield*/, this.requestController.delete(url, searchParams, bodyParams, {
                                headers: this.createHeaders(),
                            })];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, new ApiResultAdapter_1.ApiResultAdapter(result, this.endpoint.apiToResult, this.endpoint.resultToJson, params)];
                }
            });
        }); };
        this.fetch = function (params) {
            switch (_this.endpoint.method) {
                case 'post':
                    return _this.post(params);
                case 'put':
                    return _this.put(params);
                case 'delete':
                    return _this.delete(params);
                default:
                    return _this.get(params);
            }
        };
        this.fetchNullable = function (params) { return __awaiter(_this, void 0, void 0, function () {
            var result, e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.fetch(params)];
                    case 1:
                        result = _a.sent();
                        // TODO: this block should be deleted after the back-end adjustments.
                        if (!result.raw || (typeof result.raw === 'object' && Object.keys(result.raw).length === 0)) {
                            throw new core_1.MoralisApiError({
                                code: core_1.ApiErrorCode.NOT_FOUND,
                                message: 'The resource is not found',
                            });
                        }
                        return [2 /*return*/, result];
                    case 2:
                        e_1 = _a.sent();
                        if ((0, isNotFoundError_1.isNotFoundError)(e_1)) {
                            return [2 /*return*/, null];
                        }
                        throw e_1;
                    case 3: return [2 /*return*/];
                }
            });
        }); };
    }
    EndpointResolver.create = function (core, baseUrl, endpointFactory) {
        var requestController = core_1.RequestController.create(core);
        var endpoint = endpointFactory(core);
        var paramsReader = new EndpointParamsReader_1.EndpointParamsReader(endpoint);
        return new EndpointResolver(endpoint, baseUrl, core.config, requestController, paramsReader);
    };
    EndpointResolver.prototype.createUrl = function (params) {
        return this.baseUrl + this.endpoint.getUrl(params);
    };
    EndpointResolver.prototype.createHeaders = function () {
        var apiKey = this.config.get(ApiConfig_1.ApiConfig.apiKey);
        var product = this.config.get(core_1.CoreConfig.product);
        if (!apiKey) {
            throw new core_1.MoralisApiError({
                code: core_1.ApiErrorCode.API_KEY_NOT_SET,
                message: 'apiKey is not set',
            });
        }
        var headers = (0, getCommonHeaders_1.getCommonHeaders)();
        if (apiKey) {
            headers['x-api-key'] = apiKey;
        }
        if (product) {
            headers['x-moralis-product'] = product;
        }
        return headers;
    };
    return EndpointResolver;
}());
exports.EndpointResolver = EndpointResolver;
//# sourceMappingURL=EndpointResolver.js.map

/***/ }),

/***/ 5384:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Endpoints = void 0;
var EndpointResolver_1 = __webpack_require__(1555);
var PaginatedEndpointResolver_1 = __webpack_require__(9917);
var Endpoints = /** @class */ (function () {
    function Endpoints(core, baseUrl) {
        this.core = core;
        this.baseUrl = baseUrl;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.endpoints = [];
    }
    Endpoints.prototype.createFetcher = function (factory) {
        var resolver = EndpointResolver_1.EndpointResolver.create(this.core, this.baseUrl, factory);
        this.endpoints.push(resolver.endpoint);
        return resolver.fetch;
    };
    Endpoints.prototype.createNullableFetcher = function (factory) {
        var resolver = EndpointResolver_1.EndpointResolver.create(this.core, this.baseUrl, factory);
        this.endpoints.push(resolver.endpoint);
        return resolver.fetchNullable;
    };
    Endpoints.prototype.createPaginatedFetcher = function (factory) {
        var resolver = PaginatedEndpointResolver_1.PaginatedEndpointResolver.create(this.core, this.baseUrl, factory);
        this.endpoints.push(resolver.endpoint);
        return resolver.fetch;
    };
    Endpoints.prototype.getDescriptors = function () {
        return this.endpoints.map(function (endpoint) {
            var urlPatternParamNames = endpoint.urlParams || [];
            // TODO: Endpoint<> type should have `urlPattern` property instead of `getUrl` method!
            // For example: .urlPattern = '/{token0Address}/{token1Address}/pairAddress'
            var urlParams = urlPatternParamNames.reduce(function (params, paramName) {
                params[paramName] = "{".concat(paramName, "}");
                return params;
            }, {});
            var urlPattern = endpoint.getUrl(urlParams);
            return {
                // DO NOT return baseUrl here!
                name: endpoint.name,
                urlPatternParamNames: urlPatternParamNames,
                urlPattern: urlPattern,
                method: endpoint.method || 'get',
                bodyParamNames: endpoint.bodyParams ? endpoint.bodyParams.map(String) : [],
            };
        });
    };
    return Endpoints;
}());
exports.Endpoints = Endpoints;
//# sourceMappingURL=Endpoints.js.map

/***/ }),

/***/ 44:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createPaginatedEndpoint = exports.createPaginatedEndpointFactory = void 0;
var Endpoint_1 = __webpack_require__(4154);
function createPaginatedEndpointFactory(factory) {
    return factory;
}
exports.createPaginatedEndpointFactory = createPaginatedEndpointFactory;
function createPaginatedEndpoint(endpoint) {
    if (!endpoint.method) {
        endpoint.method = 'get';
    }
    if (!endpoint.bodyType) {
        endpoint.bodyType = Endpoint_1.EndpointBodyType.PROPERTY;
    }
    return endpoint;
}
exports.createPaginatedEndpoint = createPaginatedEndpoint;
//# sourceMappingURL=PaginatedEndpoint.js.map

/***/ }),

/***/ 9917:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PaginatedEndpointResolver = void 0;
var tryGetNextPageParams_1 = __webpack_require__(1569);
var ApiPaginatedResultAdapter_1 = __webpack_require__(4870);
var ApiConfig_1 = __webpack_require__(5139);
var core_1 = __webpack_require__(4243);
var EndpointParamsReader_1 = __webpack_require__(5886);
var PaginatedEndpointResolver = /** @class */ (function () {
    function PaginatedEndpointResolver(endpoint, baseUrl, config, requestController, paramsReader) {
        var _this = this;
        this.endpoint = endpoint;
        this.baseUrl = baseUrl;
        this.config = config;
        this.requestController = requestController;
        this.paramsReader = paramsReader;
        // TODO: error handler to ApiError
        this.get = function (params) { return __awaiter(_this, void 0, void 0, function () {
            var url, apiParams, searchParams, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.createUrl(params);
                        apiParams = this.endpoint.parseParams(params);
                        searchParams = this.paramsReader.getSearchParams(apiParams);
                        return [4 /*yield*/, this.requestController.get(url, searchParams, {
                                headers: this.createHeaders(),
                            })];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, new ApiPaginatedResultAdapter_1.ApiPaginatedResultAdapter(result, this.endpoint.apiToResult, this.endpoint.resultToJson, params, this.resolveNextCall(params, result))];
                }
            });
        }); };
        this.post = function (params) { return __awaiter(_this, void 0, void 0, function () {
            var url, apiParams, searchParams, bodyParams, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        url = this.createUrl(params);
                        apiParams = this.endpoint.parseParams(params);
                        searchParams = this.paramsReader.getSearchParams(apiParams);
                        bodyParams = this.paramsReader.getBodyParams(apiParams);
                        return [4 /*yield*/, this.requestController.post(url, searchParams, bodyParams, {
                                headers: this.createHeaders(),
                            })];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, new ApiPaginatedResultAdapter_1.ApiPaginatedResultAdapter(result, this.endpoint.apiToResult, this.endpoint.resultToJson, params, this.resolveNextCall(params, result))];
                }
            });
        }); };
        this.resolveNextCall = function (params, result) {
            var _a;
            var nextParams = (0, tryGetNextPageParams_1.tryGetNextPageParams)((_a = _this.endpoint.firstPageIndex) !== null && _a !== void 0 ? _a : 1, params, result);
            if (nextParams) {
                return function () { return _this.fetch(nextParams); };
            }
            return undefined;
        };
        this.fetch = function (params) {
            switch (_this.endpoint.method) {
                case 'post':
                    return _this.post(params);
                default:
                    return _this.get(params);
            }
        };
    }
    PaginatedEndpointResolver.create = function (core, baseUrl, endpointFactory) {
        var requestController = core_1.RequestController.create(core);
        var endpoint = endpointFactory(core);
        var paramsReader = new EndpointParamsReader_1.EndpointParamsReader(endpoint);
        return new PaginatedEndpointResolver(endpoint, baseUrl, core.config, requestController, paramsReader);
    };
    PaginatedEndpointResolver.prototype.createUrl = function (params) {
        return this.baseUrl + this.endpoint.getUrl(params);
    };
    PaginatedEndpointResolver.prototype.createHeaders = function () {
        var apiKey = this.config.get(ApiConfig_1.ApiConfig.apiKey);
        if (!apiKey) {
            throw new core_1.MoralisApiError({
                code: core_1.ApiErrorCode.API_KEY_NOT_SET,
                message: 'apiKey is not set',
            });
        }
        var headers = {};
        if (apiKey) {
            headers['x-api-key'] = apiKey;
        }
        return headers;
    };
    return PaginatedEndpointResolver;
}());
exports.PaginatedEndpointResolver = PaginatedEndpointResolver;
//# sourceMappingURL=PaginatedEndpointResolver.js.map

/***/ }),

/***/ 599:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getCommonHeaders = void 0;
var core_1 = __importDefault(__webpack_require__(4243));
var getCommonHeaders = function () { return ({
    'x-moralis-platform': 'JS SDK',
    'x-moralis-platform-version': core_1.default.libVersion,
    'x-moralis-build-target': 'node',
}); };
exports.getCommonHeaders = getCommonHeaders;
//# sourceMappingURL=getCommonHeaders.js.map

/***/ }),

/***/ 8733:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(4154), exports);
__exportStar(__webpack_require__(5384), exports);
__exportStar(__webpack_require__(1555), exports);
__exportStar(__webpack_require__(44), exports);
__exportStar(__webpack_require__(9917), exports);
__exportStar(__webpack_require__(8392), exports);
__exportStar(__webpack_require__(4870), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 3368:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(1569), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 1569:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.tryGetNextPageParams = void 0;
var core_1 = __webpack_require__(4243);
var tryGetNextPageParams = function (firstPageIndex, currentParams, result) {
    if (firstPageIndex !== 0 && firstPageIndex !== 1) {
        throw new core_1.MoralisApiError({
            message: 'Not supported firstPageIndex. Value can only be 0 or 1',
            code: core_1.ApiErrorCode.NOT_IMPLEMENTED,
        });
    }
    var currentPage = firstPageIndex === 1 ? result.page : result.page + 1;
    var hasNextPage = result.total > result.page_size * currentPage;
    if (!hasNextPage) {
        return null;
    }
    var nextParams = __assign({}, currentParams);
    if (result.cursor) {
        nextParams.cursor = result.cursor;
    }
    else {
        nextParams.offset = (result.page + 1) * (nextParams.limit || 500);
    }
    return nextParams;
};
exports.tryGetNextPageParams = tryGetNextPageParams;
//# sourceMappingURL=tryGetNextPageParams.js.map

/***/ }),

/***/ 5355:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisAuth = exports.BASE_URL = void 0;
var core_1 = __webpack_require__(4243);
var requestMessage_1 = __webpack_require__(7616);
var verify_1 = __webpack_require__(6237);
exports.BASE_URL = 'https://authapi.moralis.io';
var MoralisAuth = /** @class */ (function (_super) {
    __extends(MoralisAuth, _super);
    function MoralisAuth(core) {
        var _this = _super.call(this, MoralisAuth.moduleName, core, exports.BASE_URL) || this;
        _this.requestMessage = function (options) { return (0, requestMessage_1.makeRequestMessage)(_this.core)(options); };
        return _this;
    }
    MoralisAuth.create = function (core) {
        return new MoralisAuth(core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault());
    };
    MoralisAuth.prototype.setup = function () {
        // Nothing
    };
    MoralisAuth.prototype.start = function () {
        // Nothing
    };
    MoralisAuth.prototype.verify = function (options) {
        return (0, verify_1.makeVerify)(this.core)(options);
    };
    MoralisAuth.moduleName = 'auth';
    return MoralisAuth;
}(core_1.ApiModule));
exports.MoralisAuth = MoralisAuth;
//# sourceMappingURL=MoralisAuth.js.map

/***/ }),

/***/ 3228:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var MoralisAuth_1 = __webpack_require__(5355);
__exportStar(__webpack_require__(5355), exports);
exports["default"] = MoralisAuth_1.MoralisAuth;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7616:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeRequestMessage = void 0;
var sol_utils_1 = __webpack_require__(6826);
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var MoralisAuth_1 = __webpack_require__(5355);
var resolvers_1 = __webpack_require__(4381);
var AuthNetworkType_1 = __webpack_require__(4733);
var makeEvmRequestMessage = function (core, _a) {
    var chain = _a.chain, address = _a.address, networkType = _a.networkType, network = _a.network, options = __rest(_a, ["chain", "address", "networkType", "network"]);
    return api_utils_1.EndpointResolver.create(core, MoralisAuth_1.BASE_URL, resolvers_1.initializeChallengeEvm).fetch(__assign({ chainId: evm_utils_1.EvmChain.create(chain).apiId, address: evm_utils_1.EvmAddress.create(address).checksum }, options));
};
var makeSolRequestMessage = function (core, _a) {
    var address = _a.address, solNetwork = _a.solNetwork, networkType = _a.networkType, network = _a.network, options = __rest(_a, ["address", "solNetwork", "networkType", "network"]);
    return api_utils_1.EndpointResolver.create(core, MoralisAuth_1.BASE_URL, resolvers_1.initializeChallengeSol).fetch(__assign({ network: sol_utils_1.SolNetwork.create(solNetwork).network, address: sol_utils_1.SolAddress.create(address).toString() }, options));
};
var makeRequestMessage = function (core) { return function (options) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        // Backwards compatibility for the 'network' parameter
        if (!options.networkType && options.network) {
            options.networkType = options.network;
        }
        switch (options.networkType) {
            case AuthNetworkType_1.AuthNetworkType.EVM:
                return [2 /*return*/, makeEvmRequestMessage(core, options)];
            case AuthNetworkType_1.AuthNetworkType.SOLANA:
                return [2 /*return*/, makeSolRequestMessage(core, options)];
            default:
                if (!options.networkType) {
                    return [2 /*return*/, makeEvmRequestMessage(core, options)];
                }
                throw new core_1.MoralisAuthError({
                    code: core_1.AuthErrorCode.INCORRECT_NETWORK,
                    message: "Incorrect network provided. Got \"".concat(options.networkType, "\", Valid values are: ").concat(Object.values(AuthNetworkType_1.AuthNetworkType)
                        .map(function (value) { return "\"".concat(value, "\""); })
                        .join(', ')),
                });
        }
        return [2 /*return*/];
    });
}); }; };
exports.makeRequestMessage = makeRequestMessage;
//# sourceMappingURL=requestMessage.js.map

/***/ }),

/***/ 6237:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeVerify = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var MoralisAuth_1 = __webpack_require__(5355);
var resolvers_1 = __webpack_require__(4381);
var AuthNetworkType_1 = __webpack_require__(4733);
var makeEvmVerify = function (core, _a) {
    var networkType = _a.networkType, network = _a.network, options = __rest(_a, ["networkType", "network"]);
    return api_utils_1.EndpointResolver.create(core, MoralisAuth_1.BASE_URL, resolvers_1.completeChallengeEvm).fetch({
        message: options.message,
        signature: options.signature,
    });
};
var makeSolVerify = function (core, _a) {
    var networkType = _a.networkType, network = _a.network, options = __rest(_a, ["networkType", "network"]);
    return api_utils_1.EndpointResolver.create(core, MoralisAuth_1.BASE_URL, resolvers_1.completeChallengeSol).fetch({
        message: options.message,
        signature: options.signature,
    });
};
var makeVerify = function (core) { return function (options) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        // Backwards compatibility for the 'network' parameter
        if (!options.networkType && options.network) {
            options.networkType = options.network;
        }
        switch (options.networkType) {
            case AuthNetworkType_1.AuthNetworkType.EVM:
                return [2 /*return*/, makeEvmVerify(core, options)];
            case AuthNetworkType_1.AuthNetworkType.SOLANA:
                return [2 /*return*/, makeSolVerify(core, options)];
            default:
                if (!options.networkType) {
                    return [2 /*return*/, makeEvmVerify(core, options)];
                }
                throw new core_1.MoralisAuthError({
                    code: core_1.AuthErrorCode.INCORRECT_NETWORK,
                    message: "Incorrect network provided. Got \"".concat(options.networkType, "\", Valid values are: ").concat(Object.values(AuthNetworkType_1.AuthNetworkType)
                        .map(function (value) { return "\"".concat(value, "\""); })
                        .join(', ')),
                });
        }
        return [2 /*return*/];
    });
}); }; };
exports.makeVerify = makeVerify;
//# sourceMappingURL=verify.js.map

/***/ }),

/***/ 8618:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.initializeChallengeEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var name = 'requestChallengeEvm';
var method = 'post';
var bodyParams = [
    'domain',
    'chainId',
    'address',
    'statement',
    'uri',
    'expirationTime',
    'notBefore',
    'resources',
    'timeout',
];
var apiToResult = function (apiData) {
    var data = (0, core_1.toCamelCase)(apiData);
    return __assign({}, data);
};
exports.initializeChallengeEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function () { return "/challenge/request/evm"; },
        apiToResult: apiToResult,
        resultToJson: function (data) { return (__assign({}, data)); },
        parseParams: function (params) { return params; },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=evmRequestChallenge.js.map

/***/ }),

/***/ 6563:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.completeChallengeEvm = void 0;
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var api_utils_1 = __webpack_require__(3520);
var name = 'verifyChallengeEvm';
var method = 'post';
var bodyParams = ['message', 'signature'];
exports.completeChallengeEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: 'Verify Challenge (EVM)',
        getUrl: function () { return "/challenge/verify/evm"; },
        apiToResult: function (_a) {
            var chainId = _a.chainId, data = __rest(_a, ["chainId"]);
            return (__assign(__assign({}, data), { 
                // TODO: revisit EVM logic once we know how authentication in other networks work
                chain: evm_utils_1.EvmChain.create(chainId), address: evm_utils_1.EvmAddress.create(data.address), expirationTime: (0, core_1.maybe)(data.expirationTime, function (value) { return new Date(value); }) }));
        },
        resultToJson: function (result) { return (__assign(__assign({}, (0, core_1.toCamelCase)(result)), { chain: result.chain.format(), address: result.address.format() })); },
        parseParams: function (params) { return params; },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=evmVerifyChallenge.js.map

/***/ }),

/***/ 4381:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(8618), exports);
__exportStar(__webpack_require__(6563), exports);
__exportStar(__webpack_require__(5082), exports);
__exportStar(__webpack_require__(5745), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 5082:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.initializeChallengeSol = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var name = 'requestChallengeSolana';
var method = 'post';
var bodyParams = [
    'domain',
    'network',
    'address',
    'statement',
    'uri',
    'expirationTime',
    'notBefore',
    'resources',
    'timeout',
];
var apiToResult = function (apiData) {
    var data = (0, core_1.toCamelCase)(apiData);
    return __assign({}, data);
};
exports.initializeChallengeSol = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function () { return "/challenge/request/solana"; },
        apiToResult: apiToResult,
        resultToJson: function (data) { return (__assign({}, data)); },
        parseParams: function (params) { return params; },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=solRequestChallenge.js.map

/***/ }),

/***/ 5745:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.completeChallengeSol = void 0;
var sol_utils_1 = __webpack_require__(6826);
var core_1 = __webpack_require__(4243);
var api_utils_1 = __webpack_require__(3520);
var name = 'verifyChallengeSolana';
var method = 'post';
var bodyParams = ['message', 'signature'];
exports.completeChallengeSol = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: 'Verify Challenge (Solana)',
        getUrl: function () { return "/challenge/verify/solana"; },
        apiToResult: function (_a) {
            var network = _a.network, data = __rest(_a, ["network"]);
            return (__assign(__assign({}, data), { solNetwork: sol_utils_1.SolNetwork.create(network), address: sol_utils_1.SolAddress.create(data.address), expirationTime: (0, core_1.maybe)(data.expirationTime, function (value) { return new Date(value); }) }));
        },
        resultToJson: function (result) { return (__assign(__assign({}, (0, core_1.toCamelCase)(result)), { solNetwork: result.solNetwork.format(), address: result.address.format() })); },
        parseParams: function (params) { return params; },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=solVerifyChallenge.js.map

/***/ }),

/***/ 4733:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthNetworkType = void 0;
var AuthNetworkType;
(function (AuthNetworkType) {
    AuthNetworkType["EVM"] = "evm";
    AuthNetworkType["SOLANA"] = "solana";
})(AuthNetworkType = exports.AuthNetworkType || (exports.AuthNetworkType = {}));
//# sourceMappingURL=AuthNetworkType.js.map

/***/ }),

/***/ 4181:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.assertUnreachable = exports.UnreachableError = void 0;
var Error_1 = __webpack_require__(2882);
exports.UnreachableError = new Error_1.MoralisCoreError({
    code: Error_1.CoreErrorCode.GENERIC_CORE_ERROR,
    message: "Incorrect type provided, code should not reach here",
});
/**
 * Typesafe check, to make sure that code never reaches a certain point.
 * Can be used as an exhaustive check in swtich/if-else statements
 *
 * When used properly with Typescript, this code should never reach, as it is typed as 'never'
 *
 * If the code does reach this assertion an UnreachableError is thrown
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
var assertUnreachable = function (x) {
    throw exports.UnreachableError;
};
exports.assertUnreachable = assertUnreachable;
//# sourceMappingURL=assertUnreachable.js.map

/***/ }),

/***/ 9954:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(4181), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 1986:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Config = void 0;
var Error_1 = __webpack_require__(2882);
var Config = /** @class */ (function () {
    function Config() {
        this.items = new Map();
    }
    Config.prototype.registerKey = function (key, validator) {
        if (this.items.has(key.name)) {
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.CONFIG_KEY_ALREADY_EXIST,
                message: "Key \"".concat(key.name, "\" is already registered"),
            });
        }
        this.items.set(key.name, { key: key, value: key.defaultValue, validator: validator });
    };
    Config.prototype.getKeys = function () {
        return Array.from(this.items.keys());
    };
    Config.prototype.hasKey = function (key) {
        return this.items.has(key.name);
    };
    Config.prototype.get = function (keyOrName) {
        return this.getItem(keyOrName).value;
    };
    Config.prototype.set = function (keyOrName, value) {
        var item = this.getItem(keyOrName);
        var error = item.validator ? item.validator(value) : null;
        if (error) {
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.CONFIG_INVALID_VALUE,
                message: "Cannot set this config. Invalid value for \"".concat(item.key.name, "\". ").concat(error),
            });
        }
        item.value = value;
    };
    Config.prototype.merge = function (values) {
        var _this = this;
        Object.keys(values).forEach(function (keyName) {
            _this.set(keyName, values[keyName]);
        });
    };
    Config.prototype.reset = function () {
        this.items.forEach(function (item) {
            item.value = item.key.defaultValue;
        });
    };
    Config.prototype.getItem = function (keyOrName) {
        var keyName = typeof keyOrName === 'string' ? keyOrName : keyOrName.name;
        var item = this.items.get(keyName);
        if (!item) {
            // This error occurs when a user tries to set a value for a specific key, but the key is not registered.
            // That situation may occur, when a moralis module is not registered (all keys are registered in the module setup step).
            // If you have this error, you should fix your code. Firstly, you should register all modules, later you can modify the configuration.
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.CONFIG_KEY_NOT_EXIST,
                message: "Key \"".concat(keyName, "\" is unregistered. Have you registered all required modules?"),
            });
        }
        return item;
    };
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=Config.js.map

/***/ }),

/***/ 2153:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CoreConfig = void 0;
exports.CoreConfig = {
    logLevel: {
        name: 'logLevel',
        defaultValue: 'info',
    },
    buidEnvironment: {
        name: 'buidEnvironment',
        defaultValue: 'browser',
    },
    defaultNetwork: {
        name: 'defaultNetwork',
        defaultValue: 'Evm',
    },
    product: {
        name: 'product',
        defaultValue: undefined,
    },
};
//# sourceMappingURL=CoreConfig.js.map

/***/ }),

/***/ 636:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CoreConfigSetup = void 0;
var CoreConfig_1 = __webpack_require__(2153);
var CoreConfigSetup = /** @class */ (function () {
    function CoreConfigSetup() {
    }
    CoreConfigSetup.register = function (config) {
        config.registerKey(CoreConfig_1.CoreConfig.logLevel);
        config.registerKey(CoreConfig_1.CoreConfig.buidEnvironment);
        config.registerKey(CoreConfig_1.CoreConfig.defaultNetwork);
        config.registerKey(CoreConfig_1.CoreConfig.product);
    };
    return CoreConfigSetup;
}());
exports.CoreConfigSetup = CoreConfigSetup;
//# sourceMappingURL=CoreConfigSetup.js.map

/***/ }),

/***/ 9539:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=MoralisConfig.js.map

/***/ }),

/***/ 3503:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(1986), exports);
__exportStar(__webpack_require__(2153), exports);
__exportStar(__webpack_require__(9539), exports);
__exportStar(__webpack_require__(2702), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7285:
/***/ ((__unused_webpack_module, exports) => {


/**
 * Note this is just an interface, used in the core config.
 * The implementations are located in the @moralisweb3/evm-utils package.
 */
Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=EvmChainish.js.map

/***/ }),

/***/ 6499:
/***/ ((__unused_webpack_module, exports) => {


/**
 * Note this is just an interface, used in the core config.
 * The implementations are located in the @moralisweb3/sol-utils package.
 */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.solNetworkNames = void 0;
exports.solNetworkNames = ['mainnet', 'devnet'];
//# sourceMappingURL=SolNetworkish.js.map

/***/ }),

/***/ 2702:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(6499), exports);
__exportStar(__webpack_require__(7285), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 3871:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.StreamErrorCode = exports.AuthErrorCode = exports.ApiErrorCode = exports.CoreErrorCode = void 0;
var CoreErrorCode;
(function (CoreErrorCode) {
    // Generic Core error
    CoreErrorCode["GENERIC_CORE_ERROR"] = "C0001";
    // A module wants to register with a name that already is registered
    CoreErrorCode["DUPLICATE_MODULE"] = "C0002";
    // The module is not registered
    CoreErrorCode["MODULE_NOT_FOUND"] = "C0003";
    // Error in validation check
    CoreErrorCode["VALIDATION_ERROR"] = "C0004";
    CoreErrorCode["INVALID_ARGUMENT"] = "C0005";
    CoreErrorCode["REQUEST_ERROR"] = "C0006";
    CoreErrorCode["NO_DATA_FOUND"] = "C0007";
    CoreErrorCode["NOT_INITIALIZED"] = "C0008";
    CoreErrorCode["ALREADY_INITIALIZED"] = "C0009";
    CoreErrorCode["METHOD_FAILED"] = "C0010";
    CoreErrorCode["STATE_MACHINE_STARTED"] = "C0011";
    CoreErrorCode["STATE_MACHINE_NOT_STARTED"] = "C0012";
    CoreErrorCode["CONFIG_KEY_NOT_EXIST"] = "C0013";
    CoreErrorCode["CONFIG_INVALID_VALUE"] = "C0014";
    CoreErrorCode["CONFIG_KEY_ALREADY_EXIST"] = "C0015";
    CoreErrorCode["INVALID_DATA"] = "C0016";
    CoreErrorCode["BIG_NUMBER_ERROR"] = "C0500";
    CoreErrorCode["NOT_IMPLEMENTED"] = "C9000";
})(CoreErrorCode = exports.CoreErrorCode || (exports.CoreErrorCode = {}));
var ApiErrorCode;
(function (ApiErrorCode) {
    ApiErrorCode["GENERIC_API_ERROR"] = "A0001";
    ApiErrorCode["PAGE_LIMIT_EXCEEDED"] = "A0002";
    ApiErrorCode["API_KEY_NOT_SET"] = "A0003";
    ApiErrorCode["INVALID_PARAMS"] = "A0004";
    ApiErrorCode["NOT_FOUND"] = "A0404";
    ApiErrorCode["NOT_IMPLEMENTED"] = "A9000";
})(ApiErrorCode = exports.ApiErrorCode || (exports.ApiErrorCode = {}));
var AuthErrorCode;
(function (AuthErrorCode) {
    AuthErrorCode["GENERIC_AUTH_ERROR"] = "U0001";
    AuthErrorCode["INCORRECT_NETWORK"] = "U0002";
    AuthErrorCode["INCORRECT_PARAMETER"] = "U0003";
    AuthErrorCode["NOT_IMPLEMENTED"] = "U9000";
})(AuthErrorCode = exports.AuthErrorCode || (exports.AuthErrorCode = {}));
var StreamErrorCode;
(function (StreamErrorCode) {
    StreamErrorCode["GENERIC_STREAM_ERROR"] = "S0001";
    StreamErrorCode["INCORRECT_NETWORK"] = "S0002";
    StreamErrorCode["INCORRECT_PARAMETER"] = "S0003";
    StreamErrorCode["INVALID_SIGNATURE"] = "S0004";
    StreamErrorCode["NOT_IMPLEMENTED"] = "S9000";
})(StreamErrorCode = exports.StreamErrorCode || (exports.StreamErrorCode = {}));
//# sourceMappingURL=ErrorCode.js.map

/***/ }),

/***/ 9489:
/***/ (function(__unused_webpack_module, exports) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisStreamError = exports.MoralisAuthError = exports.MoralisApiError = exports.MoralisCoreError = exports.MoralisError = void 0;
var MoralisError = /** @class */ (function (_super) {
    __extends(MoralisError, _super);
    function MoralisError(_a) {
        var message = _a.message, code = _a.code, details = _a.details, cause = _a.cause;
        var _this = 
        // @ts-ignore Typescript does not recognise 'cause' ? OR we have wrong TS version
        _super.call(this, MoralisError.makeMessage(message, code), { cause: cause }) || this;
        _this.name = 'Moralis SDK Error';
        _this.isMoralisError = true;
        // Set prototype manually, as required since Typescript 2.2: https://www.typescriptlang.org/docs/handbook/release-notes/typescript-2-2.html#example
        Object.setPrototypeOf(_this, MoralisError.prototype);
        _this.code = code;
        _this.details = details;
        if (cause) {
            _this.cause = cause;
            if ('stack' in cause) {
                _this.stack = "".concat(_this.stack, "\nCAUSE: ").concat(cause.stack);
            }
        }
        if (Error.captureStackTrace) {
            Error.captureStackTrace(_this, MoralisError);
        }
        return _this;
    }
    MoralisError.makeMessage = function (message, code) { return "[".concat(code, "] ").concat(message); };
    return MoralisError;
}(Error));
exports.MoralisError = MoralisError;
var MoralisCoreError = /** @class */ (function (_super) {
    __extends(MoralisCoreError, _super);
    function MoralisCoreError(options) {
        var _this = _super.call(this, options) || this;
        _this.name = 'Moralis SDK Core Error';
        if (Error.captureStackTrace) {
            Error.captureStackTrace(_this, MoralisCoreError);
        }
        return _this;
    }
    return MoralisCoreError;
}(MoralisError));
exports.MoralisCoreError = MoralisCoreError;
var MoralisApiError = /** @class */ (function (_super) {
    __extends(MoralisApiError, _super);
    function MoralisApiError(options) {
        var _this = _super.call(this, options) || this;
        _this.name = 'Moralis SDK API Error';
        if (Error.captureStackTrace) {
            Error.captureStackTrace(_this, MoralisApiError);
        }
        return _this;
    }
    return MoralisApiError;
}(MoralisError));
exports.MoralisApiError = MoralisApiError;
var MoralisAuthError = /** @class */ (function (_super) {
    __extends(MoralisAuthError, _super);
    function MoralisAuthError(options) {
        var _this = _super.call(this, options) || this;
        _this.name = 'Moralis Auth Error';
        if (Error.captureStackTrace) {
            Error.captureStackTrace(_this, MoralisAuthError);
        }
        return _this;
    }
    return MoralisAuthError;
}(MoralisError));
exports.MoralisAuthError = MoralisAuthError;
var MoralisStreamError = /** @class */ (function (_super) {
    __extends(MoralisStreamError, _super);
    function MoralisStreamError(options) {
        var _this = _super.call(this, options) || this;
        _this.name = 'Moralis Stream Error';
        if (Error.captureStackTrace) {
            Error.captureStackTrace(_this, MoralisStreamError);
        }
        return _this;
    }
    return MoralisStreamError;
}(MoralisError));
exports.MoralisStreamError = MoralisStreamError;
//# sourceMappingURL=MoralisError.js.map

/***/ }),

/***/ 2882:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(3871), exports);
__exportStar(__webpack_require__(9489), exports);
__exportStar(__webpack_require__(6969), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6969:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.isMoralisError = void 0;
var isMoralisError = function (error) {
    if (!(error instanceof Error)) {
        return false;
    }
    if (!error.isMoralisError) {
        return false;
    }
    return true;
};
exports.isMoralisError = isMoralisError;
//# sourceMappingURL=isMoralisError.js.map

/***/ }),

/***/ 4466:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ApiModule = void 0;
var ModuleType_1 = __webpack_require__(3630);
var Module_1 = __webpack_require__(5564);
/**
 * The base class of every Moralis Api class that gets registered as a module via MoralisModules
 * It should always be created with:
 * - `name`: name of the module (should be unique)
 * - `core`: the MoralisCore instance
 * - `baseUrl`: the base url where of the api
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
var ApiModule = /** @class */ (function (_super) {
    __extends(ApiModule, _super);
    function ApiModule(name, core, baseUrl) {
        var _this = _super.call(this, name, core, ModuleType_1.ModuleType.API) || this;
        _this.baseUrl = baseUrl;
        return _this;
    }
    return ApiModule;
}(Module_1.Module));
exports.ApiModule = ApiModule;
//# sourceMappingURL=ApiModule.js.map

/***/ }),

/***/ 5564:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Module = void 0;
var eventemitter3_1 = __importDefault(__webpack_require__(5502));
var LoggerController_1 = __webpack_require__(5550);
var ModuleType_1 = __webpack_require__(3630);
/**
 * The base class of every Moralis class that gets registered as a module via MoralisModules
 * It should always be created with:
 * - `name`: name of the module (should be unique)
 * - `core`: the MoralisCore instance
 * - `type`: (optional) CoreModuleType, defaults to CoreModuleType.DEFAULT
 *
 * When creating an api, or network module, you should use the ApiModule or NetworkModule
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
var Module = /** @class */ (function () {
    function Module(name, core, type) {
        if (type === void 0) { type = ModuleType_1.ModuleType.DEFAULT; }
        this.name = name;
        this.core = core;
        this.type = type;
        this.logger = LoggerController_1.LoggerController.create(this.name, this.core);
        this.emitter = new eventemitter3_1.default();
    }
    /**
     * Any cleanup that needs to be done for removing this module.
     * It also should remove the module via `this.core.modules.remove(this.name)`
     */
    Module.prototype.cleanUp = function () {
        this.core.modules.remove(this.name);
    };
    /**
     * Listen to an event, and returns a cleanup function
     */
    Module.prototype.listen = function (eventName, listener) {
        var _this = this;
        this.emitter.on(eventName, listener);
        return function () { return _this.emitter.removeListener(eventName, listener); };
    };
    return Module;
}());
exports.Module = Module;
//# sourceMappingURL=Module.js.map

/***/ }),

/***/ 3630:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ModuleType = void 0;
var ModuleType;
(function (ModuleType) {
    ModuleType["API"] = "api";
    ModuleType["DEFAULT"] = "default";
})(ModuleType = exports.ModuleType || (exports.ModuleType = {}));
//# sourceMappingURL=ModuleType.js.map

/***/ }),

/***/ 4992:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Modules = void 0;
var utils_1 = __webpack_require__(108);
var Error_1 = __webpack_require__(2882);
/**
 * MoralisModues handles all registered modules.
 * Any package that is used in Moralis, should register itself via this class.
 * This allows cross-communication between modules and easy management of the modules
 *
 * This class is responsible for:
 * - registering new modules
 * - removing modules (in theory possible for exotic usecases, but might break the app if done after initialisation)
 * - getting individual modules by name, type or everything
 */
var Modules = /** @class */ (function () {
    function Modules() {
        this.modules = new Map();
    }
    /**
     * Register and setup a new module by providing a module that is extended from BaseClass.
     * This will throw an error if the name is not unique
     * @param module the module that needs to be registered
     */
    Modules.prototype.register = function (module) {
        if (this.modules.has(module.name)) {
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.DUPLICATE_MODULE,
                message: "The module \"".concat(module.name, "\" has already been registered."),
            });
        }
        this.modules.set(module.name, module);
        module.setup();
    };
    /**
     * Returns the module with the given name.
     * This module should have been registered with `register`
     * @param name the module name
     * @returns a valid BaseModule
     * @throws a MoralisCoreError if no module with the given name has been registered
     */
    Modules.prototype.get = function (name) {
        var module = this.modules.get(name);
        if (!module) {
            throw new Error_1.MoralisCoreError({ code: Error_1.CoreErrorCode.MODULE_NOT_FOUND, message: "Module \"".concat(name, "\" does not exist.") });
        }
        return module;
    };
    /**
     * Tries to return the module with the given name if exist. Otherwise returns null.
     * @param name the module name
     * @returns a valid BaseModule or null
     */
    Modules.prototype.tryGet = function (name) {
        return this.modules.get(name) || null;
    };
    Modules.prototype.has = function (name) {
        return this.modules.has(name);
    };
    /**
     * Returns the network module with the provided name.
     * @param name the module name
     * @returns a valid ApiModule
     * @throws a MoralisCoreError if no network module with the given name has been registered
     */
    Modules.prototype.getApi = function (name) {
        var module = this.modules.get(name);
        if (!module || !(0, utils_1.isApiModule)(module)) {
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.MODULE_NOT_FOUND,
                message: "No ApiModule found with the name \"".concat(name, "\""),
            });
        }
        return module;
    };
    /**
     * Remove the module with the provided name, if it has been registered,
     * @param name the module name
     * @throws a MoralisCoreError if the module cannot be found.
     */
    Modules.prototype.remove = function (name) {
        var isRemoved = this.modules.delete(name);
        if (!isRemoved) {
            throw new Error_1.MoralisCoreError({ code: Error_1.CoreErrorCode.MODULE_NOT_FOUND, message: "Module \"".concat(name, "\" does not exist.") });
        }
    };
    /**
     * List all the registered modules
     * @returns an array of BaseModule that have been registered
     */
    Modules.prototype.list = function () {
        return Array.from(this.modules.values());
    };
    /**
     * Returns the names of all registered modules
     */
    Modules.prototype.listNames = function () {
        return this.list().map(function (module) { return module.name; });
    };
    /**
     * List all the registered api modules (eg. modules with the type CoreModuleType.API)
     */
    Modules.prototype.listApis = function () {
        return this.list().filter(utils_1.isApiModule);
    };
    return Modules;
}());
exports.Modules = Modules;
//# sourceMappingURL=Modules.js.map

/***/ }),

/***/ 8624:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(5564), exports);
__exportStar(__webpack_require__(4466), exports);
__exportStar(__webpack_require__(3630), exports);
__exportStar(__webpack_require__(4992), exports);
__exportStar(__webpack_require__(108), exports);
__exportStar(__webpack_require__(4295), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 4295:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 108:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.isApiModule = void 0;
var ModuleType_1 = __webpack_require__(3630);
/**
 * Verify if the provided class is a api type.
 * Should be used as a Typescript type-guard
 *
 * @example
 * ```
 * if(isApiModule(module)){
 *  // module is types as ApiModule here
 * }
 * ```
 */
var isApiModule = function (moralisClass) {
    if (moralisClass.type === ModuleType_1.ModuleType.API) {
        return true;
    }
    return false;
};
exports.isApiModule = isApiModule;
//# sourceMappingURL=utils.js.map

/***/ }),

/***/ 478:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisCore = void 0;
var Modules_1 = __webpack_require__(4992);
var LoggerController_1 = __webpack_require__(5550);
var Config_1 = __webpack_require__(1986);
var CoreConfigSetup_1 = __webpack_require__(636);
var version_1 = __webpack_require__(717);
/**
 * MoralisCore is used in all Moralis applications
 * This class is **required** to be implemented in every app
 *
 * This class is responsible for:
 * - registering, removing and accessing modules
 * - accessing and changing the config
 */
var MoralisCore = /** @class */ (function () {
    function MoralisCore(modules, config, logger) {
        var _this = this;
        this.modules = modules;
        this.config = config;
        this.logger = logger;
        this.name = MoralisCore.moduleName;
        /**
         * Register all specified modules and configurations
         * @params array of all modules (any module that is extended from BaseModule) that you want to include
         */
        this.registerModules = function (modules) {
            modules.forEach(_this.registerModule);
        };
        /**
         * Register a new module
         */
        this.registerModule = function (module) {
            if ('create' in module) {
                module = module.create(_this);
            }
            _this.modules.register(module);
            _this.logger.verbose('Module registered', { module: module.name });
        };
        this.getModule = function (name) {
            return _this.modules.get(name);
        };
        /**
         * Start all modules, this function should be called before any interaction with a module,
         * as it is responsible for initialising the modules.
         *
         * This will call `start()` on every registered module
         */
        this.start = function (providedConfig) { return __awaiter(_this, void 0, void 0, function () {
            var allModules;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        allModules = this.modules.list();
                        if (providedConfig) {
                            this.config.merge(providedConfig);
                        }
                        this.logger.verbose('Starting all registered modules', {
                            moduleNames: this.modules.listNames(),
                        });
                        return [4 /*yield*/, Promise.all(allModules.map(function (module) { return module.start(); }))];
                    case 1:
                        _a.sent();
                        this.logger.verbose('Finished starting all registered modules', {
                            moduleNames: this.modules.listNames(),
                        });
                        return [2 /*return*/];
                }
            });
        }); };
    }
    MoralisCore.create = function () {
        var modules = new Modules_1.Modules();
        var config = new Config_1.Config();
        var logger = new LoggerController_1.LoggerController(MoralisCore.moduleName, config);
        var core = new MoralisCore(modules, config, logger);
        CoreConfigSetup_1.CoreConfigSetup.register(config);
        return core;
    };
    MoralisCore.moduleName = 'core';
    MoralisCore.libVersion = version_1.LIB_VERSION;
    return MoralisCore;
}());
exports.MoralisCore = MoralisCore;
//# sourceMappingURL=MoralisCore.js.map

/***/ }),

/***/ 2481:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisCoreProvider = void 0;
var Error_1 = __webpack_require__(2882);
var MoralisCoreProvider = /** @class */ (function () {
    function MoralisCoreProvider() {
    }
    MoralisCoreProvider.getDefault = function () {
        if (!this.core) {
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.NOT_INITIALIZED,
                message: 'Default instance of MoralisCore is not set',
            });
        }
        return this.core;
    };
    MoralisCoreProvider.setDefault = function (core) {
        if (this.core) {
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.ALREADY_INITIALIZED,
                message: 'Default instance of MoralisCore is already set',
            });
        }
        this.core = core;
    };
    return MoralisCoreProvider;
}());
exports.MoralisCoreProvider = MoralisCoreProvider;
//# sourceMappingURL=MoralisCoreProvider.js.map

/***/ }),

/***/ 6210:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AxiosRetry = void 0;
var axios_1 = __importDefault(__webpack_require__(2167));
var isTest_1 = __webpack_require__(9126);
var noop_1 = __webpack_require__(3112);
var AxiosRetry = /** @class */ (function () {
    function AxiosRetry() {
    }
    // TODO: refactor to reduce complexity
    // eslint-disable-next-line complexity
    AxiosRetry.request = function (retryConfig, requestConfig) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var attempt, response, e_1, axiosError;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        attempt = 1;
                        _b.label = 1;
                    case 1:
                        _b.trys.push([1, 5, , 6]);
                        if (!(0, isTest_1.isTest)()) return [3 /*break*/, 3];
                        /**
                         * Known issue where in Jest, axios.request() will leave open handlers.
                         * See: https://stackoverflow.com/questions/69169492/async-external-function-leaves-open-handles-jest-supertest-express
                         */
                        // eslint-disable-next-line no-await-in-loop -- we have sequential and conditional async requests
                        return [4 /*yield*/, process.nextTick(noop_1.noop)];
                    case 2:
                        /**
                         * Known issue where in Jest, axios.request() will leave open handlers.
                         * See: https://stackoverflow.com/questions/69169492/async-external-function-leaves-open-handles-jest-supertest-express
                         */
                        // eslint-disable-next-line no-await-in-loop -- we have sequential and conditional async requests
                        _b.sent();
                        _b.label = 3;
                    case 3: return [4 /*yield*/, axios_1.default.request(requestConfig)];
                    case 4:
                        response = _b.sent();
                        return [2 /*return*/, response];
                    case 5:
                        e_1 = _b.sent();
                        if (attempt >= retryConfig.maxAttempts) {
                            throw e_1;
                        }
                        if (!requestConfig.method || !retryConfig.allowedMethods.includes(requestConfig.method.toUpperCase())) {
                            throw e_1;
                        }
                        if (!axios_1.default.isAxiosError(e_1)) {
                            throw e_1;
                        }
                        axiosError = e_1;
                        if (!((_a = axiosError.response) === null || _a === void 0 ? void 0 : _a.status) || !retryConfig.allowedResponseStatuses.includes(axiosError.response.status)) {
                            throw e_1;
                        }
                        if (retryConfig.beforeRetry) {
                            retryConfig.beforeRetry(attempt, axiosError);
                        }
                        return [3 /*break*/, 6];
                    case 6:
                        attempt++;
                        return [3 /*break*/, 1];
                    case 7: return [2 /*return*/];
                }
            });
        });
    };
    return AxiosRetry;
}());
exports.AxiosRetry = AxiosRetry;
//# sourceMappingURL=AxiosRetry.js.map

/***/ }),

/***/ 5550:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LoggerController = void 0;
/* eslint-disable no-console */
var isMoralisError_1 = __webpack_require__(6969);
var CoreConfig_1 = __webpack_require__(2153);
var logLevelMap = {
    verbose: 5,
    debug: 4,
    info: 3,
    warning: 2,
    error: 1,
    off: 0,
};
/**
 * LoggerController, responsible to create log messages for each module.
 * It should be created with the name of the module like `new Logger('module-name')`
 * It will then prefix any logs with that module-name for easy debugging
 * It will show only logs up to the specified `logLevel` in the MoralisConfig
 */
var LoggerController = /** @class */ (function () {
    function LoggerController(moduleName, config) {
        this.moduleName = moduleName;
        this.config = config;
    }
    LoggerController.create = function (moduleName, core) {
        return new LoggerController(moduleName, core.config);
    };
    Object.defineProperty(LoggerController.prototype, "level", {
        get: function () {
            return this.config.get(CoreConfig_1.CoreConfig.logLevel);
        },
        enumerable: false,
        configurable: true
    });
    LoggerController.prototype._transport = function (level, message, details) {
        var logMessage = this._makeLogMessage(message);
        var args = [logMessage, details].filter(function (arg) { return arg != null; });
        switch (level) {
            case 'error':
                console.error.apply(console, args);
                break;
            case 'warn':
                console.warn.apply(console, args);
                break;
            case 'log':
                console.log.apply(console, args);
                break;
        }
    };
    LoggerController.prototype._shouldLog = function (logLevel) {
        var level = logLevelMap[logLevel];
        var acceptedLevel = logLevelMap[this.level];
        if (level > acceptedLevel) {
            return false;
        }
        return true;
    };
    LoggerController.prototype._makeLogMessage = function (message) {
        return "Moralis[".concat(this.moduleName, "]: ").concat(message);
    };
    LoggerController.prototype.error = function (error, details) {
        if (!this._shouldLog('error')) {
            return;
        }
        var message = '';
        if (typeof error === 'string') {
            message = error;
        }
        else if ((0, isMoralisError_1.isMoralisError)(error)) {
            message = error.message;
            if (error.details) {
                if (details) {
                    details._errorDetails = error.details;
                }
                else {
                    details = {
                        _errorDetails: error.details,
                    };
                }
            }
        }
        else {
            message = error.message;
        }
        this._transport('error', message, details);
    };
    LoggerController.prototype.warn = function (message, details) {
        if (!this._shouldLog('warning')) {
            return;
        }
        this._transport('warn', message, details);
    };
    LoggerController.prototype.info = function (message, details) {
        if (!this._shouldLog('info')) {
            return;
        }
        this._transport('log', message, details);
    };
    LoggerController.prototype.debug = function (message, details) {
        if (!this._shouldLog('debug')) {
            return;
        }
        this._transport('log', message, details);
    };
    LoggerController.prototype.verbose = function (message, details) {
        if (!this._shouldLog('verbose')) {
            return;
        }
        this._transport('log', message, details);
    };
    return LoggerController;
}());
exports.LoggerController = LoggerController;
//# sourceMappingURL=LoggerController.js.map

/***/ }),

/***/ 7544:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getMessageFromApiRequestError = exports.isApiRequestError = void 0;
var axios_1 = __webpack_require__(2167);
/**
 * Verify if the error is an AxiosError that is caused by a HTTP API error.
 */
var isApiRequestError = function (error) {
    // Check if the error is an axios error
    if (!(error instanceof axios_1.AxiosError)) {
        return false;
    }
    // Check if the error is a result of a 400 or 500 response
    if (error.code !== axios_1.AxiosError.ERR_BAD_REQUEST && error.code !== axios_1.AxiosError.ERR_BAD_RESPONSE) {
        return false;
    }
    return true;
};
exports.isApiRequestError = isApiRequestError;
/**
 * Extract the message from a ApiRequestError. Note that this is implemented based on how the Moralis APIs return Errors.
 * This can be in the form:
 * - { message: 'some message' }
 * - { message: ['some message', 'some other message'] }
 * - { }
 */
var getMessageFromApiRequestError = function (error) {
    var _a = error.response.data, message = _a.message, details = _a.details;
    var result = 'Unknown error (no error info returned from API)';
    if (Array.isArray(message)) {
        result = message.join(', ');
    }
    else if (typeof message === 'string') {
        result = message;
    }
    if (details) {
        result += " ".concat(JSON.stringify(details));
    }
    return result;
};
exports.getMessageFromApiRequestError = getMessageFromApiRequestError;
//# sourceMappingURL=ApiRequestError.js.map

/***/ }),

/***/ 504:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RequestController = void 0;
var Error_1 = __webpack_require__(2882);
var AxiosRetry_1 = __webpack_require__(6210);
var ApiRequestError_1 = __webpack_require__(7544);
/**
 * A controller responsible to handle all requests in Moralis,
 * compatible with browser, nodejJs and react-native
 */
var RequestController = /** @class */ (function () {
    function RequestController(logger) {
        this.logger = logger;
    }
    RequestController.create = function (core) {
        return new RequestController(core.logger);
    };
    RequestController.prototype.request = function (config) {
        return __awaiter(this, void 0, void 0, function () {
            var retryConfig, response, e_1, error;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.logger.verbose('[RequestController] request started', {
                            url: config.url,
                            method: config.method,
                            body: config.data,
                        });
                        retryConfig = {
                            maxAttempts: 2,
                            allowedMethods: ['GET', 'OPTIONS'],
                            allowedResponseStatuses: [408, 413, 429, 500, 502, 503, 504],
                            beforeRetry: function (attempt, error) {
                                _this.logger.verbose('[RequestController] request retry', {
                                    url: config.url,
                                    method: config.method,
                                    body: config.data,
                                    error: error,
                                    attempt: attempt,
                                });
                            },
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, AxiosRetry_1.AxiosRetry.request(retryConfig, __assign(__assign({}, config), { timeout: 10000 }))];
                    case 2:
                        response = _a.sent();
                        return [2 /*return*/, response.data];
                    case 3:
                        e_1 = _a.sent();
                        error = this.makeError(e_1);
                        this.logger.verbose('[RequestController] request error', {
                            url: config.url,
                            method: config.method,
                            body: config.data,
                            cause: error.cause,
                            name: error.name,
                            details: error.details,
                        });
                        throw error;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    RequestController.prototype.makeError = function (error) {
        if ((0, ApiRequestError_1.isApiRequestError)(error)) {
            var _a = error.response, status = _a.status, statusText = _a.statusText;
            var apiMessage = (0, ApiRequestError_1.getMessageFromApiRequestError)(error);
            return new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.REQUEST_ERROR,
                message: "Request failed, ".concat(statusText, "(").concat(status, "): ").concat(apiMessage),
                cause: error,
                details: {
                    status: status,
                    response: error.response,
                },
            });
        }
        var err = error instanceof Error ? error : new Error("".concat(error));
        return new Error_1.MoralisCoreError({
            code: Error_1.CoreErrorCode.REQUEST_ERROR,
            message: "Request failed: ".concat(err.message),
            cause: err,
        });
    };
    RequestController.prototype.post = function (url, searchParams, body, options, abortSignal) {
        return this.request({
            url: url,
            params: searchParams,
            method: 'POST',
            data: body,
            headers: options === null || options === void 0 ? void 0 : options.headers,
            signal: abortSignal,
        });
    };
    RequestController.prototype.put = function (url, searchParams, body, options, abortSignal) {
        return this.request({
            url: url,
            params: searchParams,
            method: 'PUT',
            data: body,
            headers: options === null || options === void 0 ? void 0 : options.headers,
            signal: abortSignal,
        });
    };
    RequestController.prototype.get = function (url, searchParams, options, abortSignal) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.request({
                        url: url,
                        params: searchParams,
                        method: 'GET',
                        headers: options === null || options === void 0 ? void 0 : options.headers,
                        signal: abortSignal,
                    })];
            });
        });
    };
    RequestController.prototype.delete = function (url, searchParams, body, options, abortSignal) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.request({
                        url: url,
                        params: searchParams,
                        method: 'DELETE',
                        data: body,
                        headers: options === null || options === void 0 ? void 0 : options.headers,
                        signal: abortSignal,
                    })];
            });
        });
    };
    return RequestController;
}());
exports.RequestController = RequestController;
//# sourceMappingURL=RequestController.js.map

/***/ }),

/***/ 3471:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(504), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 1757:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(3471), exports);
__exportStar(__webpack_require__(5550), exports);
__exportStar(__webpack_require__(6210), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6973:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BigNumber = void 0;
var BigNumberFormatter_1 = __webpack_require__(6358);
var BigNumberParser_1 = __webpack_require__(6655);
/**
 * The BigNumber class is a MoralisData that references to a the value of a BigNumber
 *
 * @category DataType
 */
var BigNumber = /** @class */ (function () {
    function BigNumber(value) {
        this.value = value;
    }
    /**
     * Create a new instance of BigNumber from any valid address input.
     *
     * @param value - the BigNumberish type
     * @example BigNumber.create(12);
     * @example BigNumber.create("20");
     * @returns a new BigNumber instance
     */
    BigNumber.create = function (value) {
        if (value instanceof BigNumber) {
            return value;
        }
        return new BigNumber(BigNumberParser_1.BigNumberParser.parseInt(value));
    };
    /**
     * Creates a new BigNumber from given decimals.
     * @param value
     * @param decimals - This is optional and defaults to 0
     * @example BigNumber.fromDecimal("1.23456789", 18);
     */
    BigNumber.fromDecimal = function (value, decimals) {
        if (decimals === void 0) { decimals = 0; }
        return new BigNumber(BigNumberParser_1.BigNumberParser.parseDecimal(value, decimals));
    };
    /**
     * @returns the value of this BigNumber as a BigInt
     * @example BigNumber.create(12).toBigInt();
     */
    BigNumber.prototype.toBigInt = function () {
        return this.value;
    };
    /**
     * Adds a BigNumber to current BigNumber instance.
     * @param value - the BigNumberish to add
     * @returns the result of the addition
     * @example BigNumber.create(12).add(7);
     * @example BigNumber.create(12).add("1000000000000000000");
     */
    BigNumber.prototype.add = function (value) {
        return new BigNumber(this.value + asBigInt(value));
    };
    /**
     * Subtracts a BigNumber from current BigNumber instance.
     * @param value - the BigNumberish to subtract
     * @returns the result of the subtraction
     * @example BigNumber.create(12).sub(7);
     * @example BigNumber.create("1000000000000000000").sub(20);
     */
    BigNumber.prototype.sub = function (value) {
        return new BigNumber(this.value - asBigInt(value));
    };
    /**
     * Multiplies a BigNumber with current BigNumber instance.
     * @param value - the BigNumberish to multiply
     * @returns the result of the multiplication
     * @example BigNumber.create(12).mul(7);
     * @example BigNumber.create(12).mul("1000000000000000000");
     */
    BigNumber.prototype.mul = function (value) {
        return new BigNumber(this.value * asBigInt(value));
    };
    /**
     * Divides a BigNumber with current BigNumber instance.
     * @param value - the BigNumberish to divide
     * @returns the result of the division
     * @example BigNumber.create(12).div(7);
     * @example BigNumber.create(1).div("1000000000000000000");
     */
    BigNumber.prototype.div = function (value) {
        return new BigNumber(this.value / asBigInt(value));
    };
    /**
     * Checks the equality of the current BigNumber with another BigNumber.
     * @param value - the BigNumberish to compare
     * @returns true if the BigNumbers are equal
     * @example BigNumber.create(12).equals(BigNumber.create(12)); // true
     */
    BigNumber.prototype.equals = function (value) {
        return this.value === value.toBigInt();
    };
    /**
     * Converts BigNumber instance to value in given decimals.
     * @param decimals - The decimals to convert to
     * @example BigNumber.create(12).toDecimal(18);
     */
    BigNumber.prototype.toDecimal = function (decimals) {
        return BigNumberFormatter_1.BigNumberFormatter.toDecimal(this.value, decimals);
    };
    /**
     * Converts BigNumber instance to string.
     * @example BigNumber.create(12).toString();
     */
    BigNumber.prototype.toString = function () {
        return this.value.toString();
    };
    /**
     * Converts BigNumber instance to hex string.
     * @example BigNumber.create(12).toHex();
     */
    BigNumber.prototype.toHex = function () {
        return BigNumberFormatter_1.BigNumberFormatter.toHex(this.value);
    };
    /**
     * Converts BigNumber instance to hex string.
     * @example BigNumber.create(12).toJSON();
     */
    BigNumber.prototype.toJSON = function () {
        return this.toHex();
    };
    return BigNumber;
}());
exports.BigNumber = BigNumber;
function asBigInt(value) {
    return BigNumber.create(value).toBigInt();
}
//# sourceMappingURL=BigNumber.js.map

/***/ }),

/***/ 6358:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BigNumberFormatter = void 0;
var Error_1 = __webpack_require__(2882);
var BigNumberFormatter = /** @class */ (function () {
    function BigNumberFormatter() {
    }
    BigNumberFormatter.toDecimal = function (value, decimals) {
        if (decimals < 0) {
            throw new Error_1.MoralisCoreError({
                code: Error_1.CoreErrorCode.BIG_NUMBER_ERROR,
                message: 'Invalid decimals',
            });
        }
        var result = value.toString();
        if (decimals === 0) {
            return result;
        }
        var isNegative = result.startsWith('-');
        if (isNegative) {
            result = result.substring(1);
        }
        result = result.padStart(decimals, '0');
        var dot = result.length - decimals;
        var whole = dot === 0 ? '0' : result.substring(0, dot);
        var fraction = result.substring(dot);
        result = "".concat(whole, ".").concat(fraction);
        while (result[result.length - 1] === '0' && result[result.length - 2] !== '.') {
            result = result.substring(0, result.length - 1);
        }
        if (isNegative) {
            result = "-".concat(result);
        }
        return result;
    };
    BigNumberFormatter.toHex = function (value) {
        var result = value.toString(16);
        var isNegative = result.startsWith('-');
        if (isNegative) {
            result = result.substring(1);
        }
        if (result.length % 2 !== 0) {
            result = "0".concat(result);
        }
        result = "0x".concat(result);
        if (isNegative) {
            result = "-".concat(result);
        }
        return result;
    };
    return BigNumberFormatter;
}());
exports.BigNumberFormatter = BigNumberFormatter;
//# sourceMappingURL=BigNumberFormatter.js.map

/***/ }),

/***/ 6655:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BigNumberParser = void 0;
var Error_1 = __webpack_require__(2882);
var BigNumberParser = /** @class */ (function () {
    function BigNumberParser() {
    }
    BigNumberParser.parseInt = function (value) {
        assertNotEmpty(value);
        if (typeof value === 'string') {
            if (value.length === 0) {
                throw createError('Value is empty');
            }
            var isNegativeHex = value.startsWith('-0x');
            if (isNegativeHex) {
                value = value.substring(1);
            }
            var result = BigInt(value);
            if (isNegativeHex) {
                result *= BigInt(-1);
            }
            return result;
        }
        return BigInt(value);
    };
    // TODO: refactor to reduce complexity
    // eslint-disable-next-line complexity
    BigNumberParser.parseDecimal = function (value, decimals) {
        assertNotEmpty(value);
        var multiplier = getMultiplier(decimals);
        if (typeof value === 'number') {
            return BigInt(value) * multiplier;
        }
        if (typeof value === 'bigint') {
            return value * multiplier;
        }
        var isNegative = value.startsWith('-');
        if (isNegative) {
            value = value.substring(1);
        }
        var fragments = value.split('.');
        if (fragments.length > 2) {
            throw createError('Value has more than one dot');
        }
        if (fragments.some(function (fragment) { return !fragment; })) {
            throw createError('Value has empty fragments');
        }
        var result;
        if (fragments.length === 1) {
            result = BigInt(fragments[0]) * multiplier;
        }
        else {
            var whole = fragments[0];
            var fraction = fragments[1];
            if (fraction.length > decimals) {
                throw createError("Value has too long fractional part: ".concat(fraction.length, ", max: ").concat(decimals));
            }
            if (fraction.length < decimals) {
                fraction = fraction.padEnd(decimals, '0');
            }
            result = BigInt(whole) * multiplier + BigInt(fraction);
        }
        if (isNegative) {
            result *= BigInt(-1);
        }
        return result;
    };
    return BigNumberParser;
}());
exports.BigNumberParser = BigNumberParser;
function assertNotEmpty(value) {
    if (value === null) {
        throw createError('Value is null');
    }
    if (value === undefined) {
        throw createError('Value is undefined');
    }
}
function getMultiplier(decimals) {
    if (decimals < 0) {
        throw createError('Invalid decimals');
    }
    // decimals = 0, multiplier = 1
    // decimals = 1, multiplier = 10
    // decimals = 2, multiplier = 100
    // ...
    var ten = BigInt(10);
    var multiplier = BigInt(1);
    while (decimals-- > 0) {
        multiplier *= ten;
    }
    return multiplier;
}
function createError(message) {
    return new Error_1.MoralisCoreError({
        code: Error_1.CoreErrorCode.BIG_NUMBER_ERROR,
        message: message,
    });
}
//# sourceMappingURL=BigNumberParser.js.map

/***/ }),

/***/ 7278:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(6973), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 1183:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisData = void 0;
var MoralisData = /** @class */ (function () {
    function MoralisData() {
    }
    return MoralisData;
}());
exports.MoralisData = MoralisData;
//# sourceMappingURL=MoralisData.js.map

/***/ }),

/***/ 5125:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisDataObject = void 0;
var MoralisData_1 = __webpack_require__(1183);
var MoralisDataObject = /** @class */ (function (_super) {
    __extends(MoralisDataObject, _super);
    function MoralisDataObject() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return MoralisDataObject;
}(MoralisData_1.MoralisData));
exports.MoralisDataObject = MoralisDataObject;
//# sourceMappingURL=MoralisObjectData.js.map

/***/ }),

/***/ 5905:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(1183), exports);
__exportStar(__webpack_require__(5125), exports);
__exportStar(__webpack_require__(4612), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 4612:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 1578:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dateInputToDate = void 0;
var dateInputToDate = function (value) { return (typeof value === 'string' ? new Date(value) : value); };
exports.dateInputToDate = dateInputToDate;
//# sourceMappingURL=date.js.map

/***/ }),

/***/ 3610:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(5905), exports);
__exportStar(__webpack_require__(7278), exports);
__exportStar(__webpack_require__(1578), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9126:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.isTest = void 0;
/**
 * @returns true if the current process is running in a test environment.
 */
var isTest = function () {
    var _a;
    if (typeof process !== 'undefined') {
        return ((_a = process.env) === null || _a === void 0 ? void 0 : "production") === 'test';
    }
    return false;
};
exports.isTest = isTest;
//# sourceMappingURL=isTest.js.map

/***/ }),

/***/ 4243:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var MoralisCore_1 = __webpack_require__(478);
__exportStar(__webpack_require__(478), exports);
__exportStar(__webpack_require__(2481), exports);
__exportStar(__webpack_require__(8624), exports);
__exportStar(__webpack_require__(2882), exports);
__exportStar(__webpack_require__(3503), exports);
__exportStar(__webpack_require__(9954), exports);
__exportStar(__webpack_require__(3610), exports);
__exportStar(__webpack_require__(1757), exports);
__exportStar(__webpack_require__(7410), exports);
__exportStar(__webpack_require__(9954), exports);
exports["default"] = MoralisCore_1.MoralisCore;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7410:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(3779), exports);
__exportStar(__webpack_require__(7257), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7257:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.maybe = void 0;
function maybe(value, transform) {
    if (value == null) {
        return undefined;
    }
    if (transform) {
        return transform(value);
    }
    return value;
}
exports.maybe = maybe;
//# sourceMappingURL=maybe.js.map

/***/ }),

/***/ 3112:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.noop = void 0;
/**
 * Empty (no operation) function.
 */
// eslint-disable-next-line @typescript-eslint/no-empty-function
var noop = function () { };
exports.noop = noop;
//# sourceMappingURL=noop.js.map

/***/ }),

/***/ 3779:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.toCamelCase = void 0;
var toCamel = function (value) {
    return value.replace(/([-_][a-z])/gi, function ($1) {
        return $1.toUpperCase().replace('-', '').replace('_', '');
    });
};
var isObject = function (o) {
    return o === Object(o) && !Array.isArray(o) && typeof o !== 'function';
};
var toCamelCase = function (data) {
    if (isObject(data)) {
        var n_1 = {};
        Object.keys(data).forEach(function (k) {
            // @ts-ignore TODO: fix typing
            n_1[toCamel(k)] = (0, exports.toCamelCase)(data[k]);
        });
        return n_1;
    }
    if (Array.isArray(data)) {
        // @ts-ignore TODO: difficult to type with recursive arrays
        return data.map(function (i) {
            return (0, exports.toCamelCase)(i);
        });
    }
    return data;
};
exports.toCamelCase = toCamelCase;
//# sourceMappingURL=toCamelCase.js.map

/***/ }),

/***/ 717:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LIB_VERSION = void 0;
exports.LIB_VERSION = "2.7.4";
//# sourceMappingURL=version.js.map

/***/ }),

/***/ 9769:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisEvmApi = void 0;
var core_1 = __webpack_require__(4243);
var token_1 = __webpack_require__(6639);
var defi_1 = __webpack_require__(9544);
var resolve_1 = __webpack_require__(4717);
var block_1 = __webpack_require__(4128);
var ipfs_1 = __webpack_require__(8876);
var EvmApiConfigSetup_1 = __webpack_require__(9001);
var api_utils_1 = __webpack_require__(3520);
var utils_1 = __webpack_require__(7023);
var nft_1 = __webpack_require__(8310);
var events_1 = __webpack_require__(6970);
var transaction_1 = __webpack_require__(5747);
var balance_1 = __webpack_require__(6629);
var BASE_URL = 'https://deep-index.moralis.io/api/v2';
var MoralisEvmApi = /** @class */ (function (_super) {
    __extends(MoralisEvmApi, _super);
    function MoralisEvmApi(core) {
        var _this = _super.call(this, MoralisEvmApi.moduleName, core, BASE_URL) || this;
        _this.endpoints = new api_utils_1.Endpoints(_this.core, BASE_URL);
        _this.nft = {
            getNFTTransfersByBlock: _this.endpoints.createPaginatedFetcher(nft_1.getNFTTransfersByBlock),
            getWalletNFTs: _this.endpoints.createPaginatedFetcher(nft_1.getWalletNFTs),
            getWalletNFTTransfers: _this.endpoints.createPaginatedFetcher(nft_1.getWalletNFTTransfers),
            getNFTTrades: _this.endpoints.createPaginatedFetcher(nft_1.getNFTTrades),
            getNFTLowestPrice: _this.endpoints.createNullableFetcher(nft_1.getNFTLowestPrice),
            searchNFTs: _this.endpoints.createPaginatedFetcher(nft_1.searchNFTs),
            getNFTTransfersFromToBlock: _this.endpoints.createPaginatedFetcher(nft_1.getNFTTransfersFromToBlock),
            getContractNFTs: _this.endpoints.createPaginatedFetcher(nft_1.getContractNFTs),
            getNFTOwners: _this.endpoints.createPaginatedFetcher(nft_1.getNFTOwners),
            getNFTContractMetadata: _this.endpoints.createNullableFetcher(nft_1.getNFTContractMetadata),
            reSyncMetadata: _this.endpoints.createFetcher(nft_1.reSyncMetadata),
            getNFTMetadata: _this.endpoints.createNullableFetcher(nft_1.getNFTMetadata),
            getNFTTokenIdOwners: _this.endpoints.createPaginatedFetcher(nft_1.getNFTTokenIdOwners),
            getNFTTransfers: _this.endpoints.createPaginatedFetcher(nft_1.getNFTTransfers),
            syncNFTContract: _this.endpoints.createFetcher(nft_1.syncNFTContract),
            getNFTContractTransfers: _this.endpoints.createPaginatedFetcher(nft_1.getNFTContractTransfers),
            getWalletNFTCollections: _this.endpoints.createPaginatedFetcher(nft_1.getWalletNFTCollections),
        };
        _this._token = {
            getTokenTransfers: _this.endpoints.createPaginatedFetcher(token_1.getTokenTransfers),
        };
        _this.token = {
            getWalletTokenBalances: _this.endpoints.createFetcher(token_1.getWalletTokenBalances),
            getWalletTokenTransfers: _this.endpoints.createPaginatedFetcher(token_1.getWalletTokenTransfers),
            getTokenMetadata: _this.endpoints.createFetcher(token_1.getTokenMetadata),
            getTokenMetadataBySymbol: _this.endpoints.createFetcher(token_1.getTokenMetadataBySymbol),
            getTokenPrice: _this.endpoints.createFetcher(token_1.getTokenPrice),
            getTokenTransfers: _this._token.getTokenTransfers,
            getTokenAllowance: _this.endpoints.createFetcher(token_1.getTokenAllowance),
            /**
             * @deprecated Replaced by `nft.getContractNFTs()`.
             */
            getAllTokenIds: _this.deprecationWarning('token.getAllTokenIds', 'nft.getContractNFTs', _this.nft.getContractNFTs),
            /**
             * @deprecated Replaced by `nft.getNFTContractTransfers()`.
             */
            getContractNFTTransfers: _this.deprecationWarning('token.getContractNFTTransfers', 'nft.getNFTContractTransfers', _this.nft.getNFTContractTransfers),
            /**
             * @deprecated Replaced by `nft.getNFTLowestPrice()`.
             */
            getNFTLowestPrice: _this.deprecationWarning('token.getNFTLowestPrice', 'nft.getNFTLowestPrice', _this.nft.getNFTLowestPrice),
            /**
             * @deprecated Replaced by `nft.getNFTContractMetadata()`.
             */
            getNFTMetadata: _this.deprecationWarning('token.getNFTMetadata', 'nft.getNFTContractMetadata', _this.nft.getNFTContractMetadata),
            /**
             * @deprecated Replaced by `nft.getNFTOwners()`.
             */
            getNFTOwners: _this.deprecationWarning('token.getNFTOwners', 'nft.getNFTOwners', _this.nft.getNFTOwners),
            /**
             * @deprecated Replaced by `nft.getNFTTrades()`.
             */
            getNFTTrades: _this.deprecationWarning('token.getNFTTrades', 'nft.getNFTTrades', _this.nft.getNFTTrades),
            /**
             * @deprecated Replaced by `nft.getNFTTransfersFromToBlock()`.
             */
            getNftTransfersFromToBlock: _this.deprecationWarning('token.getNftTransfersFromToBlock', 'nft.getNFTTransfersFromToBlock', _this.nft.getNFTTransfersFromToBlock),
            /**
             * @deprecated Replaced by `token.getTokenTransfers()`.
             */
            getTokenAddressTransfers: _this.deprecationWarning('token.getTokenAddressTransfers', 'token.getTokenTransfers', _this._token.getTokenTransfers),
            /**
             * @deprecated Replaced by `nft.getNFTMetadata()`.
             */
            getTokenIdMetadata: _this.deprecationWarning('token.getTokenIdMetadata', 'nft.getNFTMetadata', _this.nft.getNFTMetadata),
            /**
             * @deprecated Replaced by `nft.getNFTTokenIdOwners()`.
             */
            getTokenIdOwners: _this.deprecationWarning('token.getTokenIdOwners', 'nft.getNFTTokenIdOwners', _this.nft.getNFTTokenIdOwners),
            /**
             * @deprecated Replaced by `nft.getNFTTransfers()`.
             */
            getWalletTokenIdTransfers: _this.deprecationWarning('token.getWalletTokenIdTransfers', 'nft.getNFTTransfers', _this.nft.getNFTTransfers),
            /**
             * @deprecated Replaced by `nft.reSyncMetadata()`.
             */
            reSyncMetadata: _this.deprecationWarning('token.reSyncMetadata', 'nft.reSyncMetadata', _this.nft.reSyncMetadata),
            /**
             * @deprecated Replaced by `nft.searchNFTs()`.
             */
            searchNFTs: _this.deprecationWarning('token.searchNFTs', 'nft.searchNFTs', _this.nft.searchNFTs),
            /**
             * @deprecated Replaced by `nft.syncNFTContract()`.
             */
            syncNFTContract: _this.deprecationWarning('token.syncNFTContract', 'nft.syncNFTContract', _this.nft.syncNFTContract),
        };
        /**
         * @deprecated This property will be removed soon.
         */
        _this.contract = {
            /**
             * @deprecated Replaced by `nft.syncNFTContract()`.
             */
            syncNFTContract: _this.deprecationWarning('token.syncNFTContract', 'nft.syncNFTContract', _this.nft.syncNFTContract),
        };
        _this.defi = {
            getPairAddress: _this.endpoints.createFetcher(defi_1.getPairAddress),
            getPairReserves: _this.endpoints.createFetcher(defi_1.getPairReserves),
        };
        _this.events = {
            getContractEvents: _this.endpoints.createPaginatedFetcher(events_1.getContractEvents),
            getContractLogs: _this.endpoints.createPaginatedFetcher(events_1.getContractLogs),
        };
        _this.transaction = {
            getTransaction: _this.endpoints.createNullableFetcher(transaction_1.getTransaction),
            getWalletTransactions: _this.endpoints.createPaginatedFetcher(transaction_1.getWalletTransactions),
        };
        _this.balance = {
            getNativeBalance: _this.endpoints.createFetcher(balance_1.getNativeBalance),
        };
        /**
         * @deprecated This property will be removed soon.
         */
        _this.account = {
            /**
             * @deprecated Replaced by `balance.getNativeBalance()`.
             */
            getNativeBalance: _this.deprecationWarning('account.getNativeBalance', 'balance.getNativeBalance', _this.balance.getNativeBalance),
            /**
             * @deprecated Replaced by `nft.getWalletNFTs()`.
             */
            getNFTs: _this.deprecationWarning('account.getNFTs', 'nft.getWalletNFTs', _this.nft.getWalletNFTs),
            /**
             * @deprecated Replaced by `nft.getWalletNFTs()`. Same func as `getWalletNFTs()`.
             */
            getNFTsForContract: _this.deprecationWarning('account.getNFTsForContract', 'nft.getWalletNFTs', _this.nft.getWalletNFTs),
            /**
             * @deprecated Replaced by `nft.getWalletNFTTransfers()`.
             */
            getNFTTransfers: _this.deprecationWarning('account.getNFTTransfers', 'nft.getWalletNFTTransfers', _this.nft.getWalletNFTTransfers),
            /**
             * @deprecated Replaced by `token.getWalletTokenBalances()`.
             */
            getTokenBalances: _this.deprecationWarning('account.getTokenBalances', 'token.getWalletTokenBalances', _this.token.getWalletTokenBalances),
            /**
             * @deprecated Replaced by `token.getWalletTokenTransfers()`.
             */
            getTokenTransfers: _this.deprecationWarning('account.getTokenTransfers', 'token.getWalletTokenTransfers', _this.token.getWalletTokenTransfers),
            /**
             * @deprecated Replaced by `transaction.getWalletTransactions()`.
             */
            getTransactions: _this.deprecationWarning('account.getTransactions', 'transaction.getWalletTransactions', _this.transaction.getWalletTransactions),
            /**
             * @deprecated Replaced by `transaction.getWalletTransactions()`.
             */
            getWalletNFTCollections: _this.deprecationWarning('account.getWalletNFTCollections', 'nft.getWalletNFTCollections', _this.nft.getWalletNFTCollections),
        };
        _this.block = {
            getBlock: _this.endpoints.createNullableFetcher(block_1.getBlock),
            getDateToBlock: _this.endpoints.createFetcher(block_1.getDateToBlock),
        };
        _this.resolve = {
            resolveAddress: _this.endpoints.createNullableFetcher(resolve_1.resolveAddress),
            resolveDomain: _this.endpoints.createNullableFetcher(resolve_1.resolveDomain),
        };
        _this.ipfs = {
            uploadFolder: _this.endpoints.createFetcher(ipfs_1.uploadFolder),
        };
        /**
         * @deprecated This property will be removed soon.
         */
        _this.storage = {
            /**
             * @deprecated Replaced by `storage.uploadFolder()`.
             */
            uploadFolder: _this.deprecationWarning('storage.uploadFolder', 'ipfs.uploadFolder', _this.ipfs.uploadFolder),
        };
        _this._utils = {
            endpointWeights: _this.endpoints.createFetcher(utils_1.endpointWeights),
            web3ApiVersion: _this.endpoints.createFetcher(utils_1.web3ApiVersion),
        };
        _this.utils = {
            runContractFunction: _this.endpoints.createFetcher(utils_1.runContractFunction),
            web3ApiVersion: function () { return _this._utils.web3ApiVersion({}); },
            endpointWeights: function () { return _this._utils.endpointWeights({}); },
        };
        /**
         * @deprecated This property will be removed soon.
         */
        _this.native = {
            /**
             * @deprecated Replaced by `block.getDateToBlock()`.
             */
            getDateToBlock: _this.deprecationWarning('native.getDateToBlock', 'block.getDateToBlock', _this.block.getDateToBlock),
            /**
             * @deprecated Replaced by `block.getBlock()`.
             */
            getBlock: _this.deprecationWarning('native.getBlock', 'block.getBlock', _this.block.getBlock),
            /**
             * @deprecated Replaced by `events.getContractEvents()`.
             */
            getContractEvents: _this.deprecationWarning('native.getContractEvents', 'events.getContractEvents', _this.events.getContractEvents),
            /**
             * @deprecated Replaced by `events.getContractLogs()`.
             */
            getLogsByAddress: _this.deprecationWarning('native.getLogsByAddress', 'events.getContractLogs', _this.events.getContractLogs),
            /**
             * @deprecated Replaced by `nft.getNFTTransfersByBlock()`.
             */
            getNFTTransfersByBlock: _this.deprecationWarning('native.getNFTTransfersByBlock', 'nft.getNFTTransfersByBlock', _this.nft.getNFTTransfersByBlock),
            /**
             * @deprecated Replaced by `transaction.getTransaction()`.
             */
            getTransaction: _this.deprecationWarning('native.getTransaction', 'transaction.getTransaction', _this.transaction.getTransaction),
            /**
             * @deprecated Replaced by `utils.runContractFunction()`.
             */
            runContractFunction: _this.deprecationWarning('native.runContractFunction', 'utils.runContractFunction', _this.utils.runContractFunction),
        };
        /**
         * @deprecated This property will be removed soon.
         */
        _this.info = {
            /**
             * @deprecated Replaced by `utils.endpointWeights()`.
             */
            endpointWeights: function (_params) {
                return _this.deprecationWarning('info.endpointWeights', 'utils.endpointWeights', _this._utils.endpointWeights)({});
            },
            /**
             * @deprecated Replaced by `utils.web3ApiVersion()`.
             */
            web3ApiVersion: function (_params) {
                return _this.deprecationWarning('info.web3ApiVersion', 'utils.web3ApiVersion', _this._utils.web3ApiVersion)({});
            },
        };
        return _this;
    }
    MoralisEvmApi.create = function (core) {
        return new MoralisEvmApi(core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault());
    };
    MoralisEvmApi.prototype.setup = function () {
        EvmApiConfigSetup_1.EvmApiConfigSetup.register(this.core.config);
    };
    MoralisEvmApi.prototype.start = function () {
        // Nothing
    };
    MoralisEvmApi.prototype.deprecationWarning = function (oldName, newName, fetcher) {
        var _this = this;
        return function (params) {
            _this.logger.warn("".concat(oldName, "() is depreciated and will be removed soon. Please use ").concat(newName, "()"));
            return fetcher(params);
        };
    };
    MoralisEvmApi.moduleName = 'evmApi';
    return MoralisEvmApi;
}(core_1.ApiModule));
exports.MoralisEvmApi = MoralisEvmApi;
//# sourceMappingURL=EvmApi.js.map

/***/ }),

/***/ 8078:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmApiConfig = void 0;
exports.EvmApiConfig = {
    defaultEvmApiChain: {
        name: 'defaultEvmApiChain',
        defaultValue: '0x1',
    },
};
//# sourceMappingURL=EvmApiConfig.js.map

/***/ }),

/***/ 9001:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmApiConfigSetup = void 0;
var EvmApiConfig_1 = __webpack_require__(8078);
var EvmApiConfigSetup = /** @class */ (function () {
    function EvmApiConfigSetup() {
    }
    EvmApiConfigSetup.register = function (config) {
        config.registerKey(EvmApiConfig_1.EvmApiConfig.defaultEvmApiChain);
    };
    return EvmApiConfigSetup;
}());
exports.EvmApiConfigSetup = EvmApiConfigSetup;
//# sourceMappingURL=EvmApiConfigSetup.js.map

/***/ }),

/***/ 7268:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var EvmApi_1 = __webpack_require__(9769);
__exportStar(__webpack_require__(9769), exports);
exports["default"] = EvmApi_1.MoralisEvmApi;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 435:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmChainResolver = void 0;
var evm_utils_1 = __webpack_require__(9977);
var EvmApiConfig_1 = __webpack_require__(8078);
var EvmChainResolver = /** @class */ (function () {
    function EvmChainResolver() {
    }
    EvmChainResolver.resolve = function (chain, core) {
        if (chain) {
            return evm_utils_1.EvmChain.create(chain, core);
        }
        var defaultEvmChain = core.config.get(EvmApiConfig_1.EvmApiConfig.defaultEvmApiChain);
        return evm_utils_1.EvmChain.create(defaultEvmChain, core);
    };
    return EvmChainResolver;
}());
exports.EvmChainResolver = EvmChainResolver;
//# sourceMappingURL=EvmChainResolver.js.map

/***/ }),

/***/ 1380:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNativeBalance = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNativeBalance = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getNativeBalance',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/balance"); },
        apiToResult: function (data) { return ({
            balance: evm_utils_1.EvmNative.create(data.balance, 'wei'),
        }); },
        resultToJson: function (data) { return ({
            balance: data.balance.format(),
        }); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
            to_block: params.toBlock,
            providerUrl: params.providerUrl,
        }); },
    });
});
//# sourceMappingURL=getNativeBalance.js.map

/***/ }),

/***/ 6629:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNativeBalance = void 0;
var getNativeBalance_1 = __webpack_require__(1380);
Object.defineProperty(exports, "getNativeBalance", ({ enumerable: true, get: function () { return getNativeBalance_1.getNativeBalance; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7422:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getBlock = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
var apiToResult = function (core, apiData, params) {
    var _a;
    var data = (0, core_1.toCamelCase)(apiData);
    return evm_utils_1.EvmBlock.create(__assign(__assign({}, data), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), transactions: ((_a = data.transactions) !== null && _a !== void 0 ? _a : []).map(function (transaction) {
            var _a;
            return evm_utils_1.EvmTransaction.create({
                cumulativeGasUsed: transaction.receiptCumulativeGasUsed,
                gasPrice: transaction.gasPrice,
                gasUsed: transaction.receiptGasUsed,
                index: transaction.transactionIndex,
                contractAddress: transaction.receiptContractAddress,
                receiptRoot: transaction.receiptRoot,
                receiptStatus: +transaction.receiptStatus,
                chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                data: transaction.input,
                from: transaction.fromAddress,
                hash: transaction.hash,
                nonce: transaction.nonce,
                value: transaction.value,
                blockHash: transaction.blockHash,
                blockNumber: +transaction.blockNumber,
                blockTimestamp: new Date(transaction.blockTimestamp),
                gas: transaction.gas,
                to: transaction.toAddress,
                logs: ((_a = transaction.logs) !== null && _a !== void 0 ? _a : []).map(function (log) {
                    return evm_utils_1.EvmTransactionLog.create({
                        address: log.address,
                        blockHash: log.block_hash,
                        blockNumber: +log.block_number,
                        data: log.data,
                        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                        topics: [log.topic0, log.topic1, log.topic2, log.topic3],
                        transactionHash: log.transaction_hash,
                        blockTimestamp: log.block_timestamp,
                        logIndex: +log.log_index,
                        transactionIndex: +log.transaction_index,
                        chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    });
                }),
            }, core);
        }) }), core);
};
exports.getBlock = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getBlock',
        urlParams: ['blockNumberOrHash'],
        getUrl: function (params) { return "/block/".concat(params.blockNumberOrHash); },
        apiToResult: function (result, params) {
            return apiToResult(core, result, params);
        },
        resultToJson: function (data) { return data.toJSON(); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            block_number_or_hash: params.blockNumberOrHash,
            subdomain: params.subdomain,
        }); },
    });
});
//# sourceMappingURL=getBlock.js.map

/***/ }),

/***/ 9243:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getDateToBlock = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getDateToBlock = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getDateToBlock',
        getUrl: function () { return "/dateToBlock"; },
        apiToResult: function (data) { return (__assign(__assign({}, data), { date: new Date(data.date) })); },
        resultToJson: function (data) { return (__assign(__assign({}, data), { date: (0, core_1.dateInputToDate)(data.date) })); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            date: params.date,
        }); },
    });
});
//# sourceMappingURL=getDateToBlock.js.map

/***/ }),

/***/ 4128:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getDateToBlock = exports.getBlock = void 0;
var getBlock_1 = __webpack_require__(7422);
Object.defineProperty(exports, "getBlock", ({ enumerable: true, get: function () { return getBlock_1.getBlock; } }));
var getDateToBlock_1 = __webpack_require__(9243);
Object.defineProperty(exports, "getDateToBlock", ({ enumerable: true, get: function () { return getDateToBlock_1.getDateToBlock; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 3589:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getPairAddress = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getPairAddress = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getPairAddress',
        urlParams: ['token0Address', 'token1Address'],
        getUrl: function (params) { return "/".concat(params.token0Address, "/").concat(params.token1Address, "/pairAddress"); },
        // TODO: refactor to reduce complexity
        // eslint-disable-next-line complexity
        apiToResult: function (data, params) {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3;
            return ({
                //   ApiResult types generated all come as undefined which should not be the case TODO:
                token0: {
                    token: evm_utils_1.Erc20Token.create({
                        contractAddress: ((_a = data.token0) === null || _a === void 0 ? void 0 : _a.address) ? evm_utils_1.EvmAddress.create((_b = data.token0) === null || _b === void 0 ? void 0 : _b.address) : '',
                        decimals: (_d = (_c = data.token0) === null || _c === void 0 ? void 0 : _c.decimals) !== null && _d !== void 0 ? _d : 0,
                        name: (_f = (_e = data.token0) === null || _e === void 0 ? void 0 : _e.name) !== null && _f !== void 0 ? _f : '',
                        symbol: (_h = (_g = data.token0) === null || _g === void 0 ? void 0 : _g.symbol) !== null && _h !== void 0 ? _h : '',
                        logo: (_j = data.token0) === null || _j === void 0 ? void 0 : _j.logo,
                        thumbnail: (_k = data.token0) === null || _k === void 0 ? void 0 : _k.thumbnail,
                        chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    }, core),
                    blockNumber: (_l = data.token0) === null || _l === void 0 ? void 0 : _l.block_number,
                    validated: (_m = data.token0) === null || _m === void 0 ? void 0 : _m.validated,
                    createdAt: ((_o = data.token0) === null || _o === void 0 ? void 0 : _o.created_at) ? new Date((_p = data.token0) === null || _p === void 0 ? void 0 : _p.created_at) : undefined,
                },
                token1: {
                    token: evm_utils_1.Erc20Token.create({
                        contractAddress: ((_q = data.token0) === null || _q === void 0 ? void 0 : _q.address) ? evm_utils_1.EvmAddress.create((_r = data.token0) === null || _r === void 0 ? void 0 : _r.address, core) : '',
                        decimals: (_t = (_s = data.token1) === null || _s === void 0 ? void 0 : _s.decimals) !== null && _t !== void 0 ? _t : 0,
                        name: (_v = (_u = data.token1) === null || _u === void 0 ? void 0 : _u.name) !== null && _v !== void 0 ? _v : '',
                        symbol: (_x = (_w = data.token1) === null || _w === void 0 ? void 0 : _w.symbol) !== null && _x !== void 0 ? _x : '',
                        logo: (_y = data.token1) === null || _y === void 0 ? void 0 : _y.logo,
                        thumbnail: (_z = data.token1) === null || _z === void 0 ? void 0 : _z.thumbnail,
                        chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    }, core),
                    blockNumber: (_0 = data.token1) === null || _0 === void 0 ? void 0 : _0.block_number,
                    validated: (_1 = data.token1) === null || _1 === void 0 ? void 0 : _1.validated,
                    createdAt: ((_2 = data.token1) === null || _2 === void 0 ? void 0 : _2.created_at) ? new Date((_3 = data.token1) === null || _3 === void 0 ? void 0 : _3.created_at) : undefined,
                },
                pairAddress: data.pairAddress ? evm_utils_1.EvmAddress.create(data.pairAddress) : undefined,
            });
        },
        resultToJson: function (data) { return (__assign(__assign({}, data), { token0: __assign(__assign({}, data.token0), { token: data.token0.token.toJSON() }), token1: __assign(__assign({}, data.token1), { token: data.token1.token.toJSON() }), pairAddress: data.pairAddress ? data.pairAddress.format() : undefined })); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            token0_address: evm_utils_1.EvmAddress.create(params.token0Address, core).lowercase,
            token1_address: evm_utils_1.EvmAddress.create(params.token1Address, core).lowercase,
            exchange: params.exchange,
            to_block: params.toBlock,
            to_date: params.toDate,
        }); },
    });
});
//# sourceMappingURL=getPairAddress.js.map

/***/ }),

/***/ 9727:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getPairReserves = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getPairReserves = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getPairReserves',
        urlParams: ['pairAddress'],
        getUrl: function (params) { return "/".concat(params.pairAddress, "/reserves"); },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            pair_address: evm_utils_1.EvmAddress.create(params.pairAddress, core).lowercase,
            provider_url: params.providerUrl,
            to_block: params.toBlock,
            to_date: params.toDate,
        }); },
    });
});
//# sourceMappingURL=getPairReserves.js.map

/***/ }),

/***/ 9544:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getPairAddress = exports.getPairReserves = void 0;
var getPairReserves_1 = __webpack_require__(9727);
Object.defineProperty(exports, "getPairReserves", ({ enumerable: true, get: function () { return getPairReserves_1.getPairReserves; } }));
var getPairAddress_1 = __webpack_require__(3589);
Object.defineProperty(exports, "getPairAddress", ({ enumerable: true, get: function () { return getPairAddress_1.getPairAddress; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 1308:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getContractEvents = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
var method = 'post';
var bodyParams = ['abi'];
exports.getContractEvents = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getContractEvents',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/events"); },
        apiToResult: function (data, params) {
            var _a, _b;
            return (_b = ((_a = data.result) !== null && _a !== void 0 ? _a : [])) === null || _b === void 0 ? void 0 : _b.map(function (event) {
                return evm_utils_1.EvmEvent.create({
                    chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    address: params.address,
                    blockHash: event.block_hash,
                    blockNumber: event.block_number,
                    blockTimestamp: event.block_timestamp,
                    transactionHash: event.transaction_hash,
                    data: {
                        to: event.data.to,
                        from: event.data.from,
                        value: event.data.value,
                    },
                }, core);
            });
        },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            from_block: params.fromBlock,
            to_block: params.toBlock,
            from_date: params.fromDate,
            to_date: params.toDate,
            providerUrl: params.providerUrl,
            topic: params.topic,
            limit: params.limit,
            offset: params.offset,
            subdomain: params.subdomain,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
            abi: params.abi,
        }); },
        method: method,
        bodyParams: bodyParams,
        bodyType: api_utils_1.EndpointBodyType.BODY,
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getContractEvents.js.map

/***/ }),

/***/ 3060:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getContractLogs = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getContractLogs = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getContractLogs',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/logs"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (log) {
                return evm_utils_1.EvmTransactionLog.create(__assign(__assign({}, (0, core_1.toCamelCase)(log)), { 
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    topics: [log.topic0, log.topic1, log.topic2, log.topic3], blockNumber: Number(log.block_number), chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core) }), core);
            });
        },
        resultToJson: function (data) { return data.map(function (log) { return log.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { block_number: params.blockNumber, from_block: params.fromBlock, to_block: params.toBlock, from_date: params.fromDate, to_date: params.toDate, chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase })); },
    });
});
//# sourceMappingURL=getContractLogs.js.map

/***/ }),

/***/ 6970:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getContractLogs = exports.getContractEvents = void 0;
var getContractEvents_1 = __webpack_require__(1308);
Object.defineProperty(exports, "getContractEvents", ({ enumerable: true, get: function () { return getContractEvents_1.getContractEvents; } }));
var getContractLogs_1 = __webpack_require__(3060);
Object.defineProperty(exports, "getContractLogs", ({ enumerable: true, get: function () { return getContractLogs_1.getContractLogs; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 8876:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.uploadFolder = void 0;
var uploadFolder_1 = __webpack_require__(6985);
Object.defineProperty(exports, "uploadFolder", ({ enumerable: true, get: function () { return uploadFolder_1.uploadFolder; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6985:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.uploadFolder = void 0;
var api_utils_1 = __webpack_require__(3520);
var method = 'post';
var bodyParams = ['abi'];
exports.uploadFolder = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: 'uploadFolder',
        getUrl: function () { return "/ipfs/uploadFolder"; },
        apiToResult: function (data) {
            return data;
        },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return (__assign({}, params)); },
        method: method,
        bodyParams: bodyParams,
        bodyType: api_utils_1.EndpointBodyType.BODY,
    });
});
//# sourceMappingURL=uploadFolder.js.map

/***/ }),

/***/ 3731:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getContractNFTs = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getContractNFTs = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getContractNFTs',
        urlParams: ['address'],
        getUrl: function (params) { return "/nft/".concat(params.address); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (nft) {
                return evm_utils_1.EvmNft.create(__assign(__assign({}, (0, core_1.toCamelCase)(nft)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), ownerOf: nft.owner_of ? evm_utils_1.EvmAddress.create(nft.owner_of, core) : undefined, lastMetadataSync: nft.last_metadata_sync ? new Date(nft.last_metadata_sync) : undefined, lastTokenUriSync: nft.last_token_uri_sync ? new Date(nft.last_token_uri_sync) : undefined }), core);
            });
        },
        resultToJson: function (data) { return data.map(function (nft) { return nft.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getContractNFTs.js.map

/***/ }),

/***/ 1127:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTContractMetadata = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTContractMetadata = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getNFTContractMetadata',
        urlParams: ['address'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/metadata"); },
        apiToResult: function (data, params) {
            return evm_utils_1.EvmNftMetadata.create(__assign(__assign({}, (0, core_1.toCamelCase)(data)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), tokenAddress: evm_utils_1.EvmAddress.create(data.token_address, core), syncedAt: data.synced_at ? new Date(data.synced_at) : null, contractType: (0, core_1.maybe)(data.contract_type) }));
        },
        resultToJson: function (data) { return data.toJSON(); },
        parseParams: function (params) { return ({
            chain: params.chain ? evm_utils_1.EvmChain.create(params.chain, core).apiHex : undefined,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
        }); },
    });
});
//# sourceMappingURL=getNFTContractMetadata.js.map

/***/ }),

/***/ 9211:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTContractTransfers = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTContractTransfers = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getNFTContractTransfers',
        urlParams: ['address'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/transfers"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transfer) {
                return evm_utils_1.EvmNftTransfer.create(__assign(__assign({}, (0, core_1.toCamelCase)(transfer)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), tokenAddress: evm_utils_1.EvmAddress.create(transfer.to_address), toAddress: evm_utils_1.EvmAddress.create(transfer.to_address), operator: transfer.operator ? evm_utils_1.EvmAddress.create(transfer.operator) : null, fromAddress: transfer.from_address ? evm_utils_1.EvmAddress.create(transfer.from_address) : null, value: transfer.value ? evm_utils_1.EvmNative.create(transfer.value) : null, blockTimestamp: new Date(transfer.block_timestamp) }));
            });
        },
        resultToJson: function (data) { return data.map(function (transfer) { return transfer.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getNFTContractTransfers.js.map

/***/ }),

/***/ 8560:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTLowestPrice = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTLowestPrice = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getNFTLowestPrice',
        urlParams: ['address'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/lowestprice"); },
        apiToResult: function (data, params) {
            return evm_utils_1.EvmNftTrade.create(__assign(__assign({}, (0, core_1.toCamelCase)(data)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), sellerAddress: evm_utils_1.EvmAddress.create(data.seller_address, core), buyerAddress: evm_utils_1.EvmAddress.create(data.buyer_address, core), marketplaceAddress: evm_utils_1.EvmAddress.create(data.marketplace_address, core), tokenAddress: evm_utils_1.EvmAddress.create(data.token_address, core), price: evm_utils_1.EvmNative.create(data.price, 'wei'), blockTimestamp: new Date(data.block_timestamp), tokenIds: data.token_ids }));
        },
        resultToJson: function (data) { return data.toJSON(); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase, provider_url: params.providerUrl })); },
    });
});
//# sourceMappingURL=getNFTLowestPrice.js.map

/***/ }),

/***/ 109:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTMetadata = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTMetadata = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getNFTMetadata',
        urlParams: ['address', 'tokenId'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/").concat(params.tokenId); },
        apiToResult: function (data, params) {
            return evm_utils_1.EvmNft.create(__assign(__assign({}, (0, core_1.toCamelCase)(data)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), ownerOf: data.owner_of ? evm_utils_1.EvmAddress.create(data.owner_of, core) : undefined, lastMetadataSync: data.last_metadata_sync ? new Date(data.last_metadata_sync) : undefined, lastTokenUriSync: data.last_token_uri_sync ? new Date(data.last_token_uri_sync) : undefined }), core);
        },
        resultToJson: function (data) { return data.toJSON(); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
            token_id: params.tokenId,
            format: params.format,
        }); },
    });
});
//# sourceMappingURL=getNFTMetadata.js.map

/***/ }),

/***/ 8549:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTOwners = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTOwners = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getNFTOwners',
        urlParams: ['address'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/owners"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (nft) {
                return evm_utils_1.EvmNft.create(__assign(__assign({}, (0, core_1.toCamelCase)(nft)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), ownerOf: evm_utils_1.EvmAddress.create(nft.owner_of, core), lastMetadataSync: new Date(nft.last_metadata_sync), lastTokenUriSync: new Date(nft.last_token_uri_sync) }), core);
            });
        },
        resultToJson: function (data) { return data === null || data === void 0 ? void 0 : data.map(function (nft) { return nft.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase })); },
    });
});
//# sourceMappingURL=getNFTOwners.js.map

/***/ }),

/***/ 9465:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTTokenIdOwners = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTTokenIdOwners = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getNFTTokenIdOwners',
        urlParams: ['address', 'tokenId'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/").concat(params.tokenId, "/owners"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (nft) {
                return evm_utils_1.EvmNft.create(__assign(__assign({}, (0, core_1.toCamelCase)(nft)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), ownerOf: evm_utils_1.EvmAddress.create(nft.owner_of, core), lastMetadataSync: new Date(nft.last_metadata_sync), lastTokenUriSync: new Date(nft.last_token_uri_sync) }));
            });
        },
        resultToJson: function (data) { return data.map(function (nft) { return nft.toJSON(); }); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
            token_id: params.tokenId,
            cursor: params.cursor,
            format: params.format,
            limit: params.limit,
        }); },
    });
});
//# sourceMappingURL=getNFTTokenIdOwners.js.map

/***/ }),

/***/ 1755:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTTrades = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTTrades = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getNFTTrades',
        urlParams: ['address'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/trades"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (trade) {
                return evm_utils_1.EvmNftTrade.create(__assign(__assign({}, (0, core_1.toCamelCase)(trade)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), sellerAddress: evm_utils_1.EvmAddress.create(trade.seller_address, core), buyerAddress: evm_utils_1.EvmAddress.create(trade.buyer_address, core), marketplaceAddress: evm_utils_1.EvmAddress.create(trade.marketplace_address, core), tokenAddress: evm_utils_1.EvmAddress.create(trade.token_address, core), price: evm_utils_1.EvmNative.create(trade.price), blockTimestamp: new Date(trade.block_timestamp), tokenIds: trade.token_ids }));
            });
        },
        resultToJson: function (data) { return data.map(function (trade) { return trade.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase, to_block: params.toBlock, from_block: params.fromBlock, from_date: params.fromDate, to_date: params.toDate, provider_url: params.providerUrl })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getNFTTrades.js.map

/***/ }),

/***/ 3204:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTTransfers = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTTransfers = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getNFTTransfers',
        urlParams: ['address', 'tokenId'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/").concat(params.tokenId, "/transfers"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transfer) {
                return evm_utils_1.EvmNftTransfer.create(__assign(__assign({}, (0, core_1.toCamelCase)(transfer)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), tokenAddress: evm_utils_1.EvmAddress.create(transfer.to_address, core), toAddress: evm_utils_1.EvmAddress.create(transfer.to_address, core), operator: transfer.operator ? evm_utils_1.EvmAddress.create(transfer.operator, core) : null, fromAddress: transfer.from_address ? evm_utils_1.EvmAddress.create(transfer.from_address, core) : null, value: transfer.value ? evm_utils_1.EvmNative.create(transfer.value) : null, blockTimestamp: new Date(transfer.block_timestamp) }));
            });
        },
        resultToJson: function (data) { return data.map(function (transfer) { return transfer.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase, token_id: params.tokenId })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getNFTTransfers.js.map

/***/ }),

/***/ 1207:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTTransfersByBlock = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTTransfersByBlock = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getNFTTransfersByBlock',
        urlParams: ['blockNumberOrHash'],
        getUrl: function (params) { return "/block/".concat(params.blockNumberOrHash, "/nft/transfers"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transfer) {
                return evm_utils_1.EvmNftTransfer.create(__assign(__assign({}, (0, core_1.toCamelCase)(transfer)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), tokenAddress: evm_utils_1.EvmAddress.create(transfer.to_address), toAddress: evm_utils_1.EvmAddress.create(transfer.to_address), operator: transfer.operator ? evm_utils_1.EvmAddress.create(transfer.operator, core) : null, fromAddress: transfer.from_address ? evm_utils_1.EvmAddress.create(transfer.from_address, core) : null, value: transfer.value ? evm_utils_1.EvmNative.create(transfer.value) : null, blockTimestamp: new Date(transfer.block_timestamp) }));
            });
        },
        resultToJson: function (data) { return data.map(function (transaction) { return transaction.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, block_number_or_hash: params.blockNumberOrHash })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getNFTTransfersByBlock.js.map

/***/ }),

/***/ 6266:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTTransfersFromToBlock = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getNFTTransfersFromToBlock = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getNFTTransfersFromToBlock',
        getUrl: function () { return "/nft/transfers"; },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transfer) {
                return evm_utils_1.EvmNftTransfer.create(__assign(__assign({}, (0, core_1.toCamelCase)(transfer)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), tokenAddress: evm_utils_1.EvmAddress.create(transfer.to_address, core), toAddress: evm_utils_1.EvmAddress.create(transfer.to_address, core), operator: transfer.operator ? evm_utils_1.EvmAddress.create(transfer.operator, core) : null, fromAddress: transfer.from_address ? evm_utils_1.EvmAddress.create(transfer.from_address, core) : null, value: transfer.value ? evm_utils_1.EvmNative.create(transfer.value) : null, blockTimestamp: new Date(transfer.block_timestamp) }));
            });
        },
        resultToJson: function (data) { return data.map(function (transfer) { return transfer.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, to_block: params.toBlock, from_block: params.fromBlock, from_date: params.fromDate, to_date: params.toDate })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getNFTTransfersFromToBlock.js.map

/***/ }),

/***/ 6592:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletNFTCollections = void 0;
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var api_utils_1 = __webpack_require__(3520);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getWalletNFTCollections = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getWalletNFTCollections',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/nft/collections"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (collection) {
                return evm_utils_1.EvmNftCollection.create(__assign(__assign({}, (0, core_1.toCamelCase)(collection)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), tokenAddress: evm_utils_1.EvmAddress.create(collection.token_address, core) }), core);
            });
        },
        resultToJson: function (data) { return data.map(function (transaction) { return transaction.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase })); },
    });
});
//# sourceMappingURL=getWalletNFTCollections.js.map

/***/ }),

/***/ 8295:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletNFTTransfers = void 0;
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var api_utils_1 = __webpack_require__(3520);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getWalletNFTTransfers = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getWalletNFTTransfers',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/nft/transfers"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transfer) {
                return evm_utils_1.EvmNftTransfer.create(__assign(__assign({}, (0, core_1.toCamelCase)(transfer)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), tokenAddress: evm_utils_1.EvmAddress.create(transfer.token_address), toAddress: evm_utils_1.EvmAddress.create(transfer.to_address), operator: transfer.operator ? evm_utils_1.EvmAddress.create(transfer.operator, core) : null, fromAddress: transfer.from_address ? evm_utils_1.EvmAddress.create(transfer.from_address, core) : null, value: transfer.value ? evm_utils_1.EvmNative.create(transfer.value) : null, blockTimestamp: new Date(transfer.block_timestamp) }));
            });
        },
        resultToJson: function (data) { return data.map(function (transaction) { return transaction.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getWalletNFTTransfers.js.map

/***/ }),

/***/ 5025:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletNFTs = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getWalletNFTs = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getWalletNFTs',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/nft"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (nft) {
                return evm_utils_1.EvmNft.create({
                    chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    contractType: nft.contract_type,
                    tokenAddress: nft.token_address,
                    tokenId: nft.token_id,
                    tokenUri: nft.token_uri,
                    metadata: nft.metadata,
                    name: nft.name,
                    symbol: nft.symbol,
                    amount: nft.amount ? parseInt(nft.amount, 10) : undefined,
                    blockNumberMinted: nft.block_number_minted,
                    blockNumber: nft.block_number,
                    ownerOf: evm_utils_1.EvmAddress.create(nft.owner_of, core),
                    tokenHash: nft.token_hash,
                    lastMetadataSync: (0, core_1.dateInputToDate)(nft.last_metadata_sync),
                    lastTokenUriSync: (0, core_1.dateInputToDate)(nft.last_token_uri_sync),
                });
            });
        },
        resultToJson: function (data) { return data.map(function (nft) { return nft.toJSON(); }); },
        parseParams: function (params) {
            var _a;
            return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, token_addresses: (_a = params.tokenAddresses) === null || _a === void 0 ? void 0 : _a.map(function (address) { return evm_utils_1.EvmAddress.create(address, core).lowercase; }), address: evm_utils_1.EvmAddress.create(params.address, core).lowercase }));
        },
    });
});
//# sourceMappingURL=getWalletNFTs.js.map

/***/ }),

/***/ 8310:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.syncNFTContract = exports.searchNFTs = exports.reSyncMetadata = exports.getWalletNFTTransfers = exports.getWalletNFTs = exports.getWalletNFTCollections = exports.getNFTTransfersFromToBlock = exports.getNFTTransfersByBlock = exports.getNFTTransfers = exports.getNFTTrades = exports.getNFTTokenIdOwners = exports.getNFTOwners = exports.getNFTMetadata = exports.getNFTLowestPrice = exports.getNFTContractTransfers = exports.getNFTContractMetadata = exports.getContractNFTs = void 0;
var getContractNFTs_1 = __webpack_require__(3731);
Object.defineProperty(exports, "getContractNFTs", ({ enumerable: true, get: function () { return getContractNFTs_1.getContractNFTs; } }));
var getNFTContractMetadata_1 = __webpack_require__(1127);
Object.defineProperty(exports, "getNFTContractMetadata", ({ enumerable: true, get: function () { return getNFTContractMetadata_1.getNFTContractMetadata; } }));
var getNFTContractTransfers_1 = __webpack_require__(9211);
Object.defineProperty(exports, "getNFTContractTransfers", ({ enumerable: true, get: function () { return getNFTContractTransfers_1.getNFTContractTransfers; } }));
var getNFTLowestPrice_1 = __webpack_require__(8560);
Object.defineProperty(exports, "getNFTLowestPrice", ({ enumerable: true, get: function () { return getNFTLowestPrice_1.getNFTLowestPrice; } }));
var getNFTMetadata_1 = __webpack_require__(109);
Object.defineProperty(exports, "getNFTMetadata", ({ enumerable: true, get: function () { return getNFTMetadata_1.getNFTMetadata; } }));
var getNFTOwners_1 = __webpack_require__(8549);
Object.defineProperty(exports, "getNFTOwners", ({ enumerable: true, get: function () { return getNFTOwners_1.getNFTOwners; } }));
var getNFTTokenIdOwners_1 = __webpack_require__(9465);
Object.defineProperty(exports, "getNFTTokenIdOwners", ({ enumerable: true, get: function () { return getNFTTokenIdOwners_1.getNFTTokenIdOwners; } }));
var getNFTTrades_1 = __webpack_require__(1755);
Object.defineProperty(exports, "getNFTTrades", ({ enumerable: true, get: function () { return getNFTTrades_1.getNFTTrades; } }));
var getNFTTransfers_1 = __webpack_require__(3204);
Object.defineProperty(exports, "getNFTTransfers", ({ enumerable: true, get: function () { return getNFTTransfers_1.getNFTTransfers; } }));
var getNFTTransfersByBlock_1 = __webpack_require__(1207);
Object.defineProperty(exports, "getNFTTransfersByBlock", ({ enumerable: true, get: function () { return getNFTTransfersByBlock_1.getNFTTransfersByBlock; } }));
var getNFTTransfersFromToBlock_1 = __webpack_require__(6266);
Object.defineProperty(exports, "getNFTTransfersFromToBlock", ({ enumerable: true, get: function () { return getNFTTransfersFromToBlock_1.getNFTTransfersFromToBlock; } }));
var getWalletNFTCollections_1 = __webpack_require__(6592);
Object.defineProperty(exports, "getWalletNFTCollections", ({ enumerable: true, get: function () { return getWalletNFTCollections_1.getWalletNFTCollections; } }));
var getWalletNFTs_1 = __webpack_require__(5025);
Object.defineProperty(exports, "getWalletNFTs", ({ enumerable: true, get: function () { return getWalletNFTs_1.getWalletNFTs; } }));
var getWalletNFTTransfers_1 = __webpack_require__(8295);
Object.defineProperty(exports, "getWalletNFTTransfers", ({ enumerable: true, get: function () { return getWalletNFTTransfers_1.getWalletNFTTransfers; } }));
var reSyncMetadata_1 = __webpack_require__(6530);
Object.defineProperty(exports, "reSyncMetadata", ({ enumerable: true, get: function () { return reSyncMetadata_1.reSyncMetadata; } }));
var searchNFTs_1 = __webpack_require__(409);
Object.defineProperty(exports, "searchNFTs", ({ enumerable: true, get: function () { return searchNFTs_1.searchNFTs; } }));
var syncNFTContract_1 = __webpack_require__(157);
Object.defineProperty(exports, "syncNFTContract", ({ enumerable: true, get: function () { return syncNFTContract_1.syncNFTContract; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6530:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.reSyncMetadata = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.reSyncMetadata = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'reSyncMetadata',
        urlParams: ['address', 'tokenId'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/").concat(params.tokenId, "/metadata/resync"); },
        apiToResult: function (data) { return (__assign({}, data)); },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
            token_id: params.tokenId,
            flag: params.flag,
            mode: params.mode,
        }); },
    });
});
//# sourceMappingURL=reSyncMetadata.js.map

/***/ }),

/***/ 409:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.searchNFTs = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.searchNFTs = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'searchNFTs',
        getUrl: function () { return "/nft/search"; },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (nft) { return ({
                token: evm_utils_1.EvmNft.create({
                    chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    contractType: nft.contract_type,
                    tokenAddress: nft.token_address,
                    tokenId: nft.token_id,
                    tokenUri: nft.token_uri,
                    metadata: nft.metadata,
                    tokenHash: nft.token_hash,
                }, core),
                tokenHash: nft.token_hash,
                blockNumberMinted: nft.block_number_minted,
                lastMetadataSync: nft.last_metadata_sync ? new Date(nft.last_metadata_sync) : undefined,
                lastTokenUriSync: nft.last_token_uri_sync ? new Date(nft.last_token_uri_sync) : undefined,
                batchId: nft.batch_id,
                frozen: nft.frozen,
                frozenLogIndex: nft.frozen_log_index,
                imported: nft.imported,
                isValid: nft.is_valid,
                openseaLookup: nft.opensea_lookup,
                resyncing: nft.resyncing,
                syncing: nft.syncing,
                updatedAt: new Date(nft.updatedAt),
            }); });
        },
        resultToJson: function (data) {
            return data.map(function (nft) {
                var _a, _b;
                return (__assign(__assign({}, nft), { token: nft.token.toJSON(), lastMetadataSync: (_a = nft.lastMetadataSync) === null || _a === void 0 ? void 0 : _a.toLocaleDateString(), lastTokenUriSync: (_b = nft.lastTokenUriSync) === null || _b === void 0 ? void 0 : _b.toLocaleDateString(), updatedAt: nft.updatedAt.toLocaleDateString() }));
            });
        },
        parseParams: function (params) {
            var _a;
            return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, addresses: (_a = params.addresses) === null || _a === void 0 ? void 0 : _a.map(function (address) { return evm_utils_1.EvmAddress.create(address, core).lowercase; }) }));
        },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=searchNFTs.js.map

/***/ }),

/***/ 157:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.syncNFTContract = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
var method = 'put';
exports.syncNFTContract = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'syncNFTContract',
        urlParams: ['address'],
        getUrl: function (params) { return "/nft/".concat(params.address, "/sync"); },
        apiToResult: function (_) { return ({
            success: true,
        }); },
        resultToJson: function () { return ({
            success: true,
        }); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
        }); },
        method: method,
    });
});
//# sourceMappingURL=syncNFTContract.js.map

/***/ }),

/***/ 4717:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolveDomain = exports.resolveAddress = void 0;
var resolveAddress_1 = __webpack_require__(8126);
Object.defineProperty(exports, "resolveAddress", ({ enumerable: true, get: function () { return resolveAddress_1.resolveAddress; } }));
var resolveDomain_1 = __webpack_require__(4790);
Object.defineProperty(exports, "resolveDomain", ({ enumerable: true, get: function () { return resolveDomain_1.resolveDomain; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 8126:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolveAddress = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
exports.resolveAddress = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'resolveAddress',
        urlParams: ['address'],
        getUrl: function (params) { return "/resolve/".concat(params.address, "/reverse"); },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return ({
            address: params.address ? evm_utils_1.EvmAddress.create(params.address, core).lowercase : undefined,
        }); },
    });
});
//# sourceMappingURL=resolveAddress.js.map

/***/ }),

/***/ 4790:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolveDomain = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
exports.resolveDomain = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'resolveDomain',
        urlParams: ['domain'],
        getUrl: function (params) { return "/resolve/".concat(params.domain); },
        apiToResult: function (data) { return ({
            address: evm_utils_1.EvmAddress.create(data.address, core),
        }); },
        resultToJson: function (data) { return ({
            address: data.address.format(),
        }); },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=resolveDomain.js.map

/***/ }),

/***/ 8138:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokenAllowance = void 0;
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var api_utils_1 = __webpack_require__(3520);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getTokenAllowance = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getTokenAllowance',
        urlParams: ['address'],
        getUrl: function (params) { return "/erc20/".concat(params.address, "/allowance"); },
        apiToResult: function (data) { return ({
            allowance: core_1.BigNumber.create(data.allowance),
        }); },
        resultToJson: function (data) { return ({
            allowance: data.allowance.toString(),
        }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase, owner_address: evm_utils_1.EvmAddress.create(params.ownerAddress, core).lowercase, spender_address: evm_utils_1.EvmAddress.create(params.spenderAddress, core).lowercase })); },
    });
});
//# sourceMappingURL=getTokenAllowance.js.map

/***/ }),

/***/ 6004:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokenMetadata = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getTokenMetadata = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getTokenMetadata',
        getUrl: function () { return "/erc20/metadata"; },
        apiToResult: function (data, params) {
            return (data !== null && data !== void 0 ? data : []).map(function (token) {
                return {
                    token: evm_utils_1.Erc20Token.create(__assign(__assign({}, (0, core_1.toCamelCase)(token)), { contractAddress: token.address, chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core) }), core),
                    blockNumber: token.block_number,
                    validated: token.validated,
                };
            });
        },
        resultToJson: function (data) { return data.map(function (item) { return (__assign(__assign({}, item), { token: item.token.toJSON() })); }); },
        parseParams: function (params) { return ({
            providerUrl: params.providerUrl || undefined,
            subdomain: params.subdomain || undefined,
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            addresses: params.addresses.map(function (address) { return evm_utils_1.EvmAddress.create(address, core).lowercase; }),
        }); },
    });
});
//# sourceMappingURL=getTokenMetadata.js.map

/***/ }),

/***/ 5373:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokenMetadataBySymbol = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getTokenMetadataBySymbol = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getTokenMetadataBySymbol',
        getUrl: function () { return "/erc20/metadata/symbols"; },
        apiToResult: function (data, params) {
            return (data !== null && data !== void 0 ? data : []).map(function (token) {
                return {
                    token: evm_utils_1.Erc20Token.create(__assign(__assign({}, (0, core_1.toCamelCase)(token)), { contractAddress: token.address, chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core) }), core),
                    blockNumber: token.block_number,
                    validated: token.validated,
                };
            });
        },
        resultToJson: function (data) { return data.map(function (result) { return (__assign(__assign({}, result), { token: result.token.toJSON() })); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex })); },
    });
});
//# sourceMappingURL=getTokenMetadataBySymbol.js.map

/***/ }),

/***/ 525:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokenPrice = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getTokenPrice = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getTokenPrice',
        urlParams: ['address'],
        getUrl: function (params) { return "/erc20/".concat(params.address, "/price"); },
        apiToResult: function (data, _) {
            var _a, _b, _c;
            return (__assign(__assign({}, (0, core_1.toCamelCase)(data)), { nativePrice: ((_a = data.nativePrice) === null || _a === void 0 ? void 0 : _a.value)
                    ? evm_utils_1.EvmNative.create((_b = data.nativePrice) === null || _b === void 0 ? void 0 : _b.value, (_c = data.nativePrice) === null || _c === void 0 ? void 0 : _c.decimals)
                    : null, exchangeAddress: data.exchangeAddress ? evm_utils_1.EvmAddress.create(data.exchangeAddress, core) : null }));
        },
        resultToJson: function (data) { return (__assign(__assign({}, data), { exchangeAddress: data.exchangeAddress ? data.exchangeAddress.format() : null, nativePrice: data.nativePrice ? data.nativePrice.format() : null })); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
            exchange: params.exchange,
            to_block: params.toBlock,
            providerUrl: params.providerUrl,
        }); },
    });
});
//# sourceMappingURL=getTokenPrice.js.map

/***/ }),

/***/ 8771:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokenTransfers = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
// TODO: add decimals from api
exports.getTokenTransfers = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getTokenTransfers',
        urlParams: ['address'],
        getUrl: function (params) { return "/erc20/".concat(params.address, "/transfers"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transfer) {
                return evm_utils_1.Erc20Transfer.create(__assign(__assign({}, (0, core_1.toCamelCase)(transfer)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), address: evm_utils_1.EvmAddress.create(transfer.address, core), toAddress: evm_utils_1.EvmAddress.create(transfer.to_address, core), fromAddress: evm_utils_1.EvmAddress.create(transfer.from_address, core), value: core_1.BigNumber.create(transfer.value), blockTimestamp: new Date(transfer.block_timestamp) }));
            });
        },
        resultToJson: function (data) { return data.map(function (transfer) { return transfer.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase, to_block: params.toBlock, from_block: params.fromBlock, from_date: params.fromDate, to_date: params.toDate })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getTokenTransfers.js.map

/***/ }),

/***/ 204:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletTokenBalances = void 0;
var evm_utils_1 = __webpack_require__(9977);
var api_utils_1 = __webpack_require__(3520);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getWalletTokenBalances = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getWalletTokenBalances',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/erc20"); },
        apiToResult: function (data, params) {
            return (data !== null && data !== void 0 ? data : []).map(function (token) {
                return evm_utils_1.Erc20Value.create(token.balance, {
                    decimals: token.decimals,
                    token: {
                        decimals: token.decimals,
                        name: token.name,
                        symbol: token.symbol,
                        contractAddress: token.token_address,
                        logo: token.logo,
                        thumbnail: token.thumbnail,
                        chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    },
                });
            });
        },
        resultToJson: function (data) { return data.map(function (tokenValue) { return tokenValue.toJSON(); }); },
        parseParams: function (params) { return ({
            to_block: params.toBlock,
            token_addresses: params.tokenAddresses,
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
        }); },
    });
});
//# sourceMappingURL=getWalletTokenBalances.js.map

/***/ }),

/***/ 9758:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletTokenTransfers = void 0;
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var api_utils_1 = __webpack_require__(3520);
var EvmChainResolver_1 = __webpack_require__(435);
// TODO: get decimals from API, then we can add a ERC20Value instance
exports.getWalletTokenTransfers = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getWalletTokenTransfers',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/erc20/transfers"); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transfer) {
                return evm_utils_1.Erc20Transfer.create(__assign(__assign({}, (0, core_1.toCamelCase)(transfer)), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core), address: evm_utils_1.EvmAddress.create(transfer.address, core), toAddress: evm_utils_1.EvmAddress.create(transfer.to_address, core), fromAddress: evm_utils_1.EvmAddress.create(transfer.from_address, core), value: core_1.BigNumber.create(transfer.value), blockTimestamp: new Date(transfer.block_timestamp) }));
            });
        },
        resultToJson: function (data) { return data.map(function (transfer) { return transfer.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase, to_block: params.toBlock, from_block: params.fromBlock, from_date: params.fromDate, to_date: params.toDate })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getWalletTokenTransfers.js.map

/***/ }),

/***/ 6639:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletTokenBalances = exports.getWalletTokenTransfers = exports.getTokenMetadataBySymbol = exports.getTokenTransfers = exports.getTokenPrice = exports.getTokenAllowance = exports.getTokenMetadata = void 0;
var getTokenMetadata_1 = __webpack_require__(6004);
Object.defineProperty(exports, "getTokenMetadata", ({ enumerable: true, get: function () { return getTokenMetadata_1.getTokenMetadata; } }));
var getTokenAllowance_1 = __webpack_require__(8138);
Object.defineProperty(exports, "getTokenAllowance", ({ enumerable: true, get: function () { return getTokenAllowance_1.getTokenAllowance; } }));
var getTokenPrice_1 = __webpack_require__(525);
Object.defineProperty(exports, "getTokenPrice", ({ enumerable: true, get: function () { return getTokenPrice_1.getTokenPrice; } }));
var getTokenTransfers_1 = __webpack_require__(8771);
Object.defineProperty(exports, "getTokenTransfers", ({ enumerable: true, get: function () { return getTokenTransfers_1.getTokenTransfers; } }));
var getTokenMetadataBySymbol_1 = __webpack_require__(5373);
Object.defineProperty(exports, "getTokenMetadataBySymbol", ({ enumerable: true, get: function () { return getTokenMetadataBySymbol_1.getTokenMetadataBySymbol; } }));
var getWalletTokenTransfers_1 = __webpack_require__(9758);
Object.defineProperty(exports, "getWalletTokenTransfers", ({ enumerable: true, get: function () { return getWalletTokenTransfers_1.getWalletTokenTransfers; } }));
var getWalletTokenBalances_1 = __webpack_require__(204);
Object.defineProperty(exports, "getWalletTokenBalances", ({ enumerable: true, get: function () { return getWalletTokenBalances_1.getWalletTokenBalances; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 202:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTransaction = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getTransaction = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getTransaction',
        urlParams: ['transactionHash'],
        getUrl: function (params) { return "/transaction/".concat(params.transactionHash); },
        apiToResult: function (data, params) {
            var _a;
            return evm_utils_1.EvmTransaction.create({
                from: data.from_address,
                to: data.to_address,
                value: data.value,
                gasPrice: data.gas_price,
                gasUsed: data.receipt_gas_used,
                data: data.input,
                nonce: data.nonce,
                blockHash: data.block_hash,
                blockNumber: data.block_number,
                blockTimestamp: data.block_timestamp,
                index: data.transaction_index,
                chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                hash: data.hash,
                gas: data.gas,
                cumulativeGasUsed: data.receipt_cumulative_gas_used,
                contractAddress: data.receipt_contract_address,
                logs: ((_a = data.logs) !== null && _a !== void 0 ? _a : []).map(function (log) {
                    return evm_utils_1.EvmTransactionLog.create({
                        address: log.address,
                        blockHash: log.block_hash,
                        blockNumber: +log.block_number,
                        data: log.data,
                        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                        topics: [log.topic0, log.topic1, log.topic2, log.topic3],
                        transactionHash: log.transaction_hash,
                        blockTimestamp: log.block_timestamp,
                        logIndex: +log.log_index,
                        transactionIndex: +log.transaction_index,
                        chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    }, core);
                }),
                receiptRoot: data.receipt_root,
                receiptStatus: data.receipt_status,
            }, core);
        },
        resultToJson: function (data) { return data.toJSON(); },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            subdomain: params.subdomain || undefined,
            transaction_hash: params.transactionHash,
        }); },
    });
});
//# sourceMappingURL=getTransaction.js.map

/***/ }),

/***/ 4813:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletTransactions = void 0;
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var api_utils_1 = __webpack_require__(3520);
var EvmChainResolver_1 = __webpack_require__(435);
exports.getWalletTransactions = (0, api_utils_1.createPaginatedEndpointFactory)(function (core) {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: 'getWalletTransactions',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address); },
        apiToResult: function (data, params) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (transaction) {
                return evm_utils_1.EvmTransaction.create({
                    cumulativeGasUsed: transaction.receipt_cumulative_gas_used,
                    gasPrice: transaction.gas_price,
                    gasUsed: transaction.receipt_gas_used,
                    index: +transaction.transaction_index,
                    contractAddress: transaction.receipt_contract_address,
                    receiptRoot: transaction.receipt_root,
                    receiptStatus: +transaction.receipt_status,
                    chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core),
                    data: transaction.input,
                    from: transaction.from_address,
                    hash: transaction.hash,
                    nonce: transaction.nonce,
                    value: transaction.value,
                    blockHash: transaction.block_hash,
                    blockNumber: +transaction.block_number,
                    blockTimestamp: new Date(transaction.block_timestamp),
                    gas: core_1.BigNumber.create(transaction.gas),
                    to: transaction.to_address,
                });
            });
        },
        resultToJson: function (data) { return data.map(function (transaction) { return transaction.toJSON(); }); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex, address: evm_utils_1.EvmAddress.create(params.address, core).lowercase, to_block: params.toBlock, from_block: params.fromBlock, from_date: params.fromDate, to_date: params.toDate })); },
        firstPageIndex: 0,
    });
});
//# sourceMappingURL=getWalletTransactions.js.map

/***/ }),

/***/ 5747:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getWalletTransactions = exports.getTransaction = void 0;
var getTransaction_1 = __webpack_require__(202);
Object.defineProperty(exports, "getTransaction", ({ enumerable: true, get: function () { return getTransaction_1.getTransaction; } }));
var getWalletTransactions_1 = __webpack_require__(4813);
Object.defineProperty(exports, "getWalletTransactions", ({ enumerable: true, get: function () { return getWalletTransactions_1.getWalletTransactions; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2237:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.endpointWeights = void 0;
var api_utils_1 = __webpack_require__(3520);
exports.endpointWeights = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: 'endpointWeights',
        getUrl: function () { return "/info/endpointWeights"; },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=endpointWeights.js.map

/***/ }),

/***/ 7023:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.runContractFunction = exports.web3ApiVersion = exports.endpointWeights = void 0;
var endpointWeights_1 = __webpack_require__(2237);
Object.defineProperty(exports, "endpointWeights", ({ enumerable: true, get: function () { return endpointWeights_1.endpointWeights; } }));
var web3ApiVersion_1 = __webpack_require__(1078);
Object.defineProperty(exports, "web3ApiVersion", ({ enumerable: true, get: function () { return web3ApiVersion_1.web3ApiVersion; } }));
var runContractFunction_1 = __webpack_require__(8562);
Object.defineProperty(exports, "runContractFunction", ({ enumerable: true, get: function () { return runContractFunction_1.runContractFunction; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 8562:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.runContractFunction = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var EvmChainResolver_1 = __webpack_require__(435);
var method = 'post';
var bodyParams = ['abi', 'params'];
exports.runContractFunction = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'runContractFunction',
        urlParams: ['address'],
        getUrl: function (params) { return "/".concat(params.address, "/function"); },
        apiToResult: function (data) {
            return data;
        },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return ({
            chain: EvmChainResolver_1.EvmChainResolver.resolve(params.chain, core).apiHex,
            function_name: params.functionName,
            address: evm_utils_1.EvmAddress.create(params.address, core).lowercase,
            abi: params.abi,
            params: params.params,
        }); },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=runContractFunction.js.map

/***/ }),

/***/ 1078:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.web3ApiVersion = void 0;
var api_utils_1 = __webpack_require__(3520);
exports.web3ApiVersion = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: 'web3ApiVersion',
        getUrl: function () { return "/web3/version"; },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=web3ApiVersion.js.map

/***/ }),

/***/ 5438:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisEvmUtils = void 0;
var core_1 = __webpack_require__(4243);
var EvmUtilsConfigSetup_1 = __webpack_require__(1778);
var MoralisEvmUtils = /** @class */ (function (_super) {
    __extends(MoralisEvmUtils, _super);
    function MoralisEvmUtils(core) {
        return _super.call(this, MoralisEvmUtils.moduleName, core) || this;
    }
    MoralisEvmUtils.create = function (core) {
        return new MoralisEvmUtils(core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault());
    };
    MoralisEvmUtils.prototype.setup = function () {
        EvmUtilsConfigSetup_1.EvmUtilsConfigSetup.register(this.core.config);
    };
    MoralisEvmUtils.prototype.start = function () {
        // Nothing
    };
    MoralisEvmUtils.moduleName = 'evmUtils';
    return MoralisEvmUtils;
}(core_1.Module));
exports.MoralisEvmUtils = MoralisEvmUtils;
//# sourceMappingURL=MoralisEvmUtils.js.map

/***/ }),

/***/ 4362:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmUtilsConfig = void 0;
exports.EvmUtilsConfig = {
    formatEvmChainId: {
        name: 'formatEvmChainId',
        defaultValue: 'hex',
    },
    formatEvmAddress: {
        name: 'formatEvmAddress',
        defaultValue: 'lowercase',
    },
};
//# sourceMappingURL=EvmUtilsConfig.js.map

/***/ }),

/***/ 1778:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmUtilsConfigSetup = void 0;
var EvmUtilsConfig_1 = __webpack_require__(4362);
var EvmUtilsConfigSetup = /** @class */ (function () {
    function EvmUtilsConfigSetup() {
    }
    EvmUtilsConfigSetup.register = function (config) {
        config.registerKey(EvmUtilsConfig_1.EvmUtilsConfig.formatEvmAddress);
        config.registerKey(EvmUtilsConfig_1.EvmUtilsConfig.formatEvmChainId);
    };
    return EvmUtilsConfigSetup;
}());
exports.EvmUtilsConfigSetup = EvmUtilsConfigSetup;
//# sourceMappingURL=EvmUtilsConfigSetup.js.map

/***/ }),

/***/ 1385:
/***/ ((__unused_webpack_module, exports) => {


/* eslint-disable no-template-curly-in-string */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.chainList = void 0;
// Sourced from https://chainid.network/chains.json
exports.chainList = [
    {
        name: 'Ethereum Mainnet',
        chain: 'ETH',
        icon: 'ethereum',
        rpc: [
            'https://mainnet.infura.io/v3/${INFURA_API_KEY}',
            'wss://mainnet.infura.io/ws/v3/${INFURA_API_KEY}',
            'https://api.mycryptoapi.com/eth',
            'https://cloudflare-eth.com',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://ethereum.org',
        shortName: 'eth',
        chainId: 1,
        networkId: 1,
        slip44: 60,
        ens: {
            registry: '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e',
        },
        explorers: [
            {
                name: 'etherscan',
                url: 'https://etherscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Expanse Network',
        chain: 'EXP',
        rpc: ['https://node.expanse.tech'],
        faucets: [],
        nativeCurrency: {
            name: 'Expanse Network Ether',
            symbol: 'EXP',
            decimals: 18,
        },
        infoURL: 'https://expanse.tech',
        shortName: 'exp',
        chainId: 2,
        networkId: 1,
        slip44: 40,
    },
    {
        name: 'Ropsten',
        title: 'Ethereum Testnet Ropsten',
        chain: 'ETH',
        network: 'testnet',
        rpc: ['https://ropsten.infura.io/v3/${INFURA_API_KEY}', 'wss://ropsten.infura.io/ws/v3/${INFURA_API_KEY}'],
        faucets: ['http://fauceth.komputing.org?chain=3&address=${ADDRESS}', 'https://faucet.ropsten.be?${ADDRESS}'],
        nativeCurrency: {
            name: 'Ropsten Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://github.com/ethereum/ropsten',
        shortName: 'rop',
        chainId: 3,
        networkId: 3,
        ens: {
            registry: '0x112234455c3a32fd11230c42e7bccd4a84e02010',
        },
        explorers: [
            {
                name: 'etherscan',
                url: 'https://ropsten.etherscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Rinkeby',
        title: 'Ethereum Testnet Rinkeby',
        chain: 'ETH',
        network: 'testnet',
        rpc: ['https://rinkeby.infura.io/v3/${INFURA_API_KEY}', 'wss://rinkeby.infura.io/ws/v3/${INFURA_API_KEY}'],
        faucets: ['http://fauceth.komputing.org?chain=4&address=${ADDRESS}', 'https://faucet.rinkeby.io'],
        nativeCurrency: {
            name: 'Rinkeby Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://www.rinkeby.io',
        shortName: 'rin',
        chainId: 4,
        networkId: 4,
        ens: {
            registry: '0xe7410170f87102df0055eb195163a03b7f2bff4a',
        },
        explorers: [
            {
                name: 'etherscan-rinkeby',
                url: 'https://rinkeby.etherscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Görli',
        title: 'Ethereum Testnet Görli',
        chain: 'ETH',
        network: 'testnet',
        rpc: [
            'https://goerli.infura.io/v3/${INFURA_API_KEY}',
            'wss://goerli.infura.io/v3/${INFURA_API_KEY}',
            'https://rpc.goerli.mudit.blog/',
        ],
        faucets: [
            'http://fauceth.komputing.org?chain=5&address=${ADDRESS}',
            'https://goerli-faucet.slock.it?address=${ADDRESS}',
            'https://faucet.goerli.mudit.blog',
        ],
        nativeCurrency: {
            name: 'Görli Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://goerli.net/#about',
        shortName: 'gor',
        chainId: 5,
        networkId: 5,
        ens: {
            registry: '0x112234455c3a32fd11230c42e7bccd4a84e02010',
        },
        explorers: [
            {
                name: 'etherscan-goerli',
                url: 'https://goerli.etherscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Ethereum Classic Testnet Kotti',
        chain: 'ETC',
        rpc: ['https://www.ethercluster.com/kotti'],
        faucets: [],
        nativeCurrency: {
            name: 'Kotti Ether',
            symbol: 'KOT',
            decimals: 18,
        },
        infoURL: 'https://explorer.jade.builders/?network=kotti',
        shortName: 'kot',
        chainId: 6,
        networkId: 6,
    },
    {
        name: 'ThaiChain',
        chain: 'TCH',
        rpc: ['https://rpc.dome.cloud'],
        faucets: [],
        nativeCurrency: {
            name: 'ThaiChain Ether',
            symbol: 'TCH',
            decimals: 18,
        },
        infoURL: 'https://thaichain.io',
        shortName: 'tch',
        chainId: 7,
        networkId: 7,
    },
    {
        name: 'Ubiq',
        chain: 'UBQ',
        rpc: ['https://rpc.octano.dev', 'https://pyrus2.ubiqscan.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Ubiq Ether',
            symbol: 'UBQ',
            decimals: 18,
        },
        infoURL: 'https://ubiqsmart.com',
        shortName: 'ubq',
        chainId: 8,
        networkId: 8,
        slip44: 108,
        explorers: [
            {
                name: 'ubiqscan',
                url: 'https://ubiqscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Ubiq Network Testnet',
        chain: 'UBQ',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Ubiq Testnet Ether',
            symbol: 'TUBQ',
            decimals: 18,
        },
        infoURL: 'https://ethersocial.org',
        shortName: 'tubq',
        chainId: 9,
        networkId: 2,
    },
    {
        name: 'Optimism',
        chain: 'ETH',
        rpc: ['https://mainnet.optimism.io/'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://optimism.io',
        shortName: 'oeth',
        chainId: 10,
        networkId: 10,
        explorers: [
            {
                name: 'etherscan',
                url: 'https://optimistic.etherscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Metadium Mainnet',
        chain: 'META',
        rpc: ['https://api.metadium.com/prod'],
        faucets: [],
        nativeCurrency: {
            name: 'Metadium Mainnet Ether',
            symbol: 'META',
            decimals: 18,
        },
        infoURL: 'https://metadium.com',
        shortName: 'meta',
        chainId: 11,
        networkId: 11,
        slip44: 916,
    },
    {
        name: 'Metadium Testnet',
        chain: 'META',
        rpc: ['https://api.metadium.com/dev'],
        faucets: [],
        nativeCurrency: {
            name: 'Metadium Testnet Ether',
            symbol: 'KAL',
            decimals: 18,
        },
        infoURL: 'https://metadium.com',
        shortName: 'kal',
        chainId: 12,
        networkId: 12,
    },
    {
        name: 'Diode Testnet Staging',
        chain: 'DIODE',
        rpc: ['https://staging.diode.io:8443/', 'wss://staging.diode.io:8443/ws'],
        faucets: [],
        nativeCurrency: {
            name: 'Staging Diodes',
            symbol: 'sDIODE',
            decimals: 18,
        },
        infoURL: 'https://diode.io/staging',
        shortName: 'dstg',
        chainId: 13,
        networkId: 13,
    },
    {
        name: 'Flare Mainnet',
        chain: 'FLR',
        icon: 'flare',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'FLR',
            symbol: 'FLR',
            decimals: 18,
        },
        infoURL: 'https://flare.xyz',
        shortName: 'flr',
        chainId: 14,
        networkId: 14,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://flare-explorer.flare.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Diode Prenet',
        chain: 'DIODE',
        rpc: ['https://prenet.diode.io:8443/', 'wss://prenet.diode.io:8443/ws'],
        faucets: [],
        nativeCurrency: {
            name: 'Diodes',
            symbol: 'DIODE',
            decimals: 18,
        },
        infoURL: 'https://diode.io/prenet',
        shortName: 'diode',
        chainId: 15,
        networkId: 15,
    },
    {
        name: 'Flare Testnet Coston',
        chain: 'FLR',
        rpc: ['https://coston-api.flare.network/ext/bc/C/rpc'],
        faucets: ['https://faucet.towolabs.com', 'https://fauceth.komputing.org?chain=16&address=${ADDRESS}'],
        nativeCurrency: {
            name: 'Coston Spark',
            symbol: 'CFLR',
            decimals: 18,
        },
        infoURL: 'https://flare.xyz',
        shortName: 'cflr',
        chainId: 16,
        networkId: 16,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://coston-explorer.flare.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'ThaiChain 2.0 ThaiFi',
        chain: 'TCH',
        rpc: ['https://rpc.thaifi.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Thaifi Ether',
            symbol: 'TFI',
            decimals: 18,
        },
        infoURL: 'https://exp.thaifi.com',
        shortName: 'tfi',
        chainId: 17,
        networkId: 17,
    },
    {
        name: 'ThunderCore Testnet',
        chain: 'TST',
        rpc: ['https://testnet-rpc.thundercore.com'],
        faucets: ['https://faucet-testnet.thundercore.com'],
        nativeCurrency: {
            name: 'ThunderCore Testnet Token',
            symbol: 'TST',
            decimals: 18,
        },
        infoURL: 'https://thundercore.com',
        shortName: 'TST',
        chainId: 18,
        networkId: 18,
        explorers: [
            {
                name: 'thundercore-blockscout-testnet',
                url: 'https://explorer-testnet.thundercore.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Songbird Canary-Network',
        chain: 'SGB',
        icon: 'songbird',
        rpc: [
            'https://songbird.towolabs.com/rpc',
            'https://sgb.ftso.com.au/ext/bc/C/rpc',
            'https://sgb.lightft.so/rpc',
            'https://sgb-rpc.ftso.eu',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Songbird',
            symbol: 'SGB',
            decimals: 18,
        },
        infoURL: 'https://flare.xyz',
        shortName: 'sgb',
        chainId: 19,
        networkId: 19,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://songbird-explorer.flare.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Elastos Smart Chain',
        chain: 'ETH',
        rpc: ['https://api.elastos.io/eth'],
        faucets: ['https://faucet.elastos.org/'],
        nativeCurrency: {
            name: 'Elastos',
            symbol: 'ELA',
            decimals: 18,
        },
        infoURL: 'https://www.elastos.org/',
        shortName: 'elaeth',
        chainId: 20,
        networkId: 20,
        explorers: [
            {
                name: 'elastos eth explorer',
                url: 'https://eth.elastos.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'ELA-ETH-Sidechain Testnet',
        chain: 'ETH',
        rpc: ['https://rpc.elaeth.io'],
        faucets: ['https://faucet.elaeth.io/'],
        nativeCurrency: {
            name: 'Elastos',
            symbol: 'tELA',
            decimals: 18,
        },
        infoURL: 'https://elaeth.io/',
        shortName: 'elaetht',
        chainId: 21,
        networkId: 21,
    },
    {
        name: 'ELA-DID-Sidechain Mainnet',
        chain: 'ETH',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Elastos',
            symbol: 'ELA',
            decimals: 18,
        },
        infoURL: 'https://www.elastos.org/',
        shortName: 'eladid',
        chainId: 22,
        networkId: 22,
    },
    {
        name: 'ELA-DID-Sidechain Testnet',
        chain: 'ETH',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Elastos',
            symbol: 'tELA',
            decimals: 18,
        },
        infoURL: 'https://elaeth.io/',
        shortName: 'eladidt',
        chainId: 23,
        networkId: 23,
    },
    {
        name: 'Dithereum Mainnet',
        chain: 'DTH',
        icon: 'dithereum',
        rpc: ['https://node-mainnet.dithereum.io'],
        faucets: ['https://faucet.dithereum.org'],
        nativeCurrency: {
            name: 'Dither',
            symbol: 'DTH',
            decimals: 18,
        },
        infoURL: 'https://dithereum.org',
        shortName: 'dthmainnet',
        chainId: 24,
        networkId: 24,
    },
    {
        name: 'Cronos Mainnet Beta',
        chain: 'CRO',
        rpc: ['https://evm.cronos.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Cronos',
            symbol: 'CRO',
            decimals: 18,
        },
        infoURL: 'https://cronos.org/',
        shortName: 'cro',
        chainId: 25,
        networkId: 25,
        explorers: [
            {
                name: 'Cronos Explorer',
                url: 'https://cronos.org/explorer',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Genesis L1 testnet',
        chain: 'genesis',
        rpc: ['https://testrpc.genesisl1.org'],
        faucets: [],
        nativeCurrency: {
            name: 'L1 testcoin',
            symbol: 'L1test',
            decimals: 18,
        },
        infoURL: 'https://www.genesisl1.com',
        shortName: 'L1test',
        chainId: 26,
        networkId: 26,
        explorers: [
            {
                name: 'Genesis L1 testnet explorer',
                url: 'https://testnet.genesisl1.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'ShibaChain',
        chain: 'SHIB',
        rpc: ['https://rpc.shibachain.net'],
        faucets: [],
        nativeCurrency: {
            name: 'SHIBA INU COIN',
            symbol: 'SHIB',
            decimals: 18,
        },
        infoURL: 'https://www.shibachain.net',
        shortName: 'shib',
        chainId: 27,
        networkId: 27,
        explorers: [
            {
                name: 'Shiba Explorer',
                url: 'https://exp.shibachain.net',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Boba Network Rinkeby Testnet',
        chain: 'ETH',
        rpc: ['https://rinkeby.boba.network/'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://boba.network',
        shortName: 'Boba Rinkeby',
        chainId: 28,
        networkId: 28,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://blockexplorer.rinkeby.boba.network',
                standard: 'none',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-4',
            bridges: [
                {
                    url: 'https://gateway.rinkeby.boba.network',
                },
            ],
        },
    },
    {
        name: 'Genesis L1',
        chain: 'genesis',
        rpc: ['https://rpc.genesisl1.org'],
        faucets: [],
        nativeCurrency: {
            name: 'L1 coin',
            symbol: 'L1',
            decimals: 18,
        },
        infoURL: 'https://www.genesisl1.com',
        shortName: 'L1',
        chainId: 29,
        networkId: 29,
        explorers: [
            {
                name: 'Genesis L1 blockchain explorer',
                url: 'https://explorer.genesisl1.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'RSK Mainnet',
        chain: 'RSK',
        rpc: ['https://public-node.rsk.co', 'https://mycrypto.rsk.co'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'RSK Mainnet Ether',
            symbol: 'RBTC',
            decimals: 18,
        },
        infoURL: 'https://rsk.co',
        shortName: 'rsk',
        chainId: 30,
        networkId: 30,
        slip44: 137,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://explorer.rsk.co',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'RSK Testnet',
        chain: 'RSK',
        rpc: ['https://public-node.testnet.rsk.co', 'https://mycrypto.testnet.rsk.co'],
        faucets: ['https://faucet.testnet.rsk.co'],
        nativeCurrency: {
            name: 'RSK Testnet Ether',
            symbol: 'tRBTC',
            decimals: 18,
        },
        infoURL: 'https://rsk.co',
        shortName: 'trsk',
        chainId: 31,
        networkId: 31,
    },
    {
        name: 'GoodData Testnet',
        chain: 'GooD',
        rpc: ['https://test2.goodata.io'],
        faucets: [],
        nativeCurrency: {
            name: 'GoodData Testnet Ether',
            symbol: 'GooD',
            decimals: 18,
        },
        infoURL: 'https://www.goodata.org',
        shortName: 'GooDT',
        chainId: 32,
        networkId: 32,
    },
    {
        name: 'GoodData Mainnet',
        chain: 'GooD',
        rpc: ['https://rpc.goodata.io'],
        faucets: [],
        nativeCurrency: {
            name: 'GoodData Mainnet Ether',
            symbol: 'GooD',
            decimals: 18,
        },
        infoURL: 'https://www.goodata.org',
        shortName: 'GooD',
        chainId: 33,
        networkId: 33,
    },
    {
        name: 'Dithereum Testnet',
        chain: 'DTH',
        icon: 'dithereum',
        rpc: ['https://node-testnet.dithereum.io'],
        faucets: ['https://faucet.dithereum.org'],
        nativeCurrency: {
            name: 'Dither',
            symbol: 'DTH',
            decimals: 18,
        },
        infoURL: 'https://dithereum.org',
        shortName: 'dth',
        chainId: 34,
        networkId: 34,
    },
    {
        name: 'TBWG Chain',
        chain: 'TBWG',
        rpc: ['https://rpc.tbwg.io'],
        faucets: [],
        nativeCurrency: {
            name: 'TBWG Ether',
            symbol: 'TBG',
            decimals: 18,
        },
        infoURL: 'https://tbwg.io',
        shortName: 'tbwg',
        chainId: 35,
        networkId: 35,
    },
    {
        name: 'Dxchain Mainnet',
        chain: 'Dxchain',
        rpc: ['https://mainnet.dxchain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Dxchain',
            symbol: 'DX',
            decimals: 18,
        },
        infoURL: 'https://www.dxchain.com/',
        shortName: 'dx',
        chainId: 36,
        networkId: 36,
    },
    {
        name: 'Valorbit',
        chain: 'VAL',
        rpc: ['https://rpc.valorbit.com/v2'],
        faucets: [],
        nativeCurrency: {
            name: 'Valorbit',
            symbol: 'VAL',
            decimals: 18,
        },
        infoURL: 'https://valorbit.com',
        shortName: 'val',
        chainId: 38,
        networkId: 38,
        slip44: 538,
    },
    {
        name: 'Telos EVM Mainnet',
        chain: 'TLOS',
        rpc: ['https://mainnet.telos.net/evm'],
        faucets: [],
        nativeCurrency: {
            name: 'Telos',
            symbol: 'TLOS',
            decimals: 18,
        },
        infoURL: 'https://telos.net',
        shortName: 'Telos EVM',
        chainId: 40,
        networkId: 40,
        explorers: [
            {
                name: 'teloscan',
                url: 'https://teloscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Telos EVM Testnet',
        chain: 'TLOS',
        rpc: ['https://testnet.telos.net/evm'],
        faucets: ['https://app.telos.net/testnet/developers'],
        nativeCurrency: {
            name: 'Telos',
            symbol: 'TLOS',
            decimals: 18,
        },
        infoURL: 'https://telos.net',
        shortName: 'Telos EVM Testnet',
        chainId: 41,
        networkId: 41,
    },
    {
        name: 'Kovan',
        title: 'Ethereum Testnet Kovan',
        chain: 'ETH',
        network: 'testnet',
        rpc: [
            'https://kovan.poa.network',
            'http://kovan.poa.network:8545',
            'https://kovan.infura.io/v3/${INFURA_API_KEY}',
            'wss://kovan.infura.io/ws/v3/${INFURA_API_KEY}',
            'ws://kovan.poa.network:8546',
        ],
        faucets: [
            'http://fauceth.komputing.org?chain=42&address=${ADDRESS}',
            'https://faucet.kovan.network',
            'https://gitter.im/kovan-testnet/faucet',
        ],
        nativeCurrency: {
            name: 'Kovan Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        explorers: [
            {
                name: 'etherscan',
                url: 'https://kovan.etherscan.io',
                standard: 'EIP3091',
            },
        ],
        infoURL: 'https://kovan-testnet.github.io/website',
        shortName: 'kov',
        chainId: 42,
        networkId: 42,
    },
    {
        name: 'Darwinia Pangolin Testnet',
        chain: 'pangolin',
        rpc: ['https://pangolin-rpc.darwinia.network'],
        faucets: ['https://docs.crab.network/dvm/wallets/dvm-metamask#apply-for-the-test-token'],
        nativeCurrency: {
            name: 'Pangolin Network Native Token”',
            symbol: 'PRING',
            decimals: 18,
        },
        infoURL: 'https://darwinia.network/',
        shortName: 'pangolin',
        chainId: 43,
        networkId: 43,
        explorers: [
            {
                name: 'subscan',
                url: 'https://pangolin.subscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Darwinia Crab Network',
        chain: 'crab',
        rpc: ['https://crab-rpc.darwinia.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Crab Network Native Token',
            symbol: 'CRAB',
            decimals: 18,
        },
        infoURL: 'https://crab.network/',
        shortName: 'crab',
        chainId: 44,
        networkId: 44,
        explorers: [
            {
                name: 'subscan',
                url: 'https://crab.subscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Darwinia Pangoro Testnet',
        chain: 'pangoro',
        rpc: ['http://pangoro-rpc.darwinia.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Pangoro Network Native Token”',
            symbol: 'ORING',
            decimals: 18,
        },
        infoURL: 'https://darwinia.network/',
        shortName: 'pangoro',
        chainId: 45,
        networkId: 45,
        explorers: [
            {
                name: 'subscan',
                url: 'https://pangoro.subscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Darwinia Network',
        chain: 'darwinia',
        network: 'darwinia network',
        rpc: ['https://darwinia-rpc.darwinia.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Darwinia Network Native Token',
            symbol: 'RING',
            decimals: 18,
        },
        infoURL: 'https://darwinia.network/',
        shortName: 'darwinia',
        chainId: 46,
        networkId: 46,
        explorers: [
            {
                name: 'subscan',
                url: 'https://darwinia.subscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'XinFin Network Mainnet',
        chain: 'XDC',
        rpc: ['https://rpc.xinfin.network'],
        faucets: [],
        nativeCurrency: {
            name: 'XinFin',
            symbol: 'XDC',
            decimals: 18,
        },
        infoURL: 'https://xinfin.org',
        shortName: 'xdc',
        chainId: 50,
        networkId: 50,
    },
    {
        name: 'XinFin Apothem Testnet',
        chain: 'TXDC',
        rpc: ['https://rpc.apothem.network'],
        faucets: [],
        nativeCurrency: {
            name: 'XinFinTest',
            symbol: 'TXDC',
            decimals: 18,
        },
        infoURL: 'https://xinfin.org',
        shortName: 'TXDC',
        chainId: 51,
        networkId: 51,
    },
    {
        name: 'CoinEx Smart Chain Mainnet',
        chain: 'CSC',
        rpc: ['https://rpc.coinex.net'],
        faucets: [],
        nativeCurrency: {
            name: 'CoinEx Chain Native Token',
            symbol: 'cet',
            decimals: 18,
        },
        infoURL: 'https://www.coinex.org/',
        shortName: 'cet',
        chainId: 52,
        networkId: 52,
        explorers: [
            {
                name: 'coinexscan',
                url: 'https://www.coinex.net',
                standard: 'none',
            },
        ],
    },
    {
        name: 'CoinEx Smart Chain Testnet',
        chain: 'CSC',
        rpc: ['https://testnet-rpc.coinex.net/'],
        faucets: [],
        nativeCurrency: {
            name: 'CoinEx Chain Test Native Token',
            symbol: 'cett',
            decimals: 18,
        },
        infoURL: 'https://www.coinex.org/',
        shortName: 'tcet',
        chainId: 53,
        networkId: 53,
        explorers: [
            {
                name: 'coinexscan',
                url: 'https://testnet.coinex.net',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Openpiece Mainnet',
        chain: 'OPENPIECE',
        icon: 'openpiece',
        network: 'mainnet',
        rpc: ['https://mainnet.openpiece.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Belly',
            symbol: 'BELLY',
            decimals: 18,
        },
        infoURL: 'https://cryptopiece.online',
        shortName: 'OP',
        chainId: 54,
        networkId: 54,
        explorers: [
            {
                name: 'Belly Scan',
                url: 'https://bellyscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Zyx Mainnet',
        chain: 'ZYX',
        rpc: [
            'https://rpc-1.zyx.network/',
            'https://rpc-2.zyx.network/',
            'https://rpc-3.zyx.network/',
            'https://rpc-4.zyx.network/',
            'https://rpc-5.zyx.network/',
            'https://rpc-6.zyx.network/',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Zyx',
            symbol: 'ZYX',
            decimals: 18,
        },
        infoURL: 'https://zyx.network/',
        shortName: 'ZYX',
        chainId: 55,
        networkId: 55,
        explorers: [
            {
                name: 'zyxscan',
                url: 'https://zyxscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Binance Smart Chain Mainnet',
        chain: 'BSC',
        rpc: [
            'https://bsc-dataseed1.binance.org',
            'https://bsc-dataseed2.binance.org',
            'https://bsc-dataseed3.binance.org',
            'https://bsc-dataseed4.binance.org',
            'https://bsc-dataseed1.defibit.io',
            'https://bsc-dataseed2.defibit.io',
            'https://bsc-dataseed3.defibit.io',
            'https://bsc-dataseed4.defibit.io',
            'https://bsc-dataseed1.ninicoin.io',
            'https://bsc-dataseed2.ninicoin.io',
            'https://bsc-dataseed3.ninicoin.io',
            'https://bsc-dataseed4.ninicoin.io',
            'wss://bsc-ws-node.nariox.org',
        ],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'Binance Chain Native Token',
            symbol: 'BNB',
            decimals: 18,
        },
        infoURL: 'https://www.binance.org',
        shortName: 'bnb',
        chainId: 56,
        networkId: 56,
        slip44: 714,
        explorers: [
            {
                name: 'bscscan',
                url: 'https://bscscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Syscoin Mainnet',
        chain: 'SYS',
        rpc: ['https://rpc.syscoin.org', 'wss://rpc.syscoin.org/wss'],
        faucets: ['https://faucet.syscoin.org'],
        nativeCurrency: {
            name: 'Syscoin',
            symbol: 'SYS',
            decimals: 18,
        },
        infoURL: 'https://www.syscoin.org',
        shortName: 'sys',
        chainId: 57,
        networkId: 57,
        explorers: [
            {
                name: 'Syscoin Block Explorer',
                url: 'https://explorer.syscoin.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Ontology Mainnet',
        chain: 'Ontology',
        rpc: [
            'http://dappnode1.ont.io:20339',
            'http://dappnode2.ont.io:20339',
            'http://dappnode3.ont.io:20339',
            'http://dappnode4.ont.io:20339',
            'https://dappnode1.ont.io:10339',
            'https://dappnode2.ont.io:10339',
            'https://dappnode3.ont.io:10339',
            'https://dappnode4.ont.io:10339',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'ONG',
            symbol: 'ONG',
            decimals: 18,
        },
        infoURL: 'https://ont.io/',
        shortName: 'Ontology Mainnet',
        chainId: 58,
        networkId: 58,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.ont.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'EOS Mainnet',
        chain: 'EOS',
        rpc: ['https://api.eosargentina.io'],
        faucets: [],
        nativeCurrency: {
            name: 'EOS',
            symbol: 'EOS',
            decimals: 18,
        },
        infoURL: 'https://eoscommunity.org/',
        shortName: 'EOS Mainnet',
        chainId: 59,
        networkId: 59,
        explorers: [
            {
                name: 'bloks',
                url: 'https://bloks.eosargentina.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'GoChain',
        chain: 'GO',
        rpc: ['https://rpc.gochain.io'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'GoChain Ether',
            symbol: 'GO',
            decimals: 18,
        },
        infoURL: 'https://gochain.io',
        shortName: 'go',
        chainId: 60,
        networkId: 60,
        slip44: 6060,
        explorers: [
            {
                name: 'GoChain Explorer',
                url: 'https://explorer.gochain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Ethereum Classic Mainnet',
        chain: 'ETC',
        rpc: ['https://www.ethercluster.com/etc'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/?'],
        nativeCurrency: {
            name: 'Ethereum Classic Ether',
            symbol: 'ETC',
            decimals: 18,
        },
        infoURL: 'https://ethereumclassic.org',
        shortName: 'etc',
        chainId: 61,
        networkId: 1,
        slip44: 61,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://blockscout.com/etc/mainnet',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Ethereum Classic Testnet Morden',
        chain: 'ETC',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Ethereum Classic Testnet Ether',
            symbol: 'TETC',
            decimals: 18,
        },
        infoURL: 'https://ethereumclassic.org',
        shortName: 'tetc',
        chainId: 62,
        networkId: 2,
    },
    {
        name: 'Ethereum Classic Testnet Mordor',
        chain: 'ETC',
        rpc: ['https://www.ethercluster.com/mordor'],
        faucets: [],
        nativeCurrency: {
            name: 'Mordor Classic Testnet Ether',
            symbol: 'METC',
            decimals: 18,
        },
        infoURL: 'https://github.com/eth-classic/mordor/',
        shortName: 'metc',
        chainId: 63,
        networkId: 7,
    },
    {
        name: 'Ellaism',
        chain: 'ELLA',
        rpc: ['https://jsonrpc.ellaism.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Ellaism Ether',
            symbol: 'ELLA',
            decimals: 18,
        },
        infoURL: 'https://ellaism.org',
        shortName: 'ellaism',
        chainId: 64,
        networkId: 64,
        slip44: 163,
    },
    {
        name: 'OKExChain Testnet',
        chain: 'okexchain',
        rpc: ['https://exchaintestrpc.okex.org'],
        faucets: ['https://www.okex.com/drawdex'],
        nativeCurrency: {
            name: 'OKExChain Global Utility Token in testnet',
            symbol: 'OKT',
            decimals: 18,
        },
        infoURL: 'https://www.okex.com/okexchain',
        shortName: 'tokt',
        chainId: 65,
        networkId: 65,
        explorers: [
            {
                name: 'OKLink',
                url: 'https://www.oklink.com/okexchain-test',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'OKXChain Mainnet',
        chain: 'okxchain',
        rpc: ['https://exchainrpc.okex.org', 'https://okc-mainnet.gateway.pokt.network/v1/lb/6275309bea1b320039c893ff'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/?'],
        nativeCurrency: {
            name: 'OKXChain Global Utility Token',
            symbol: 'OKT',
            decimals: 18,
        },
        infoURL: 'https://www.okex.com/okc',
        shortName: 'okt',
        chainId: 66,
        networkId: 66,
        explorers: [
            {
                name: 'OKLink',
                url: 'https://www.oklink.com/en/okc',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'DBChain Testnet',
        chain: 'DBM',
        rpc: ['http://test-rpc.dbmbp.com'],
        faucets: [],
        nativeCurrency: {
            name: 'DBChain Testnet',
            symbol: 'DBM',
            decimals: 18,
        },
        infoURL: 'http://test.dbmbp.com',
        shortName: 'dbm',
        chainId: 67,
        networkId: 67,
    },
    {
        name: 'SoterOne Mainnet',
        chain: 'SOTER',
        rpc: ['https://rpc.soter.one'],
        faucets: [],
        nativeCurrency: {
            name: 'SoterOne Mainnet Ether',
            symbol: 'SOTER',
            decimals: 18,
        },
        infoURL: 'https://www.soterone.com',
        shortName: 'SO1',
        chainId: 68,
        networkId: 68,
    },
    {
        name: 'Optimism Kovan',
        title: 'Optimism Testnet Kovan',
        chain: 'ETH',
        rpc: ['https://kovan.optimism.io/'],
        faucets: ['http://fauceth.komputing.org?chain=69&address=${ADDRESS}'],
        nativeCurrency: {
            name: 'Kovan Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        explorers: [
            {
                name: 'etherscan',
                url: 'https://kovan-optimistic.etherscan.io',
                standard: 'EIP3091',
            },
        ],
        infoURL: 'https://optimism.io',
        shortName: 'okov',
        chainId: 69,
        networkId: 69,
    },
    {
        name: 'Hoo Smart Chain',
        chain: 'HSC',
        rpc: [
            'https://http-mainnet.hoosmartchain.com',
            'https://http-mainnet2.hoosmartchain.com',
            'wss://ws-mainnet.hoosmartchain.com',
            'wss://ws-mainnet2.hoosmartchain.com',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Hoo Smart Chain Native Token',
            symbol: 'HOO',
            decimals: 18,
        },
        infoURL: 'https://www.hoosmartchain.com',
        shortName: 'hsc',
        chainId: 70,
        networkId: 70,
        slip44: 1170,
        explorers: [
            {
                name: 'hooscan',
                url: 'https://www.hooscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Conflux eSpace (Testnet)',
        chain: 'Conflux',
        network: 'testnet',
        rpc: ['https://evmtestnet.confluxrpc.com'],
        faucets: ['https://faucet.confluxnetwork.org'],
        nativeCurrency: {
            name: 'CFX',
            symbol: 'CFX',
            decimals: 18,
        },
        infoURL: 'https://confluxnetwork.org',
        shortName: 'cfxtest',
        chainId: 71,
        networkId: 71,
        icon: 'conflux',
        explorers: [
            {
                name: 'Conflux Scan',
                url: 'https://evmtestnet.confluxscan.net',
                standard: 'none',
            },
        ],
    },
    {
        name: 'DxChain Testnet',
        chain: 'DxChain',
        rpc: ['https://testnet-http.dxchain.com'],
        faucets: ['https://faucet.dxscan.io'],
        nativeCurrency: {
            name: 'DxChain Testnet',
            symbol: 'DX',
            decimals: 18,
        },
        infoURL: 'https://testnet.dxscan.io/',
        shortName: 'dxc',
        chainId: 72,
        networkId: 72,
    },
    {
        name: 'IDChain Mainnet',
        chain: 'IDChain',
        network: 'mainnet',
        rpc: ['https://idchain.one/rpc/', 'wss://idchain.one/ws/'],
        faucets: [],
        nativeCurrency: {
            name: 'EIDI',
            symbol: 'EIDI',
            decimals: 18,
        },
        infoURL: 'https://idchain.one/begin/',
        shortName: 'idchain',
        chainId: 74,
        networkId: 74,
        icon: 'idchain',
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.idchain.one',
                icon: 'etherscan',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Mix',
        chain: 'MIX',
        rpc: ['https://rpc2.mix-blockchain.org:8647'],
        faucets: [],
        nativeCurrency: {
            name: 'Mix Ether',
            symbol: 'MIX',
            decimals: 18,
        },
        infoURL: 'https://mix-blockchain.org',
        shortName: 'mix',
        chainId: 76,
        networkId: 76,
        slip44: 76,
    },
    {
        name: 'POA Network Sokol',
        chain: 'POA',
        rpc: ['https://sokol.poa.network', 'wss://sokol.poa.network/wss', 'ws://sokol.poa.network:8546'],
        faucets: ['https://faucet.poa.network'],
        nativeCurrency: {
            name: 'POA Sokol Ether',
            symbol: 'SPOA',
            decimals: 18,
        },
        infoURL: 'https://poa.network',
        shortName: 'spoa',
        chainId: 77,
        networkId: 77,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://blockscout.com/poa/sokol',
                standard: 'none',
            },
        ],
    },
    {
        name: 'PrimusChain mainnet',
        chain: 'PC',
        rpc: ['https://ethnode.primusmoney.com/mainnet'],
        faucets: [],
        nativeCurrency: {
            name: 'Primus Ether',
            symbol: 'PETH',
            decimals: 18,
        },
        infoURL: 'https://primusmoney.com',
        shortName: 'primuschain',
        chainId: 78,
        networkId: 78,
    },
    {
        name: 'Zenith Mainnet',
        chain: 'Zenith',
        rpc: [
            'https://dataserver-us-1.zenithchain.co/',
            'https://dataserver-asia-3.zenithchain.co/',
            'https://dataserver-asia-4.zenithchain.co/',
            'https://dataserver-asia-2.zenithchain.co/',
            'https://dataserver-asia-5.zenithchain.co/',
            'https://dataserver-asia-6.zenithchain.co/',
            'https://dataserver-asia-7.zenithchain.co/',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'ZENITH',
            symbol: 'ZENITH',
            decimals: 18,
        },
        infoURL: 'https://www.zenithchain.co/',
        chainId: 79,
        networkId: 79,
        shortName: 'zenith',
        explorers: [
            {
                name: 'zenith scan',
                url: 'https://scan.zenithchain.co',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'GeneChain',
        chain: 'GeneChain',
        rpc: ['https://rpc.genechain.io'],
        faucets: [],
        nativeCurrency: {
            name: 'RNA',
            symbol: 'RNA',
            decimals: 18,
        },
        infoURL: 'https://scan.genechain.io/',
        shortName: 'GeneChain',
        chainId: 80,
        networkId: 80,
        explorers: [
            {
                name: 'GeneChain Scan',
                url: 'https://scan.genechain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Zenith Testnet (Vilnius)',
        chain: 'Zenith',
        rpc: ['https://vilnius.zenithchain.co/http'],
        faucets: ['https://faucet.zenithchain.co/'],
        nativeCurrency: {
            name: 'Vilnius',
            symbol: 'VIL',
            decimals: 18,
        },
        infoURL: 'https://www.zenithchain.co/',
        chainId: 81,
        networkId: 81,
        shortName: 'VIL',
        explorers: [
            {
                name: 'vilnius scan',
                url: 'https://vilnius.scan.zenithchain.co',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Meter Mainnet',
        chain: 'METER',
        rpc: ['https://rpc.meter.io'],
        faucets: ['https://faucet.meter.io'],
        nativeCurrency: {
            name: 'Meter',
            symbol: 'MTR',
            decimals: 18,
        },
        infoURL: 'https://www.meter.io',
        shortName: 'Meter',
        chainId: 82,
        networkId: 82,
        explorers: [
            {
                name: 'Meter Mainnet Scan',
                url: 'https://scan.meter.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Meter Testnet',
        chain: 'METER Testnet',
        rpc: ['https://rpctest.meter.io'],
        faucets: ['https://faucet-warringstakes.meter.io'],
        nativeCurrency: {
            name: 'Meter',
            symbol: 'MTR',
            decimals: 18,
        },
        infoURL: 'https://www.meter.io',
        shortName: 'MeterTest',
        chainId: 83,
        networkId: 83,
        explorers: [
            {
                name: 'Meter Testnet Scan',
                url: 'https://scan-warringstakes.meter.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'GateChain Testnet',
        chainId: 85,
        shortName: 'gttest',
        chain: 'GTTEST',
        networkId: 85,
        nativeCurrency: {
            name: 'GateToken',
            symbol: 'GT',
            decimals: 18,
        },
        rpc: ['https://testnet.gatenode.cc'],
        faucets: ['https://www.gatescan.org/testnet/faucet'],
        explorers: [
            {
                name: 'GateScan',
                url: 'https://www.gatescan.org/testnet',
                standard: 'EIP3091',
            },
        ],
        infoURL: 'https://www.gatechain.io',
    },
    {
        name: 'GateChain Mainnet',
        chainId: 86,
        shortName: 'gt',
        chain: 'GT',
        networkId: 86,
        nativeCurrency: {
            name: 'GateToken',
            symbol: 'GT',
            decimals: 18,
        },
        rpc: ['https://evm.gatenode.cc'],
        faucets: ['https://www.gatescan.org/faucet'],
        explorers: [
            {
                name: 'GateScan',
                url: 'https://www.gatescan.org',
                standard: 'EIP3091',
            },
        ],
        infoURL: 'https://www.gatechain.io',
    },
    {
        name: 'Nova Network',
        chain: 'NNW',
        icon: 'novanetwork',
        rpc: ['https://connect.novanetwork.io', 'https://0x57.redjackstudio.com', 'https://rpc.novanetwork.io:9070'],
        faucets: [],
        nativeCurrency: {
            name: 'Supernova',
            symbol: 'SNT',
            decimals: 18,
        },
        infoURL: 'https://novanetwork.io',
        shortName: 'nnw',
        chainId: 87,
        networkId: 87,
        explorers: [
            {
                name: 'novanetwork',
                url: 'https://explorer.novanetwork.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'TomoChain',
        chain: 'TOMO',
        rpc: ['https://rpc.tomochain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'TomoChain',
            symbol: 'TOMO',
            decimals: 18,
        },
        infoURL: 'https://tomochain.com',
        shortName: 'tomo',
        chainId: 88,
        networkId: 88,
        slip44: 889,
    },
    {
        name: 'TomoChain Testnet',
        chain: 'TOMO',
        rpc: ['https://rpc.testnet.tomochain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'TomoChain',
            symbol: 'TOMO',
            decimals: 18,
        },
        infoURL: 'https://tomochain.com',
        shortName: 'tomot',
        chainId: 89,
        networkId: 89,
        slip44: 889,
    },
    {
        name: 'Garizon Stage0',
        chain: 'GAR',
        network: 'mainnet',
        icon: 'garizon',
        rpc: ['https://s0.garizon.net/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-s0',
        chainId: 90,
        networkId: 90,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Garizon Stage1',
        chain: 'GAR',
        network: 'mainnet',
        icon: 'garizon',
        rpc: ['https://s1.garizon.net/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-s1',
        chainId: 91,
        networkId: 91,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
        parent: {
            chain: 'eip155-90',
            type: 'shard',
        },
    },
    {
        name: 'Garizon Stage2',
        chain: 'GAR',
        network: 'mainnet',
        icon: 'garizon',
        rpc: ['https://s2.garizon.net/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-s2',
        chainId: 92,
        networkId: 92,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
        parent: {
            chain: 'eip155-90',
            type: 'shard',
        },
    },
    {
        name: 'Garizon Stage3',
        chain: 'GAR',
        network: 'mainnet',
        icon: 'garizon',
        rpc: ['https://s3.garizon.net/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-s3',
        chainId: 93,
        networkId: 93,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
        parent: {
            chain: 'eip155-90',
            type: 'shard',
        },
    },
    {
        name: 'CryptoKylin Testnet',
        chain: 'EOS',
        rpc: ['https://kylin.eosargentina.io'],
        faucets: [],
        nativeCurrency: {
            name: 'EOS',
            symbol: 'EOS',
            decimals: 18,
        },
        infoURL: 'https://www.cryptokylin.io/',
        shortName: 'Kylin Testnet',
        chainId: 95,
        networkId: 95,
        explorers: [
            {
                name: 'eosq',
                url: 'https://kylin.eosargentina.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'NEXT Smart Chain',
        chain: 'NSC',
        rpc: ['https://rpc.nextsmartchain.com'],
        faucets: ['https://faucet.nextsmartchain.com'],
        nativeCurrency: {
            name: 'NEXT',
            symbol: 'NEXT',
            decimals: 18,
        },
        infoURL: 'https://www.nextsmartchain.com/',
        shortName: 'nsc',
        chainId: 96,
        networkId: 96,
        explorers: [
            {
                name: 'Next Smart Chain Explorer',
                url: 'https://explorer.nextsmartchain.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Binance Smart Chain Testnet',
        chain: 'BSC',
        rpc: [
            'https://data-seed-prebsc-1-s1.binance.org:8545',
            'https://data-seed-prebsc-2-s1.binance.org:8545',
            'https://data-seed-prebsc-1-s2.binance.org:8545',
            'https://data-seed-prebsc-2-s2.binance.org:8545',
            'https://data-seed-prebsc-1-s3.binance.org:8545',
            'https://data-seed-prebsc-2-s3.binance.org:8545',
        ],
        faucets: ['https://testnet.binance.org/faucet-smart'],
        nativeCurrency: {
            name: 'Binance Chain Native Token',
            symbol: 'tBNB',
            decimals: 18,
        },
        infoURL: 'https://testnet.binance.org/',
        shortName: 'bnbt',
        chainId: 97,
        networkId: 97,
        explorers: [
            {
                name: 'bscscan-testnet',
                url: 'https://testnet.bscscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'POA Network Core',
        chain: 'POA',
        rpc: [
            'https://core.poanetwork.dev',
            'http://core.poanetwork.dev:8545',
            'https://core.poa.network',
            'ws://core.poanetwork.dev:8546',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'POA Network Core Ether',
            symbol: 'POA',
            decimals: 18,
        },
        infoURL: 'https://poa.network',
        shortName: 'poa',
        chainId: 99,
        networkId: 99,
        slip44: 178,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://blockscout.com/poa/core',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Gnosis Chain',
        chain: 'GNO',
        icon: 'gnosis',
        rpc: [
            'https://rpc.gnosischain.com',
            'https://rpc.ankr.com/gnosis',
            'https://gnosischain-rpc.gateway.pokt.network',
            'https://gnosis-mainnet.public.blastapi.io',
            'wss://rpc.gnosischain.com/wss',
        ],
        faucets: [
            'https://faucet.gimlu.com/gnosis',
            'https://stakely.io/faucet/gnosis-chain-xdai',
            'https://faucet.prussia.dev/xdai',
        ],
        nativeCurrency: {
            name: 'xDAI',
            symbol: 'xDAI',
            decimals: 18,
        },
        infoURL: 'https://developers.gnosischain.com',
        shortName: 'gno',
        chainId: 100,
        networkId: 100,
        slip44: 700,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://blockscout.com/xdai/mainnet',
                icon: 'blockscout',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'EtherInc',
        chain: 'ETI',
        rpc: ['https://api.einc.io/jsonrpc/mainnet'],
        faucets: [],
        nativeCurrency: {
            name: 'EtherInc Ether',
            symbol: 'ETI',
            decimals: 18,
        },
        infoURL: 'https://einc.io',
        shortName: 'eti',
        chainId: 101,
        networkId: 1,
        slip44: 464,
    },
    {
        name: 'Web3Games Testnet',
        chain: 'Web3Games',
        icon: 'web3games',
        rpc: ['https://testnet.web3games.org/evm'],
        faucets: [],
        nativeCurrency: {
            name: 'Web3Games',
            symbol: 'W3G',
            decimals: 18,
        },
        infoURL: 'https://web3games.org/',
        shortName: 'tw3g',
        chainId: 102,
        networkId: 102,
    },
    {
        name: 'Kaiba Lightning Chain Testnet',
        chain: 'tKLC',
        network: 'testnet',
        rpc: ['https://klc.live/'],
        faucets: [],
        nativeCurrency: {
            name: 'Kaiba Testnet Token',
            symbol: 'tKAIBA',
            decimals: 18,
        },
        infoURL: 'https://kaibadefi.com',
        shortName: 'tklc',
        chainId: 104,
        networkId: 104,
        icon: 'kaiba',
        explorers: [
            {
                name: 'kaibascan',
                url: 'https://kaibascan.io',
                icon: 'kaibascan',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Web3Games Devnet',
        chain: 'Web3Games',
        icon: 'web3games',
        rpc: ['https://devnet.web3games.org/evm'],
        faucets: [],
        nativeCurrency: {
            name: 'Web3Games',
            symbol: 'W3G',
            decimals: 18,
        },
        infoURL: 'https://web3games.org/',
        shortName: 'dw3g',
        chainId: 105,
        networkId: 105,
        explorers: [
            {
                name: 'Web3Games Explorer',
                url: 'https://explorer-devnet.web3games.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Velas EVM Mainnet',
        chain: 'Velas',
        icon: 'velas',
        rpc: ['https://evmexplorer.velas.com/rpc', 'https://explorer.velas.com/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Velas',
            symbol: 'VLX',
            decimals: 18,
        },
        infoURL: 'https://velas.com',
        shortName: 'vlx',
        chainId: 106,
        networkId: 106,
        explorers: [
            {
                name: 'Velas Explorer',
                url: 'https://evmexplorer.velas.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Nebula Testnet',
        chain: 'NTN',
        icon: 'nebulatestnet',
        rpc: ['https://testnet.rpc.novanetwork.io:9070'],
        faucets: ['https://faucet.novanetwork.io'],
        nativeCurrency: {
            name: 'Nebula X',
            symbol: 'NBX',
            decimals: 18,
        },
        infoURL: 'https://novanetwork.io',
        shortName: 'ntn',
        chainId: 107,
        networkId: 107,
        explorers: [
            {
                name: 'nebulatestnet',
                url: 'https://explorer.novanetwork.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'ThunderCore Mainnet',
        chain: 'TT',
        rpc: [
            'https://mainnet-rpc.thundercore.com',
            'https://mainnet-rpc.thundertoken.net',
            'https://mainnet-rpc.thundercore.io',
        ],
        faucets: ['https://faucet.thundercore.com'],
        nativeCurrency: {
            name: 'ThunderCore Token',
            symbol: 'TT',
            decimals: 18,
        },
        infoURL: 'https://thundercore.com',
        shortName: 'TT',
        chainId: 108,
        networkId: 108,
        slip44: 1001,
        explorers: [
            {
                name: 'thundercore-viewblock',
                url: 'https://viewblock.io/thundercore',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Proton Testnet',
        chain: 'XPR',
        rpc: ['https://protontestnet.greymass.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'Proton',
            symbol: 'XPR',
            decimals: 4,
        },
        infoURL: 'https://protonchain.com',
        shortName: 'xpr',
        chainId: 110,
        networkId: 110,
    },
    {
        name: 'EtherLite Chain',
        chain: 'ETL',
        rpc: ['https://rpc.etherlite.org'],
        faucets: ['https://etherlite.org/faucets'],
        nativeCurrency: {
            name: 'EtherLite',
            symbol: 'ETL',
            decimals: 18,
        },
        infoURL: 'https://etherlite.org',
        shortName: 'ETL',
        chainId: 111,
        networkId: 111,
        icon: 'etherlite',
    },
    {
        name: 'Fuse Mainnet',
        chain: 'FUSE',
        rpc: ['https://rpc.fuse.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Fuse',
            symbol: 'FUSE',
            decimals: 18,
        },
        infoURL: 'https://fuse.io/',
        shortName: 'fuse',
        chainId: 122,
        networkId: 122,
    },
    {
        name: 'Fuse Sparknet',
        chain: 'fuse',
        rpc: ['https://rpc.fusespark.io'],
        faucets: ['https://get.fusespark.io'],
        nativeCurrency: {
            name: 'Spark',
            symbol: 'SPARK',
            decimals: 18,
        },
        infoURL: 'https://docs.fuse.io/general/fuse-network-blockchain/fuse-testnet',
        shortName: 'spark',
        chainId: 123,
        networkId: 123,
    },
    {
        name: 'Decentralized Web Mainnet',
        shortName: 'dwu',
        chain: 'DWU',
        chainId: 124,
        networkId: 124,
        rpc: ['https://decentralized-web.tech/dw_rpc.php'],
        faucets: [],
        infoURL: 'https://decentralized-web.tech/dw_chain.php',
        nativeCurrency: {
            name: 'Decentralized Web Utility',
            symbol: 'DWU',
            decimals: 18,
        },
    },
    {
        name: 'OYchain Testnet',
        chain: 'OYchain',
        rpc: ['https://rpc.testnet.oychain.io'],
        faucets: ['https://faucet.oychain.io'],
        nativeCurrency: {
            name: 'OYchain Token',
            symbol: 'OY',
            decimals: 18,
        },
        infoURL: 'https://www.oychain.io',
        shortName: 'oychain testnet',
        chainId: 125,
        networkId: 125,
        slip44: 125,
        explorers: [
            {
                name: 'OYchain Testnet Explorer',
                url: 'https://explorer.testnet.oychain.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'OYchain Mainnet',
        chain: 'OYchain',
        icon: 'oychain',
        rpc: ['https://rpc.mainnet.oychain.io'],
        faucets: [],
        nativeCurrency: {
            name: 'OYchain Token',
            symbol: 'OY',
            decimals: 18,
        },
        infoURL: 'https://www.oychain.io',
        shortName: 'oychain mainnet',
        chainId: 126,
        networkId: 126,
        slip44: 126,
        explorers: [
            {
                name: 'OYchain Mainnet Explorer',
                url: 'https://explorer.oychain.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Factory 127 Mainnet',
        chain: 'FETH',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Factory 127 Token',
            symbol: 'FETH',
            decimals: 18,
        },
        infoURL: 'https://www.factory127.com',
        shortName: 'feth',
        chainId: 127,
        networkId: 127,
        slip44: 127,
    },
    {
        name: 'Huobi ECO Chain Mainnet',
        chain: 'Heco',
        rpc: ['https://http-mainnet.hecochain.com', 'wss://ws-mainnet.hecochain.com'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'Huobi ECO Chain Native Token',
            symbol: 'HT',
            decimals: 18,
        },
        infoURL: 'https://www.hecochain.com',
        shortName: 'heco',
        chainId: 128,
        networkId: 128,
        slip44: 1010,
        explorers: [
            {
                name: 'hecoinfo',
                url: 'https://hecoinfo.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Polygon Mainnet',
        chain: 'Polygon',
        rpc: [
            'https://polygon-rpc.com/',
            'https://rpc-mainnet.matic.network',
            'https://matic-mainnet.chainstacklabs.com',
            'https://rpc-mainnet.maticvigil.com',
            'https://rpc-mainnet.matic.quiknode.pro',
            'https://matic-mainnet-full-rpc.bwarelabs.com',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'MATIC',
            symbol: 'MATIC',
            decimals: 18,
        },
        infoURL: 'https://polygon.technology/',
        shortName: 'MATIC',
        chainId: 137,
        networkId: 137,
        slip44: 966,
        explorers: [
            {
                name: 'polygonscan',
                url: 'https://polygonscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Openpiece Testnet',
        chain: 'OPENPIECE',
        icon: 'openpiece',
        network: 'testnet',
        rpc: ['https://testnet.openpiece.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Belly',
            symbol: 'BELLY',
            decimals: 18,
        },
        infoURL: 'https://cryptopiece.online',
        shortName: 'OPtest',
        chainId: 141,
        networkId: 141,
        explorers: [
            {
                name: 'Belly Scan',
                url: 'https://testnet.bellyscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'DAX CHAIN',
        chain: 'DAX',
        rpc: ['https://rpc.prodax.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Prodax',
            symbol: 'DAX',
            decimals: 18,
        },
        infoURL: 'https://prodax.io/',
        shortName: 'dax',
        chainId: 142,
        networkId: 142,
    },
    {
        name: 'Lightstreams Testnet',
        chain: 'PHT',
        rpc: ['https://node.sirius.lightstreams.io'],
        faucets: ['https://discuss.lightstreams.network/t/request-test-tokens'],
        nativeCurrency: {
            name: 'Lightstreams PHT',
            symbol: 'PHT',
            decimals: 18,
        },
        infoURL: 'https://explorer.sirius.lightstreams.io',
        shortName: 'tpht',
        chainId: 162,
        networkId: 162,
    },
    {
        name: 'Lightstreams Mainnet',
        chain: 'PHT',
        rpc: ['https://node.mainnet.lightstreams.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Lightstreams PHT',
            symbol: 'PHT',
            decimals: 18,
        },
        infoURL: 'https://explorer.lightstreams.io',
        shortName: 'pht',
        chainId: 163,
        networkId: 163,
    },
    {
        name: 'AIOZ Network',
        chain: 'AIOZ',
        network: 'mainnet',
        icon: 'aioz',
        rpc: ['https://eth-dataseed.aioz.network'],
        faucets: [],
        nativeCurrency: {
            name: 'AIOZ',
            symbol: 'AIOZ',
            decimals: 18,
        },
        infoURL: 'https://aioz.network',
        shortName: 'aioz',
        chainId: 168,
        networkId: 168,
        slip44: 60,
        explorers: [
            {
                name: 'AIOZ Network Explorer',
                url: 'https://explorer.aioz.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'HOO Smart Chain Testnet',
        chain: 'ETH',
        rpc: ['https://http-testnet.hoosmartchain.com'],
        faucets: ['https://faucet-testnet.hscscan.com/'],
        nativeCurrency: {
            name: 'HOO',
            symbol: 'HOO',
            decimals: 18,
        },
        infoURL: 'https://www.hoosmartchain.com',
        shortName: 'hoosmartchain',
        chainId: 170,
        networkId: 170,
    },
    {
        name: 'Latam-Blockchain Resil Testnet',
        chain: 'Resil',
        rpc: ['https://rpc.latam-blockchain.com', 'wss://ws.latam-blockchain.com'],
        faucets: ['https://faucet.latam-blockchain.com'],
        nativeCurrency: {
            name: 'Latam-Blockchain Resil Test Native Token',
            symbol: 'usd',
            decimals: 18,
        },
        infoURL: 'https://latam-blockchain.com',
        shortName: 'resil',
        chainId: 172,
        networkId: 172,
    },
    {
        name: 'AME Chain Mainnet',
        chain: 'AME',
        rpc: ['https://node1.amechain.io/'],
        faucets: [],
        nativeCurrency: {
            name: 'AME',
            symbol: 'AME',
            decimals: 18,
        },
        infoURL: 'https://amechain.io/',
        shortName: 'ame',
        chainId: 180,
        networkId: 180,
        explorers: [
            {
                name: 'AME Scan',
                url: 'https://amescan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Seele Mainnet',
        chain: 'Seele',
        rpc: ['https://rpc.seelen.pro/'],
        faucets: [],
        nativeCurrency: {
            name: 'Seele',
            symbol: 'Seele',
            decimals: 18,
        },
        infoURL: 'https://seelen.pro/',
        shortName: 'Seele',
        chainId: 186,
        networkId: 186,
        explorers: [
            {
                name: 'seeleview',
                url: 'https://seeleview.net',
                standard: 'none',
            },
        ],
    },
    {
        name: 'BMC Mainnet',
        chain: 'BMC',
        rpc: ['https://mainnet.bmcchain.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'BTM',
            symbol: 'BTM',
            decimals: 18,
        },
        infoURL: 'https://bmc.bytom.io/',
        shortName: 'BMC',
        chainId: 188,
        networkId: 188,
        explorers: [
            {
                name: 'Blockmeta',
                url: 'https://bmc.blockmeta.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'BMC Testnet',
        chain: 'BMC',
        rpc: ['https://testnet.bmcchain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'BTM',
            symbol: 'BTM',
            decimals: 18,
        },
        infoURL: 'https://bmc.bytom.io/',
        shortName: 'BMCT',
        chainId: 189,
        networkId: 189,
        explorers: [
            {
                name: 'Blockmeta',
                url: 'https://bmctestnet.blockmeta.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Crypto Emergency',
        chain: 'CEM',
        rpc: ['https://cemchain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Crypto Emergency',
            symbol: 'CEM',
            decimals: 18,
        },
        infoURL: 'https://cemblockchain.com/',
        shortName: 'cem',
        chainId: 193,
        networkId: 193,
        explorers: [
            {
                name: 'cemscan',
                url: 'https://cemscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'BitTorrent Chain Mainnet',
        chain: 'BTTC',
        rpc: ['https://rpc.bittorrentchain.io/'],
        faucets: [],
        nativeCurrency: {
            name: 'BitTorrent',
            symbol: 'BTT',
            decimals: 18,
        },
        infoURL: 'https://bittorrentchain.io/',
        shortName: 'BTT',
        chainId: 199,
        networkId: 199,
        explorers: [
            {
                name: 'bttcscan',
                url: 'https://scan.bittorrentchain.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Arbitrum on xDai',
        chain: 'AOX',
        rpc: ['https://arbitrum.xdaichain.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'xDAI',
            symbol: 'xDAI',
            decimals: 18,
        },
        infoURL: 'https://xdaichain.com',
        shortName: 'aox',
        chainId: 200,
        networkId: 200,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://blockscout.com/xdai/arbitrum',
                standard: 'EIP3091',
            },
        ],
        parent: {
            chain: 'eip155-100',
            type: 'L2',
        },
    },
    {
        name: 'Freight Trust Network',
        chain: 'EDI',
        rpc: ['http://13.57.207.168:3435', 'https://app.freighttrust.net/ftn/${API_KEY}'],
        faucets: ['http://faucet.freight.sh'],
        nativeCurrency: {
            name: 'Freight Trust Native',
            symbol: '0xF',
            decimals: 18,
        },
        infoURL: 'https://freighttrust.com',
        shortName: 'EDI',
        chainId: 211,
        networkId: 0,
    },
    {
        name: 'SoterOne Mainnet old',
        chain: 'SOTER',
        rpc: ['https://rpc.soter.one'],
        faucets: [],
        nativeCurrency: {
            name: 'SoterOne Mainnet Ether',
            symbol: 'SOTER',
            decimals: 18,
        },
        infoURL: 'https://www.soterone.com',
        shortName: 'SO1-old',
        chainId: 218,
        networkId: 218,
        status: 'deprecated',
    },
    {
        name: 'Permission',
        chain: 'ASK',
        rpc: ['https://blockchain-api-mainnet.permission.io/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'ASK',
            symbol: 'ASK',
            decimals: 18,
        },
        infoURL: 'https://permission.io/',
        shortName: 'ASK',
        chainId: 222,
        networkId: 2221,
        slip44: 2221,
    },
    {
        name: 'LACHAIN Mainnet',
        chain: 'LA',
        icon: 'lachain',
        rpc: ['https://rpc-mainnet.lachain.io'],
        faucets: [],
        nativeCurrency: {
            name: 'LA',
            symbol: 'LA',
            decimals: 18,
        },
        infoURL: 'https://lachain.io',
        shortName: 'LA',
        chainId: 225,
        networkId: 225,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://scan.lachain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'LACHAIN Testnet',
        chain: 'TLA',
        icon: 'lachain',
        rpc: ['https://rpc-testnet.lachain.io'],
        faucets: [],
        nativeCurrency: {
            name: 'TLA',
            symbol: 'TLA',
            decimals: 18,
        },
        infoURL: 'https://lachain.io',
        shortName: 'TLA',
        chainId: 226,
        networkId: 226,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://scan-test.lachain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Energy Web Chain',
        chain: 'Energy Web Chain',
        rpc: ['https://rpc.energyweb.org', 'wss://rpc.energyweb.org/ws'],
        faucets: ['https://faucet.carbonswap.exchange', 'https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'Energy Web Token',
            symbol: 'EWT',
            decimals: 18,
        },
        infoURL: 'https://energyweb.org',
        shortName: 'ewt',
        chainId: 246,
        networkId: 246,
        slip44: 246,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://explorer.energyweb.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Fantom Opera',
        chain: 'FTM',
        rpc: ['https://rpc.ftm.tools'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'Fantom',
            symbol: 'FTM',
            decimals: 18,
        },
        infoURL: 'https://fantom.foundation',
        shortName: 'ftm',
        chainId: 250,
        networkId: 250,
        icon: 'fantom',
        explorers: [
            {
                name: 'ftmscan',
                url: 'https://ftmscan.com',
                icon: 'ftmscan',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Huobi ECO Chain Testnet',
        chain: 'Heco',
        rpc: ['https://http-testnet.hecochain.com', 'wss://ws-testnet.hecochain.com'],
        faucets: ['https://scan-testnet.hecochain.com/faucet'],
        nativeCurrency: {
            name: 'Huobi ECO Chain Test Native Token',
            symbol: 'htt',
            decimals: 18,
        },
        infoURL: 'https://testnet.hecoinfo.com',
        shortName: 'hecot',
        chainId: 256,
        networkId: 256,
    },
    {
        name: 'Setheum',
        chain: 'Setheum',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Setheum',
            symbol: 'SETM',
            decimals: 18,
        },
        infoURL: 'https://setheum.xyz',
        shortName: 'setm',
        chainId: 258,
        networkId: 258,
    },
    {
        name: 'SUR Blockchain Network',
        chain: 'SUR',
        rpc: ['https://sur.nilin.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Suren',
            symbol: 'SRN',
            decimals: 18,
        },
        infoURL: 'https://surnet.org',
        shortName: 'SUR',
        chainId: 262,
        networkId: 1,
        icon: 'SUR',
        explorers: [
            {
                name: 'Surnet Explorer',
                url: 'https://explorer.surnet.org',
                icon: 'SUR',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'High Performance Blockchain',
        chain: 'HPB',
        rpc: ['https://hpbnode.com', 'wss://ws.hpbnode.com'],
        faucets: ['https://myhpbwallet.com/'],
        nativeCurrency: {
            name: 'High Performance Blockchain Ether',
            symbol: 'HPB',
            decimals: 18,
        },
        infoURL: 'https://hpb.io',
        shortName: 'hpb',
        chainId: 269,
        networkId: 269,
        slip44: 269,
        explorers: [
            {
                name: 'hscan',
                url: 'https://hscan.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'zkSync alpha testnet',
        chain: 'ETH',
        rpc: ['https://zksync2-testnet.zksync.dev'],
        faucets: ['https://portal.zksync.io/faucet'],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://v2-docs.zksync.io/',
        shortName: 'zksync-goerli',
        chainId: 280,
        networkId: 280,
        icon: 'ethereum',
        explorers: [
            {
                name: 'blockscout',
                url: 'https://zksync2-testnet.zkscan.io',
                icon: 'blockscout',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Boba Network',
        chain: 'ETH',
        rpc: ['https://mainnet.boba.network/'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://boba.network',
        shortName: 'Boba',
        chainId: 288,
        networkId: 288,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://blockexplorer.boba.network',
                standard: 'none',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-1',
            bridges: [
                {
                    url: 'https://gateway.boba.network',
                },
            ],
        },
    },
    {
        name: 'Optimism on Gnosis Chain',
        chain: 'OGC',
        rpc: ['https://optimism.gnosischain.com', 'wss://optimism.gnosischain.com/wss'],
        faucets: ['https://faucet.gimlu.com/gnosis'],
        nativeCurrency: {
            name: 'xDAI',
            symbol: 'xDAI',
            decimals: 18,
        },
        infoURL: 'https://www.xdaichain.com/for-developers/optimism-optimistic-rollups-on-gc',
        shortName: 'ogc',
        chainId: 300,
        networkId: 300,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://blockscout.com/xdai/optimism',
                icon: 'blockscout',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'KCC Mainnet',
        chain: 'KCC',
        rpc: ['https://rpc-mainnet.kcc.network', 'wss://rpc-ws-mainnet.kcc.network'],
        faucets: [],
        nativeCurrency: {
            name: 'KuCoin Token',
            symbol: 'KCS',
            decimals: 18,
        },
        infoURL: 'https://kcc.io',
        shortName: 'kcs',
        chainId: 321,
        networkId: 1,
        explorers: [
            {
                name: 'KCC Explorer',
                url: 'https://explorer.kcc.io/en',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'KCC Testnet',
        chain: 'KCC',
        rpc: ['https://rpc-testnet.kcc.network', 'wss://rpc-ws-testnet.kcc.network'],
        faucets: ['https://faucet-testnet.kcc.network'],
        nativeCurrency: {
            name: 'KuCoin Testnet Token',
            symbol: 'tKCS',
            decimals: 18,
        },
        infoURL: 'https://scan-testnet.kcc.network',
        shortName: 'kcst',
        chainId: 322,
        networkId: 322,
        explorers: [
            {
                name: 'kcc-scan',
                url: 'https://scan-testnet.kcc.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Web3Q Mainnet',
        chain: 'Web3Q',
        rpc: ['https://mainnet.web3q.io:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'Web3Q',
            symbol: 'W3Q',
            decimals: 18,
        },
        infoURL: 'https://web3q.io/home.w3q/',
        shortName: 'w3q',
        chainId: 333,
        networkId: 333,
        explorers: [
            {
                name: 'w3q-mainnet',
                url: 'https://explorer.mainnet.web3q.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'DFK Chain Test',
        chain: 'DFK',
        icon: 'dfk',
        network: 'testnet',
        rpc: ['https://subnets.avax.network/defi-kingdoms/dfk-chain-testnet/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Jewel',
            symbol: 'JEWEL',
            decimals: 18,
        },
        infoURL: 'https://defikingdoms.com',
        shortName: 'DFKTEST',
        chainId: 335,
        networkId: 335,
        explorers: [
            {
                name: 'ethernal',
                url: 'https://explorer-test.dfkchain.com',
                icon: 'ethereum',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Shiden',
        chain: 'SDN',
        rpc: ['https://rpc.shiden.astar.network:8545', 'wss://shiden.api.onfinality.io/public-ws'],
        faucets: [],
        nativeCurrency: {
            name: 'Shiden',
            symbol: 'SDN',
            decimals: 18,
        },
        infoURL: 'https://shiden.astar.network/',
        shortName: 'sdn',
        chainId: 336,
        networkId: 336,
        icon: 'shiden',
        explorers: [
            {
                name: 'subscan',
                url: 'https://shiden.subscan.io',
                standard: 'none',
                icon: 'subscan',
            },
        ],
    },
    {
        name: 'Cronos Testnet',
        chain: 'CRO',
        rpc: ['https://cronos-testnet-3.crypto.org:8545', 'wss://cronos-testnet-3.crypto.org:8546'],
        faucets: ['https://cronos.crypto.org/faucet'],
        nativeCurrency: {
            name: 'Crypto.org Test Coin',
            symbol: 'TCRO',
            decimals: 18,
        },
        infoURL: 'https://cronos.crypto.org',
        shortName: 'tcro',
        chainId: 338,
        networkId: 338,
        explorers: [
            {
                name: 'Cronos Testnet Explorer',
                url: 'https://cronos.crypto.org/explorer/testnet3',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Theta Mainnet',
        chain: 'Theta',
        rpc: ['https://eth-rpc-api.thetatoken.org/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Theta Fuel',
            symbol: 'TFUEL',
            decimals: 18,
        },
        infoURL: 'https://www.thetatoken.org/',
        shortName: 'theta-mainnet',
        chainId: 361,
        networkId: 361,
        explorers: [
            {
                name: 'Theta Mainnet Explorer',
                url: 'https://explorer.thetatoken.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Theta Sapphire Testnet',
        chain: 'Theta',
        rpc: ['https://eth-rpc-api-sapphire.thetatoken.org/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Theta Fuel',
            symbol: 'TFUEL',
            decimals: 18,
        },
        infoURL: 'https://www.thetatoken.org/',
        shortName: 'theta-sapphire',
        chainId: 363,
        networkId: 363,
        explorers: [
            {
                name: 'Theta Sapphire Testnet Explorer',
                url: 'https://guardian-testnet-sapphire-explorer.thetatoken.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Theta Amber Testnet',
        chain: 'Theta',
        rpc: ['https://eth-rpc-api-amber.thetatoken.org/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Theta Fuel',
            symbol: 'TFUEL',
            decimals: 18,
        },
        infoURL: 'https://www.thetatoken.org/',
        shortName: 'theta-amber',
        chainId: 364,
        networkId: 364,
        explorers: [
            {
                name: 'Theta Amber Testnet Explorer',
                url: 'https://guardian-testnet-amber-explorer.thetatoken.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Theta Testnet',
        chain: 'Theta',
        rpc: ['https://eth-rpc-api-testnet.thetatoken.org/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Theta Fuel',
            symbol: 'TFUEL',
            decimals: 18,
        },
        infoURL: 'https://www.thetatoken.org/',
        shortName: 'theta-testnet',
        chainId: 365,
        networkId: 365,
        explorers: [
            {
                name: 'Theta Testnet Explorer',
                url: 'https://testnet-explorer.thetatoken.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'PulseChain Mainnet',
        shortName: 'pls',
        chain: 'PLS',
        chainId: 369,
        networkId: 369,
        infoURL: 'https://pulsechain.com/',
        rpc: ['https://rpc.mainnet.pulsechain.com/', 'wss://rpc.mainnet.pulsechain.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'Pulse',
            symbol: 'PLS',
            decimals: 18,
        },
    },
    {
        name: 'Lisinski',
        chain: 'CRO',
        rpc: ['https://rpc-bitfalls1.lisinski.online'],
        faucets: ['https://pipa.lisinski.online'],
        nativeCurrency: {
            name: 'Lisinski Ether',
            symbol: 'LISINS',
            decimals: 18,
        },
        infoURL: 'https://lisinski.online',
        shortName: 'lisinski',
        chainId: 385,
        networkId: 385,
    },
    {
        name: 'SX Network Mainnet',
        chain: 'SX',
        icon: 'SX',
        network: 'mainnet',
        rpc: ['https://rpc.sx.technology'],
        faucets: [],
        nativeCurrency: {
            name: 'SX Network',
            symbol: 'SX',
            decimals: 18,
        },
        infoURL: 'https://www.sx.technology',
        shortName: 'SX',
        chainId: 416,
        networkId: 416,
        explorers: [
            {
                name: 'SX Network Explorer',
                url: 'https://explorer.sx.technology',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Optimism Goerli Testnet',
        chain: 'ETH',
        rpc: ['https://goerli.optimism.io/'],
        faucets: [],
        nativeCurrency: {
            name: 'Görli Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://optimism.io',
        shortName: 'ogor',
        chainId: 420,
        networkId: 420,
    },
    {
        name: 'Rupaya',
        chain: 'RUPX',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Rupaya',
            symbol: 'RUPX',
            decimals: 18,
        },
        infoURL: 'https://www.rupx.io',
        shortName: 'rupx',
        chainId: 499,
        networkId: 499,
        slip44: 499,
    },
    {
        name: 'Double-A Chain Mainnet',
        chain: 'AAC',
        rpc: ['https://rpc.acuteangle.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Acuteangle Native Token',
            symbol: 'AAC',
            decimals: 18,
        },
        infoURL: 'https://www.acuteangle.com/',
        shortName: 'aac',
        chainId: 512,
        networkId: 512,
        slip44: 1512,
        explorers: [
            {
                name: 'aacscan',
                url: 'https://scan.acuteangle.com',
                standard: 'EIP3091',
            },
        ],
        icon: 'aac',
    },
    {
        name: 'Double-A Chain Testnet',
        chain: 'AAC',
        icon: 'aac',
        rpc: ['https://rpc-testnet.acuteangle.com'],
        faucets: ['https://scan-testnet.acuteangle.com/faucet'],
        nativeCurrency: {
            name: 'Acuteangle Native Token',
            symbol: 'AAC',
            decimals: 18,
        },
        infoURL: 'https://www.acuteangle.com/',
        shortName: 'aact',
        chainId: 513,
        networkId: 513,
        explorers: [
            {
                name: 'aacscan-testnet',
                url: 'https://scan-testnet.acuteangle.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'XT Smart Chain Mainnet',
        chain: 'XSC',
        icon: 'xsc',
        rpc: ['https://datarpc1.xsc.pub', 'https://datarpc2.xsc.pub', 'https://datarpc3.xsc.pub'],
        faucets: ['https://xsc.pub/faucet'],
        nativeCurrency: {
            name: 'XT Smart Chain Native Token',
            symbol: 'XT',
            decimals: 18,
        },
        infoURL: 'https://xsc.pub/',
        shortName: 'xt',
        chainId: 520,
        networkId: 1024,
        explorers: [
            {
                name: 'xscscan',
                url: 'https://xscscan.pub',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'F(x)Core Mainnet Network',
        chain: 'Fxcore',
        network: 'mainnet',
        rpc: ['https://fx-json-web3.functionx.io:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'Function X',
            symbol: 'FX',
            decimals: 18,
        },
        infoURL: 'https://functionx.io/',
        shortName: 'f(x)Core',
        chainId: 530,
        networkId: 530,
        icon: 'fxcore',
        explorers: [
            {
                name: 'FunctionX Explorer',
                url: 'https://fx-evm.functionx.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Candle',
        chain: 'Candle',
        rpc: ['https://candle-rpc.com/', 'https://rpc.cndlchain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'CANDLE',
            symbol: 'CNDL',
            decimals: 18,
        },
        infoURL: 'https://candlelabs.org/',
        shortName: 'CNDL',
        chainId: 534,
        networkId: 534,
        slip44: 674,
        explorers: [
            {
                name: 'candleexplorer',
                url: 'https://candleexplorer.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Vela1 Chain Mainnet',
        chain: 'VELA1',
        rpc: ['https://rpc.velaverse.io'],
        faucets: [],
        nativeCurrency: {
            name: 'CLASS COIN',
            symbol: 'CLASS',
            decimals: 18,
        },
        infoURL: 'https://velaverse.io',
        shortName: 'CLASS',
        chainId: 555,
        networkId: 555,
        explorers: [
            {
                name: 'Vela1 Chain Mainnet Explorer',
                url: 'https://exp.velaverse.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Tao Network',
        chain: 'TAO',
        rpc: [
            'https://rpc.testnet.tao.network',
            'http://rpc.testnet.tao.network:8545',
            'https://rpc.tao.network',
            'wss://rpc.tao.network',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Tao',
            symbol: 'TAO',
            decimals: 18,
        },
        infoURL: 'https://tao.network',
        shortName: 'tao',
        chainId: 558,
        networkId: 558,
    },
    {
        name: 'Metis Stardust Testnet',
        chain: 'ETH',
        rpc: ['https://stardust.metis.io/?owner=588'],
        faucets: [],
        nativeCurrency: {
            name: 'tMetis',
            symbol: 'METIS',
            decimals: 18,
        },
        infoURL: 'https://www.metis.io',
        shortName: 'metis-stardust',
        chainId: 588,
        networkId: 588,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://stardust-explorer.metis.io',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-4',
            bridges: [
                {
                    url: 'https://bridge.metis.io',
                },
            ],
        },
    },
    {
        name: 'Astar',
        chain: 'ASTR',
        rpc: ['https://rpc.astar.network:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'Astar',
            symbol: 'ASTR',
            decimals: 18,
        },
        infoURL: 'https://astar.network/',
        shortName: 'astr',
        chainId: 592,
        networkId: 592,
        icon: 'astar',
        explorers: [
            {
                name: 'subscan',
                url: 'https://astar.subscan.io',
                standard: 'none',
                icon: 'subscan',
            },
        ],
    },
    {
        name: 'Acala Mandala Testnet',
        chain: 'mACA',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Acala Mandala Token',
            symbol: 'mACA',
            decimals: 18,
        },
        infoURL: 'https://acala.network',
        shortName: 'maca',
        chainId: 595,
        networkId: 595,
    },
    {
        name: 'Karura Network Testnet',
        chain: 'KAR',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Karura Token',
            symbol: 'KAR',
            decimals: 18,
        },
        infoURL: 'https://karura.network',
        shortName: 'tkar',
        chainId: 596,
        networkId: 596,
        slip44: 596,
    },
    {
        name: 'Acala Network Testnet',
        chain: 'ACA',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Acala Token',
            symbol: 'ACA',
            decimals: 18,
        },
        infoURL: 'https://acala.network',
        shortName: 'taca',
        chainId: 597,
        networkId: 597,
        slip44: 597,
    },
    {
        name: 'Meshnyan testnet',
        chain: 'MeshTestChain',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Meshnyan Testnet Native Token',
            symbol: 'MESHT',
            decimals: 18,
        },
        infoURL: '',
        shortName: 'mesh-chain-testnet',
        chainId: 600,
        networkId: 600,
    },
    {
        name: 'SX Network Testnet',
        chain: 'SX',
        icon: 'SX',
        network: 'testnet',
        rpc: ['https://rpc.toronto.sx.technology'],
        faucets: ['https://faucet.toronto.sx.technology'],
        nativeCurrency: {
            name: 'SX Network',
            symbol: 'SX',
            decimals: 18,
        },
        infoURL: 'https://www.sx.technology',
        shortName: 'SX-Testnet',
        chainId: 647,
        networkId: 647,
        explorers: [
            {
                name: 'SX Network Toronto Explorer',
                url: 'https://explorer.toronto.sx.technology',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Pixie Chain Testnet',
        chain: 'PixieChain',
        rpc: ['https://http-testnet.chain.pixie.xyz', 'wss://ws-testnet.chain.pixie.xyz'],
        faucets: ['https://chain.pixie.xyz/faucet'],
        nativeCurrency: {
            name: 'Pixie Chain Testnet Native Token',
            symbol: 'PCTT',
            decimals: 18,
        },
        infoURL: 'https://scan-testnet.chain.pixie.xyz',
        shortName: 'pixie-chain-testnet',
        chainId: 666,
        networkId: 666,
    },
    {
        name: 'Karura Network',
        chain: 'KAR',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Karura Token',
            symbol: 'KAR',
            decimals: 18,
        },
        infoURL: 'https://karura.network',
        shortName: 'kar',
        chainId: 686,
        networkId: 686,
        slip44: 686,
    },
    {
        name: 'Star Social Testnet',
        chain: 'SNS',
        rpc: ['https://avastar.cc/ext/bc/C/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Social',
            symbol: 'SNS',
            decimals: 18,
        },
        infoURL: 'https://info.avastar.cc',
        shortName: 'SNS',
        chainId: 700,
        networkId: 700,
        explorers: [
            {
                name: 'starscan',
                url: 'https://avastar.info',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'BlockChain Station Mainnet',
        chain: 'BCS',
        rpc: ['https://rpc-mainnet.bcsdev.io', 'wss://rpc-ws-mainnet.bcsdev.io'],
        faucets: [],
        nativeCurrency: {
            name: 'BCS Token',
            symbol: 'BCS',
            decimals: 18,
        },
        infoURL: 'https://blockchainstation.io',
        shortName: 'bcs',
        chainId: 707,
        networkId: 707,
        explorers: [
            {
                name: 'BlockChain Station Explorer',
                url: 'https://explorer.bcsdev.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'BlockChain Station Testnet',
        chain: 'BCS',
        rpc: ['https://rpc-testnet.bcsdev.io', 'wss://rpc-ws-testnet.bcsdev.io'],
        faucets: ['https://faucet.bcsdev.io'],
        nativeCurrency: {
            name: 'BCS Testnet Token',
            symbol: 'tBCS',
            decimals: 18,
        },
        infoURL: 'https://blockchainstation.io',
        shortName: 'tbcs',
        chainId: 708,
        networkId: 708,
        explorers: [
            {
                name: 'BlockChain Station Explorer',
                url: 'https://testnet.bcsdev.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Factory 127 Testnet',
        chain: 'FETH',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Factory 127 Token',
            symbol: 'FETH',
            decimals: 18,
        },
        infoURL: 'https://www.factory127.com',
        shortName: 'tfeth',
        chainId: 721,
        networkId: 721,
        slip44: 721,
    },
    {
        name: 'OpenChain Testnet',
        chain: 'OpenChain Testnet',
        rpc: ['http://mainnet.openchain.info:8545', 'https://mainnet1.openchain.info'],
        faucets: ['https://faucet.openchain.info/'],
        nativeCurrency: {
            name: 'Openchain Testnet',
            symbol: 'TOPC',
            decimals: 18,
        },
        infoURL: 'https://testnet.openchain.info/',
        shortName: 'opc',
        chainId: 776,
        networkId: 776,
        explorers: [
            {
                name: 'OPEN CHAIN TESTNET',
                url: 'https://testnet.openchain.info',
                standard: 'none',
            },
        ],
    },
    {
        name: 'cheapETH',
        chain: 'cheapETH',
        rpc: ['https://node.cheapeth.org/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'cTH',
            symbol: 'cTH',
            decimals: 18,
        },
        infoURL: 'https://cheapeth.org/',
        shortName: 'cth',
        chainId: 777,
        networkId: 777,
    },
    {
        name: 'Acala Network',
        chain: 'ACA',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Acala Token',
            symbol: 'ACA',
            decimals: 18,
        },
        infoURL: 'https://acala.network',
        shortName: 'aca',
        chainId: 787,
        networkId: 787,
        slip44: 787,
    },
    {
        name: 'Aerochain Testnet',
        chain: 'Aerochain',
        network: 'testnet',
        rpc: ['https://testnet-rpc.aerochain.id/'],
        faucets: ['https://faucet.aerochain.id/'],
        nativeCurrency: {
            name: 'Aerochain Testnet',
            symbol: 'TAero',
            decimals: 18,
        },
        infoURL: 'https://aerochaincoin.org/',
        shortName: 'taero',
        chainId: 788,
        networkId: 788,
        explorers: [
            {
                name: 'aeroscan',
                url: 'https://testnet.aeroscan.id',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Haic',
        chain: 'Haic',
        rpc: ['https://orig.haichain.io/'],
        faucets: [],
        nativeCurrency: {
            name: 'Haicoin',
            symbol: 'HAIC',
            decimals: 18,
        },
        infoURL: 'https://www.haichain.io/',
        shortName: 'haic',
        chainId: 803,
        networkId: 803,
    },
    {
        name: 'Portal Fantasy Chain Test',
        chain: 'PF',
        icon: 'pf',
        network: 'testnet',
        rpc: ['https://subnets.avax.network/portal-fantasy/testnet/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Portal Fantasy Token',
            symbol: 'PFT',
            decimals: 18,
        },
        infoURL: 'https://portalfantasy.io',
        shortName: 'PFTEST',
        chainId: 808,
        networkId: 808,
        explorers: [],
    },
    {
        name: 'Callisto Mainnet',
        chain: 'CLO',
        rpc: ['https://clo-geth.0xinfra.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Callisto Mainnet Ether',
            symbol: 'CLO',
            decimals: 18,
        },
        infoURL: 'https://callisto.network',
        shortName: 'clo',
        chainId: 820,
        networkId: 1,
        slip44: 820,
    },
    {
        name: 'Callisto Testnet',
        chain: 'CLO',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Callisto Testnet Ether',
            symbol: 'TCLO',
            decimals: 18,
        },
        infoURL: 'https://callisto.network',
        shortName: 'tclo',
        chainId: 821,
        networkId: 2,
    },
    {
        name: 'Ambros Chain Mainnet',
        chain: 'ambroschain',
        rpc: ['https://api.ambros.network'],
        faucets: [],
        nativeCurrency: {
            name: 'AMBROS',
            symbol: 'AMBROS',
            decimals: 18,
        },
        infoURL: 'https://ambros.network',
        shortName: 'ambros',
        chainId: 880,
        networkId: 880,
        explorers: [
            {
                name: 'Ambros Chain Explorer',
                url: 'https://ambrosscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Wanchain',
        chain: 'WAN',
        rpc: ['https://gwan-ssl.wandevs.org:56891/'],
        faucets: [],
        nativeCurrency: {
            name: 'Wancoin',
            symbol: 'WAN',
            decimals: 18,
        },
        infoURL: 'https://www.wanscan.org',
        shortName: 'wan',
        chainId: 888,
        networkId: 888,
        slip44: 5718350,
    },
    {
        name: 'Garizon Testnet Stage0',
        chain: 'GAR',
        network: 'testnet',
        icon: 'garizon',
        rpc: ['https://s0-testnet.garizon.net/rpc'],
        faucets: ['https://faucet-testnet.garizon.com'],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-test-s0',
        chainId: 900,
        networkId: 900,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer-testnet.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Garizon Testnet Stage1',
        chain: 'GAR',
        network: 'testnet',
        icon: 'garizon',
        rpc: ['https://s1-testnet.garizon.net/rpc'],
        faucets: ['https://faucet-testnet.garizon.com'],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-test-s1',
        chainId: 901,
        networkId: 901,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer-testnet.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
        parent: {
            chain: 'eip155-900',
            type: 'shard',
        },
    },
    {
        name: 'Garizon Testnet Stage2',
        chain: 'GAR',
        network: 'testnet',
        icon: 'garizon',
        rpc: ['https://s2-testnet.garizon.net/rpc'],
        faucets: ['https://faucet-testnet.garizon.com'],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-test-s2',
        chainId: 902,
        networkId: 902,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer-testnet.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
        parent: {
            chain: 'eip155-900',
            type: 'shard',
        },
    },
    {
        name: 'Garizon Testnet Stage3',
        chain: 'GAR',
        network: 'testnet',
        icon: 'garizon',
        rpc: ['https://s3-testnet.garizon.net/rpc'],
        faucets: ['https://faucet-testnet.garizon.com'],
        nativeCurrency: {
            name: 'Garizon',
            symbol: 'GAR',
            decimals: 18,
        },
        infoURL: 'https://garizon.com',
        shortName: 'gar-test-s3',
        chainId: 903,
        networkId: 903,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer-testnet.garizon.com',
                icon: 'garizon',
                standard: 'EIP3091',
            },
        ],
        parent: {
            chain: 'eip155-900',
            type: 'shard',
        },
    },
    {
        name: 'Portal Fantasy Chain',
        chain: 'PF',
        icon: 'pf',
        network: 'mainnet',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Portal Fantasy Token',
            symbol: 'PFT',
            decimals: 18,
        },
        infoURL: 'https://portalfantasy.io',
        shortName: 'PF',
        chainId: 909,
        networkId: 909,
        explorers: [],
        status: 'incubating',
    },
    {
        name: 'PulseChain Testnet',
        shortName: 'tpls',
        chain: 'tPLS',
        chainId: 940,
        networkId: 940,
        infoURL: 'https://pulsechain.com/',
        rpc: ['https://rpc.v2.testnet.pulsechain.com/', 'wss://rpc.v2.testnet.pulsechain.com/'],
        faucets: ['https://faucet.v2.testnet.pulsechain.com/'],
        nativeCurrency: {
            name: 'Test Pulse',
            symbol: 'tPLS',
            decimals: 18,
        },
    },
    {
        name: 'PulseChain Testnet v2b',
        shortName: 't2bpls',
        chain: 't2bPLS',
        network: 'testnet-2b',
        chainId: 941,
        networkId: 941,
        infoURL: 'https://pulsechain.com/',
        rpc: ['https://rpc.v2b.testnet.pulsechain.com/', 'wss://rpc.v2b.testnet.pulsechain.com/'],
        faucets: ['https://faucet.v2b.testnet.pulsechain.com/'],
        nativeCurrency: {
            name: 'Test Pulse',
            symbol: 'tPLS',
            decimals: 18,
        },
    },
    {
        name: 'PulseChain Testnet v3',
        shortName: 't3pls',
        chain: 't3PLS',
        network: 'testnet-3',
        chainId: 942,
        networkId: 942,
        infoURL: 'https://pulsechain.com/',
        rpc: ['https://rpc.v3.testnet.pulsechain.com/', 'wss://rpc.v3.testnet.pulsechain.com/'],
        faucets: ['https://faucet.v3.testnet.pulsechain.com/'],
        nativeCurrency: {
            name: 'Test Pulse',
            symbol: 'tPLS',
            decimals: 18,
        },
    },
    {
        name: 'Nepal Blockchain Network',
        chain: 'YETI',
        rpc: ['https://api.nepalblockchain.dev', 'https://api.nepalblockchain.network'],
        faucets: ['https://faucet.nepalblockchain.network'],
        nativeCurrency: {
            name: 'Nepal Blockchain Network Ether',
            symbol: 'YETI',
            decimals: 18,
        },
        infoURL: 'https://nepalblockchain.network',
        shortName: 'yeti',
        chainId: 977,
        networkId: 977,
    },
    {
        name: 'TOP Mainnet EVM',
        chain: 'TOP',
        icon: 'top',
        rpc: ['ethapi.topnetwork.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://www.topnetwork.org/',
        shortName: 'top_evm',
        chainId: 980,
        networkId: 0,
        explorers: [
            {
                name: 'topscan.dev',
                url: 'https://www.topscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'TOP Mainnet',
        chain: 'TOP',
        icon: 'top',
        rpc: ['topapi.topnetwork.org'],
        faucets: [],
        nativeCurrency: {
            name: 'TOP',
            symbol: 'TOP',
            decimals: 6,
        },
        infoURL: 'https://www.topnetwork.org/',
        shortName: 'top',
        chainId: 989,
        networkId: 0,
        explorers: [
            {
                name: 'topscan.dev',
                url: 'https://www.topscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Lucky Network',
        chain: 'LN',
        rpc: ['https://rpc.luckynetwork.org', 'wss://ws.lnscan.org', 'https://rpc.lnscan.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Lucky',
            symbol: 'L99',
            decimals: 18,
        },
        infoURL: 'https://luckynetwork.org',
        shortName: 'ln',
        chainId: 998,
        networkId: 998,
        icon: 'lucky',
        explorers: [
            {
                name: 'blockscout',
                url: 'https://explorer.luckynetwork.org',
                standard: 'none',
            },
            {
                name: 'expedition',
                url: 'https://lnscan.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Wanchain Testnet',
        chain: 'WAN',
        rpc: ['https://gwan-ssl.wandevs.org:46891/'],
        faucets: [],
        nativeCurrency: {
            name: 'Wancoin',
            symbol: 'WAN',
            decimals: 18,
        },
        infoURL: 'https://testnet.wanscan.org',
        shortName: 'twan',
        chainId: 999,
        networkId: 999,
    },
    {
        name: 'GTON Mainnet',
        chain: 'GTON',
        rpc: ['https://rpc.gton.network/'],
        faucets: [],
        nativeCurrency: {
            name: 'GCD',
            symbol: 'GCD',
            decimals: 18,
        },
        infoURL: 'https://gton.capital',
        shortName: 'gton',
        chainId: 1000,
        networkId: 1000,
        explorers: [
            {
                name: 'GTON Network Explorer',
                url: 'https://explorer.gton.network',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-1',
        },
    },
    {
        name: 'Klaytn Testnet Baobab',
        chain: 'KLAY',
        rpc: ['https://api.baobab.klaytn.net:8651'],
        faucets: ['https://baobab.wallet.klaytn.com/access?next=faucet'],
        nativeCurrency: {
            name: 'KLAY',
            symbol: 'KLAY',
            decimals: 18,
        },
        infoURL: 'https://www.klaytn.com/',
        shortName: 'Baobab',
        chainId: 1001,
        networkId: 1001,
    },
    {
        name: 'Newton Testnet',
        chain: 'NEW',
        rpc: ['https://rpc1.newchain.newtonproject.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Newton',
            symbol: 'NEW',
            decimals: 18,
        },
        infoURL: 'https://www.newtonproject.org/',
        shortName: 'tnew',
        chainId: 1007,
        networkId: 1007,
    },
    {
        name: 'Eurus Mainnet',
        chain: 'EUN',
        network: 'eurus',
        rpc: ['https://mainnet.eurus.network/'],
        faucets: [],
        nativeCurrency: {
            name: 'Eurus',
            symbol: 'EUN',
            decimals: 18,
        },
        infoURL: 'https://eurus.network',
        shortName: 'eun',
        chainId: 1008,
        networkId: 1008,
        icon: 'eurus',
        explorers: [
            {
                name: 'eurusexplorer',
                url: 'https://explorer.eurus.network',
                icon: 'eurus',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Evrice Network',
        chain: 'EVC',
        rpc: ['https://meta.evrice.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Evrice',
            symbol: 'EVC',
            decimals: 18,
        },
        infoURL: 'https://evrice.com',
        shortName: 'EVC',
        chainId: 1010,
        networkId: 1010,
        slip44: 1020,
    },
    {
        name: 'Newton',
        chain: 'NEW',
        rpc: ['https://global.rpc.mainnet.newtonproject.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Newton',
            symbol: 'NEW',
            decimals: 18,
        },
        infoURL: 'https://www.newtonproject.org/',
        shortName: 'new',
        chainId: 1012,
        networkId: 1012,
    },
    {
        name: 'Sakura',
        chain: 'Sakura',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Sakura',
            symbol: 'SKU',
            decimals: 18,
        },
        infoURL: 'https://clover.finance/sakura',
        shortName: 'sku',
        chainId: 1022,
        networkId: 1022,
    },
    {
        name: 'Clover Testnet',
        chain: 'Clover',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Clover',
            symbol: 'CLV',
            decimals: 18,
        },
        infoURL: 'https://clover.finance',
        shortName: 'tclv',
        chainId: 1023,
        networkId: 1023,
    },
    {
        name: 'CLV Parachain',
        chain: 'CLV',
        rpc: ['https://api-para.clover.finance'],
        faucets: [],
        nativeCurrency: {
            name: 'CLV',
            symbol: 'CLV',
            decimals: 18,
        },
        infoURL: 'https://clv.org',
        shortName: 'clv',
        chainId: 1024,
        networkId: 1024,
    },
    {
        name: 'BitTorrent Chain Testnet',
        chain: 'BTTC',
        rpc: ['https://testrpc.bittorrentchain.io/'],
        faucets: [],
        nativeCurrency: {
            name: 'BitTorrent',
            symbol: 'BTT',
            decimals: 18,
        },
        infoURL: 'https://bittorrentchain.io/',
        shortName: 'tbtt',
        chainId: 1028,
        networkId: 1028,
        explorers: [
            {
                name: 'testbttcscan',
                url: 'https://testscan.bittorrentchain.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Conflux eSpace',
        chain: 'Conflux',
        network: 'mainnet',
        rpc: ['https://evm.confluxrpc.com'],
        faucets: [],
        nativeCurrency: {
            name: 'CFX',
            symbol: 'CFX',
            decimals: 18,
        },
        infoURL: 'https://confluxnetwork.org',
        shortName: 'cfx',
        chainId: 1030,
        networkId: 1030,
        icon: 'conflux',
        explorers: [
            {
                name: 'Conflux Scan',
                url: 'https://evm.confluxscan.net',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Metis Andromeda Mainnet',
        chain: 'ETH',
        rpc: ['https://andromeda.metis.io/?owner=1088'],
        faucets: [],
        nativeCurrency: {
            name: 'Metis',
            symbol: 'METIS',
            decimals: 18,
        },
        infoURL: 'https://www.metis.io',
        shortName: 'metis-andromeda',
        chainId: 1088,
        networkId: 1088,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://andromeda-explorer.metis.io',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-1',
            bridges: [
                {
                    url: 'https://bridge.metis.io',
                },
            ],
        },
    },
    {
        name: 'MathChain',
        chain: 'MATH',
        rpc: ['https://mathchain-asia.maiziqianbao.net/rpc', 'https://mathchain-us.maiziqianbao.net/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'MathChain',
            symbol: 'MATH',
            decimals: 18,
        },
        infoURL: 'https://mathchain.org',
        shortName: 'MATH',
        chainId: 1139,
        networkId: 1139,
    },
    {
        name: 'MathChain Testnet',
        chain: 'MATH',
        rpc: ['https://galois-hk.maiziqianbao.net/rpc'],
        faucets: ['https://scan.boka.network/#/Galois/faucet'],
        nativeCurrency: {
            name: 'MathChain',
            symbol: 'MATH',
            decimals: 18,
        },
        infoURL: 'https://mathchain.org',
        shortName: 'tMATH',
        chainId: 1140,
        networkId: 1140,
    },
    {
        name: 'Iora Chain',
        chain: 'IORA',
        network: 'iorachain',
        icon: 'iorachain',
        rpc: ['https://dataseed.iorachain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Iora',
            symbol: 'IORA',
            decimals: 18,
        },
        infoURL: 'https://iorachain.com',
        shortName: 'iora',
        chainId: 1197,
        networkId: 1197,
        explorers: [
            {
                name: 'ioraexplorer',
                url: 'https://explorer.iorachain.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Evanesco Testnet',
        chain: 'Evanesco Testnet',
        network: 'avis',
        rpc: ['https://seed5.evanesco.org:8547'],
        faucets: [],
        nativeCurrency: {
            name: 'AVIS',
            symbol: 'AVIS',
            decimals: 18,
        },
        infoURL: 'https://evanesco.org/',
        shortName: 'avis',
        chainId: 1201,
        networkId: 1201,
    },
    {
        name: 'World Trade Technical Chain Mainnet',
        chain: 'WTT',
        rpc: ['https://rpc.cadaut.com', 'wss://rpc.cadaut.com/ws'],
        faucets: [],
        nativeCurrency: {
            name: 'World Trade Token',
            symbol: 'WTT',
            decimals: 18,
        },
        infoURL: 'http://www.cadaut.com',
        shortName: 'wtt',
        chainId: 1202,
        networkId: 2048,
        explorers: [
            {
                name: 'WTTScout',
                url: 'https://explorer.cadaut.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Popcateum Mainnet',
        chain: 'POPCATEUM',
        rpc: ['https://dataseed.popcateum.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Popcat',
            symbol: 'POP',
            decimals: 18,
        },
        infoURL: 'https://popcateum.org',
        shortName: 'popcat',
        chainId: 1213,
        networkId: 1213,
        explorers: [
            {
                name: 'popcateum explorer',
                url: 'https://explorer.popcateum.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'EnterChain Mainnet',
        chain: 'ENTER',
        network: 'mainnet',
        rpc: ['https://tapi.entercoin.net/'],
        faucets: [],
        nativeCurrency: {
            name: 'EnterCoin',
            symbol: 'ENTER',
            decimals: 18,
        },
        infoURL: 'https://entercoin.net',
        shortName: 'enter',
        chainId: 1214,
        networkId: 1214,
        icon: 'enter',
        explorers: [
            {
                name: 'Enter Explorer - Expenter',
                url: 'https://explorer.entercoin.net',
                icon: 'enter',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'OM Platform Mainnet',
        chain: 'omplatform',
        network: 'mainnet',
        rpc: ['https://rpc-cnx.omplatform.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'OMCOIN',
            symbol: 'OM',
            decimals: 18,
        },
        infoURL: 'https://omplatform.com/',
        shortName: 'om',
        chainId: 1246,
        networkId: 1246,
        explorers: [
            {
                name: 'OMSCAN - Expenter',
                url: 'https://omscan.omplatform.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'HALO Mainnet',
        chain: 'HALO',
        rpc: ['https://nodes.halo.land'],
        faucets: [],
        nativeCurrency: {
            name: 'HALO',
            symbol: 'HO',
            decimals: 18,
        },
        infoURL: 'https://halo.land/#/',
        shortName: 'HO',
        chainId: 1280,
        networkId: 1280,
        explorers: [
            {
                name: 'HALOexplorer',
                url: 'https://browser.halo.land',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Moonbeam',
        chain: 'MOON',
        rpc: ['https://rpc.api.moonbeam.network', 'wss://wss.api.moonbeam.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Glimmer',
            symbol: 'GLMR',
            decimals: 18,
        },
        infoURL: 'https://moonbeam.network/networks/moonbeam/',
        shortName: 'mbeam',
        chainId: 1284,
        networkId: 1284,
        explorers: [
            {
                name: 'moonscan',
                url: 'https://moonbeam.moonscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Moonriver',
        chain: 'MOON',
        rpc: ['https://rpc.api.moonriver.moonbeam.network', 'wss://wss.api.moonriver.moonbeam.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Moonriver',
            symbol: 'MOVR',
            decimals: 18,
        },
        infoURL: 'https://moonbeam.network/networks/moonriver/',
        shortName: 'mriver',
        chainId: 1285,
        networkId: 1285,
        explorers: [
            {
                name: 'moonscan',
                url: 'https://moonriver.moonscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Moonrock old',
        chain: 'MOON',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Rocs',
            symbol: 'ROC',
            decimals: 18,
        },
        infoURL: '',
        shortName: 'mrock-old',
        chainId: 1286,
        networkId: 1286,
        status: 'deprecated',
    },
    {
        name: 'Moonbase Alpha',
        chain: 'MOON',
        rpc: ['https://rpc.api.moonbase.moonbeam.network', 'wss://wss.api.moonbase.moonbeam.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Dev',
            symbol: 'DEV',
            decimals: 18,
        },
        infoURL: 'https://docs.moonbeam.network/networks/testnet/',
        shortName: 'mbase',
        chainId: 1287,
        networkId: 1287,
        explorers: [
            {
                name: 'moonscan',
                url: 'https://moonbase.moonscan.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Moonrock',
        chain: 'MOON',
        rpc: ['https://rpc.api.moonrock.moonbeam.network', 'wss://wss.api.moonrock.moonbeam.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Rocs',
            symbol: 'ROC',
            decimals: 18,
        },
        infoURL: 'https://docs.moonbeam.network/learn/platform/networks/overview/',
        shortName: 'mrock',
        chainId: 1288,
        networkId: 1288,
    },
    {
        name: 'Boba Network Bobabase',
        chain: 'Bobabase',
        rpc: [
            'https://bobabase.boba.network',
            'wss://wss.bobabase.boba.network',
            'https://replica.bobabase.boba.network',
            'wss://replica-wss.bobabase.boba.network',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Boba Token',
            symbol: 'BOBA',
            decimals: 18,
        },
        infoURL: 'https://boba.network',
        shortName: 'Bobabase',
        chainId: 1297,
        networkId: 1297,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://blockexplorer.bobabase.boba.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Aitd Mainnet',
        chain: 'AITD',
        icon: 'aitd',
        rpc: ['http://walletrpc.aitd.io', 'http://node.aitd.io'],
        faucets: [],
        nativeCurrency: {
            name: 'AITD Mainnet',
            symbol: 'AITD',
            decimals: 18,
        },
        infoURL: 'https://www.aitd.io/',
        shortName: 'aitd',
        chainId: 1319,
        networkId: 1319,
        explorers: [
            {
                name: 'AITD Chain Explorer Mainnet',
                url: 'https://aitd-explorer-new.aitd.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Aitd Testnet',
        chain: 'AITD',
        icon: 'aitd',
        rpc: ['http://http-testnet.aitd.io'],
        faucets: ['https://aitd-faucet-pre.aitdcoin.com/'],
        nativeCurrency: {
            name: 'AITD Testnet',
            symbol: 'AITD',
            decimals: 18,
        },
        infoURL: 'https://www.aitd.io/',
        shortName: 'aitdtestnet',
        chainId: 1320,
        networkId: 1320,
        explorers: [
            {
                name: 'AITD Chain Explorer Testnet',
                url: 'https://block-explorer-testnet.aitd.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'CENNZnet old',
        chain: 'CENNZnet',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'CPAY',
            symbol: 'CPAY',
            decimals: 18,
        },
        infoURL: 'https://cennz.net',
        shortName: 'cennz-old',
        chainId: 1337,
        networkId: 1337,
        status: 'deprecated',
    },
    {
        name: 'Sherpax Mainnet',
        chain: 'Sherpax Mainnet',
        rpc: ['https://mainnet.sherpax.io/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'KSX',
            symbol: 'KSX',
            decimals: 18,
        },
        infoURL: 'https://sherpax.io/',
        shortName: 'Sherpax',
        chainId: 1506,
        networkId: 1506,
        explorers: [
            {
                name: 'Sherpax Mainnet Explorer',
                url: 'https://evm.sherpax.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Sherpax Testnet',
        chain: 'Sherpax Testnet',
        rpc: ['https://sherpax-testnet.chainx.org/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'KSX',
            symbol: 'KSX',
            decimals: 18,
        },
        infoURL: 'https://sherpax.io/',
        shortName: 'Sherpax Testnet',
        chainId: 1507,
        networkId: 1507,
        explorers: [
            {
                name: 'Sherpax Testnet Explorer',
                url: 'https://evm-pre.sherpax.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Catecoin Chain Mainnet',
        chain: 'Catechain',
        rpc: ['https://send.catechain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Catecoin',
            symbol: 'CATE',
            decimals: 18,
        },
        infoURL: 'https://catechain.com',
        shortName: 'cate',
        chainId: 1618,
        networkId: 1618,
    },
    {
        name: 'Atheios',
        chain: 'ATH',
        rpc: ['https://wallet.atheios.com:8797'],
        faucets: [],
        nativeCurrency: {
            name: 'Atheios Ether',
            symbol: 'ATH',
            decimals: 18,
        },
        infoURL: 'https://atheios.com',
        shortName: 'ath',
        chainId: 1620,
        networkId: 11235813,
        slip44: 1620,
    },
    {
        name: 'Btachain',
        chain: 'btachain',
        rpc: ['https://dataseed1.btachain.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'Bitcoin Asset',
            symbol: 'BTA',
            decimals: 18,
        },
        infoURL: 'https://bitcoinasset.io/',
        shortName: 'bta',
        chainId: 1657,
        networkId: 1657,
    },
    {
        name: 'LUDAN Mainnet',
        chain: 'LUDAN',
        rpc: ['https://rpc.ludan.org/'],
        faucets: [],
        nativeCurrency: {
            name: 'LUDAN',
            symbol: 'LUDAN',
            decimals: 18,
        },
        infoURL: 'https://www.ludan.org/',
        shortName: 'LUDAN',
        icon: 'ludan',
        chainId: 1688,
        networkId: 1688,
    },
    {
        name: 'Cube Chain Mainnet',
        chain: 'Cube',
        icon: 'cube',
        rpc: [
            'https://http-mainnet.cube.network',
            'wss://ws-mainnet.cube.network',
            'https://http-mainnet-sg.cube.network',
            'wss://ws-mainnet-sg.cube.network',
            'https://http-mainnet-us.cube.network',
            'wss://ws-mainnet-us.cube.network',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Cube Chain Native Token',
            symbol: 'CUBE',
            decimals: 18,
        },
        infoURL: 'https://www.cube.network',
        shortName: 'cube',
        chainId: 1818,
        networkId: 1818,
        slip44: 1818,
        explorers: [
            {
                name: 'cube-scan',
                url: 'https://cubescan.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Cube Chain Testnet',
        chain: 'Cube',
        icon: 'cube',
        rpc: [
            'https://http-testnet.cube.network',
            'wss://ws-testnet.cube.network',
            'https://http-testnet-sg.cube.network',
            'wss://ws-testnet-sg.cube.network',
            'https://http-testnet-jp.cube.network',
            'wss://ws-testnet-jp.cube.network',
            'https://http-testnet-us.cube.network',
            'wss://ws-testnet-us.cube.network',
        ],
        faucets: ['https://faucet.cube.network'],
        nativeCurrency: {
            name: 'Cube Chain Test Native Token',
            symbol: 'CUBET',
            decimals: 18,
        },
        infoURL: 'https://www.cube.network',
        shortName: 'cubet',
        chainId: 1819,
        networkId: 1819,
        slip44: 1819,
        explorers: [
            {
                name: 'cubetest-scan',
                url: 'https://testnet.cubescan.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Teslafunds',
        chain: 'TSF',
        rpc: ['https://tsfapi.europool.me'],
        faucets: [],
        nativeCurrency: {
            name: 'Teslafunds Ether',
            symbol: 'TSF',
            decimals: 18,
        },
        infoURL: 'https://teslafunds.io',
        shortName: 'tsf',
        chainId: 1856,
        networkId: 1,
    },
    {
        name: 'BON Network',
        chain: 'BON',
        network: 'testnet',
        rpc: ['http://rpc.boyanet.org:8545', 'ws://rpc.boyanet.org:8546'],
        faucets: [],
        nativeCurrency: {
            name: 'BOYACoin',
            symbol: 'BOY',
            decimals: 18,
        },
        infoURL: 'https://boyanet.org',
        shortName: 'boya',
        chainId: 1898,
        networkId: 1,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.boyanet.org:4001',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Eurus Testnet',
        chain: 'EUN',
        network: 'eurus-testnet',
        rpc: ['https://testnet.eurus.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Eurus',
            symbol: 'EUN',
            decimals: 18,
        },
        infoURL: 'https://eurus.network',
        shortName: 'euntest',
        chainId: 1984,
        networkId: 1984,
        icon: 'eurus',
        explorers: [
            {
                name: 'testnetexplorer',
                url: 'https://testnetexplorer.eurus.network',
                icon: 'eurus',
                standard: 'none',
            },
        ],
    },
    {
        name: 'EtherGem',
        chain: 'EGEM',
        rpc: ['https://jsonrpc.egem.io/custom'],
        faucets: [],
        nativeCurrency: {
            name: 'EtherGem Ether',
            symbol: 'EGEM',
            decimals: 18,
        },
        infoURL: 'https://egem.io',
        shortName: 'egem',
        chainId: 1987,
        networkId: 1987,
        slip44: 1987,
    },
    {
        name: 'Milkomeda C1 Mainnet',
        chain: 'milkAda',
        icon: 'milkomeda',
        network: 'mainnet',
        rpc: ['https://rpc-mainnet-cardano-evm.c1.milkomeda.com', 'wss://rpc-mainnet-cardano-evm.c1.milkomeda.com'],
        faucets: [],
        nativeCurrency: {
            name: 'milkAda',
            symbol: 'mADA',
            decimals: 18,
        },
        infoURL: 'https://milkomeda.com',
        shortName: 'milkAda',
        chainId: 2001,
        networkId: 2001,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://explorer-mainnet-cardano-evm.c1.milkomeda.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'CloudWalk Testnet',
        chain: 'CloudWalk Testnet',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'CloudWalk Native Token',
            symbol: 'CWN',
            decimals: 18,
        },
        infoURL: 'https://cloudwalk.io',
        shortName: 'cloudwalk_testnet',
        chainId: 2008,
        networkId: 2008,
        explorers: [
            {
                name: 'CloudWalk Testnet Explorer',
                url: 'https://explorer.testnet.cloudwalk.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'CloudWalk Mainnet',
        chain: 'CloudWalk Mainnet',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'CloudWalk Native Token',
            symbol: 'CWN',
            decimals: 18,
        },
        infoURL: 'https://cloudwalk.io',
        shortName: 'cloudwalk_mainnet',
        chainId: 2009,
        networkId: 2009,
        explorers: [
            {
                name: 'CloudWalk Mainnet Explorer',
                url: 'https://explorer.mainnet.cloudwalk.io',
                standard: 'none',
            },
        ],
    },
    {
        name: '420coin',
        chain: '420',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'Fourtwenty',
            symbol: '420',
            decimals: 18,
        },
        infoURL: 'https://420integrated.com',
        shortName: '420',
        chainId: 2020,
        networkId: 2020,
    },
    {
        name: 'Edgeware Mainnet',
        chain: 'EDG',
        rpc: ['https://mainnet1.edgewa.re'],
        faucets: [],
        nativeCurrency: {
            name: 'Edge',
            symbol: 'EDG',
            decimals: 18,
        },
        infoURL: 'http://edgewa.re',
        shortName: 'edg',
        chainId: 2021,
        networkId: 2021,
    },
    {
        name: 'Beresheet Testnet',
        chain: 'EDG',
        rpc: ['https://beresheet1.edgewa.re'],
        faucets: [],
        nativeCurrency: {
            name: 'Testnet Edge',
            symbol: 'tEDG',
            decimals: 18,
        },
        infoURL: 'http://edgewa.re',
        shortName: 'edgt',
        chainId: 2022,
        networkId: 2022,
    },
    {
        name: 'Taycan Testnet',
        chain: 'Taycan',
        rpc: ['https://test-taycan.hupayx.io'],
        faucets: ['https://ttaycan-faucet.hupayx.io/'],
        nativeCurrency: {
            name: 'test-Shuffle',
            symbol: 'tSFL',
            decimals: 18,
        },
        infoURL: 'https://hupayx.io',
        shortName: 'taycan-testnet',
        chainId: 2023,
        networkId: 2023,
        explorers: [
            {
                name: 'Taycan Explorer(Blockscout)',
                url: 'https://evmscan-test.hupayx.io',
                standard: 'none',
            },
            {
                name: 'Taycan Cosmos Explorer',
                url: 'https://cosmoscan-test.hupayx.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Rangers Protocol Mainnet',
        chain: 'Rangers',
        icon: 'rangers',
        rpc: ['https://mainnet.rangersprotocol.com/api/jsonrpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Rangers Protocol Gas',
            symbol: 'RPG',
            decimals: 18,
        },
        infoURL: 'https://rangersprotocol.com',
        shortName: 'rpg',
        chainId: 2025,
        networkId: 2025,
        slip44: 1008,
        explorers: [
            {
                name: 'rangersscan',
                url: 'https://scan.rangersprotocol.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Ecoball Mainnet',
        chain: 'ECO',
        rpc: ['https://api.ecoball.org/ecoball/'],
        faucets: [],
        nativeCurrency: {
            name: 'Ecoball Coin',
            symbol: 'ECO',
            decimals: 18,
        },
        infoURL: 'https://ecoball.org',
        shortName: 'eco',
        chainId: 2100,
        networkId: 2100,
        explorers: [
            {
                name: 'Ecoball Explorer',
                url: 'https://scan.ecoball.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Ecoball Testnet Espuma',
        chain: 'ECO',
        rpc: ['https://api.ecoball.org/espuma/'],
        faucets: [],
        nativeCurrency: {
            name: 'Espuma Coin',
            symbol: 'ECO',
            decimals: 18,
        },
        infoURL: 'https://ecoball.org',
        shortName: 'esp',
        chainId: 2101,
        networkId: 2101,
        explorers: [
            {
                name: 'Ecoball Testnet Explorer',
                url: 'https://espuma-scan.ecoball.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Findora Mainnet',
        chain: 'Findora',
        network: 'mainnet',
        rpc: ['https://prod-mainnet.prod.findora.org:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'FRA',
            symbol: 'FRA',
            decimals: 18,
        },
        infoURL: 'https://findora.org/',
        shortName: 'fra',
        chainId: 2152,
        networkId: 2152,
        explorers: [
            {
                name: 'findorascan',
                url: 'https://evm.findorascan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Findora Testnet',
        chain: 'Testnet-anvil',
        network: 'testnet',
        rpc: ['https://prod-testnet.prod.findora.org:8545/'],
        faucets: [],
        nativeCurrency: {
            name: 'FRA',
            symbol: 'FRA',
            decimals: 18,
        },
        infoURL: 'https://findora.org/',
        shortName: 'findora-testnet',
        chainId: 2153,
        networkId: 2153,
        explorers: [
            {
                name: 'findorascan',
                url: 'https://testnet-anvil.evm.findorascan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Evanesco Mainnet',
        chain: 'EVA',
        network: 'mainnet',
        rpc: ['https://seed4.evanesco.org:8546'],
        faucets: [],
        nativeCurrency: {
            name: 'EVA',
            symbol: 'EVA',
            decimals: 18,
        },
        infoURL: 'https://evanesco.org/',
        shortName: 'evanesco',
        chainId: 2213,
        networkId: 2213,
        icon: 'evanesco',
        explorers: [
            {
                name: 'Evanesco Explorer',
                url: 'https://explorer.evanesco.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Kava EVM Testnet',
        chain: 'KAVA',
        network: 'testnet',
        rpc: ['https://evm.testnet.kava.io', 'wss://wevm.testnet.kava.io'],
        faucets: ['https://faucet.kava.io'],
        nativeCurrency: {
            name: 'TKava',
            symbol: 'TKAVA',
            decimals: 18,
        },
        infoURL: 'https://www.kava.io',
        shortName: 'tkava',
        chainId: 2221,
        networkId: 2221,
        icon: 'kava',
        explorers: [
            {
                name: 'Kava Testnet Explorer',
                url: 'https://explorer.testnet.kava.io',
                standard: 'EIP3091',
                icon: 'kava',
            },
        ],
    },
    {
        name: 'Kava EVM',
        chain: 'KAVA',
        network: 'mainnet',
        rpc: ['https://evm.kava.io', 'https://evm2.kava.io', 'wss://wevm.kava.io', 'wss://wevm2.kava.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Kava',
            symbol: 'KAVA',
            decimals: 18,
        },
        infoURL: 'https://www.kava.io',
        shortName: 'kava',
        chainId: 2222,
        networkId: 2222,
        icon: 'kava',
        explorers: [
            {
                name: 'Kava EVM Explorer',
                url: 'https://explorer.kava.io',
                standard: 'EIP3091',
                icon: 'kava',
            },
        ],
    },
    {
        name: 'VChain Mainnet',
        chain: 'VChain',
        rpc: ['https://bc.vcex.xyz'],
        faucets: [],
        nativeCurrency: {
            name: 'VNDT',
            symbol: 'VNDT',
            decimals: 18,
        },
        infoURL: 'https://bo.vcex.xyz/',
        shortName: 'VChain',
        chainId: 2223,
        networkId: 2223,
        explorers: [
            {
                name: 'VChain Scan',
                url: 'https://scan.vcex.xyz',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Kortho Mainnet',
        chain: 'Kortho Chain',
        rpc: ['https://www.kortho-chain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'KorthoChain',
            symbol: 'KTO',
            decimals: 11,
        },
        infoURL: 'https://www.kortho.io/',
        shortName: 'ktoc',
        chainId: 2559,
        networkId: 2559,
    },
    {
        name: 'TechPay Mainnet',
        chain: 'TPC',
        network: 'mainnet',
        rpc: ['https://api.techpay.io/'],
        faucets: [],
        nativeCurrency: {
            name: 'TechPay',
            symbol: 'TPC',
            decimals: 18,
        },
        infoURL: 'https://techpay.io/',
        shortName: 'tpc',
        chainId: 2569,
        networkId: 2569,
        icon: 'techpay',
        explorers: [
            {
                name: 'tpcscan',
                url: 'https://tpcscan.com',
                icon: 'techpay',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'EZChain C-Chain Mainnet',
        chain: 'EZC',
        rpc: ['https://api.ezchain.com/ext/bc/C/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'EZChain',
            symbol: 'EZC',
            decimals: 18,
        },
        infoURL: 'https://ezchain.com',
        shortName: 'EZChain',
        chainId: 2612,
        networkId: 2612,
        icon: 'ezchain',
        explorers: [
            {
                name: 'ezchain',
                url: 'https://cchain-explorer.ezchain.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'EZChain C-Chain Testnet',
        chain: 'EZC',
        rpc: ['https://testnet-api.ezchain.com/ext/bc/C/rpc'],
        faucets: ['https://testnet-faucet.ezchain.com'],
        nativeCurrency: {
            name: 'EZChain',
            symbol: 'EZC',
            decimals: 18,
        },
        infoURL: 'https://ezchain.com',
        shortName: 'Fuji-EZChain',
        chainId: 2613,
        networkId: 2613,
        icon: 'ezchain',
        explorers: [
            {
                name: 'ezchain',
                url: 'https://testnet-cchain-explorer.ezchain.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'CENNZnet Rata',
        chain: 'CENNZnet',
        network: 'rata',
        rpc: ['https://rata.centrality.me/public'],
        faucets: ['https://app-faucet.centrality.me'],
        nativeCurrency: {
            name: 'CPAY',
            symbol: 'CPAY',
            decimals: 18,
        },
        infoURL: 'https://cennz.net',
        shortName: 'cennz-r',
        chainId: 3000,
        networkId: 3000,
        icon: 'cennz',
    },
    {
        name: 'CENNZnet Nikau',
        chain: 'CENNZnet',
        network: 'nikau',
        rpc: ['https://nikau.centrality.me/public'],
        faucets: ['https://app-faucet.centrality.me'],
        nativeCurrency: {
            name: 'CPAY',
            symbol: 'CPAY',
            decimals: 18,
        },
        infoURL: 'https://cennz.net',
        shortName: 'cennz-n',
        chainId: 3001,
        networkId: 3001,
        icon: 'cennz',
        explorers: [
            {
                name: 'UNcover',
                url: 'https://www.uncoverexplorer.com/?network=Nikau',
                standard: 'none',
            },
        ],
    },
    {
        name: 'ZCore Testnet',
        chain: 'Beach',
        icon: 'zcore',
        rpc: ['https://rpc-testnet.zcore.cash'],
        faucets: ['https://faucet.zcore.cash'],
        nativeCurrency: {
            name: 'ZCore',
            symbol: 'ZCR',
            decimals: 18,
        },
        infoURL: 'https://zcore.cash',
        shortName: 'zcrbeach',
        chainId: 3331,
        networkId: 3331,
    },
    {
        name: 'Web3Q Testnet',
        chain: 'Web3Q',
        rpc: ['https://testnet.web3q.io:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'Web3Q',
            symbol: 'W3Q',
            decimals: 18,
        },
        infoURL: 'https://testnet.web3q.io/home.w3q/',
        shortName: 'w3q-t',
        chainId: 3333,
        networkId: 3333,
        explorers: [
            {
                name: 'w3q-testnet',
                url: 'https://explorer.testnet.web3q.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Web3Q Galileo',
        chain: 'Web3Q',
        rpc: ['https://galileo.web3q.io:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'Web3Q',
            symbol: 'W3Q',
            decimals: 18,
        },
        infoURL: 'https://galileo.web3q.io/home.w3q/',
        shortName: 'w3q-g',
        chainId: 3334,
        networkId: 3334,
        explorers: [
            {
                name: 'w3q-galileo',
                url: 'https://explorer.galileo.web3q.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Paribu Net Mainnet',
        chain: 'PRB',
        network: 'Paribu Net',
        rpc: ['https://rpc.paribu.network'],
        faucets: [],
        nativeCurrency: {
            name: 'PRB',
            symbol: 'PRB',
            decimals: 18,
        },
        infoURL: 'https://net.paribu.com',
        shortName: 'prb',
        chainId: 3400,
        networkId: 3400,
        icon: 'prb',
        explorers: [
            {
                name: 'Paribu Net Explorer',
                url: 'https://explorer.paribu.network',
                icon: 'explorer',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Paribu Net Testnet',
        chain: 'PRB',
        network: 'Paribu Net',
        rpc: ['https://rpc.testnet.paribuscan.com'],
        faucets: ['https://faucet.paribuscan.com'],
        nativeCurrency: {
            name: 'PRB',
            symbol: 'PRB',
            decimals: 18,
        },
        infoURL: 'https://net.paribu.com',
        shortName: 'prbtestnet',
        chainId: 3500,
        networkId: 3500,
        icon: 'prb',
        explorers: [
            {
                name: 'Paribu Net Testnet Explorer',
                url: 'https://testnet.paribuscan.com',
                icon: 'explorer',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'JFIN Chain',
        chain: 'JFIN',
        rpc: ['https://rpc.jfinchain.com'],
        faucets: [],
        nativeCurrency: {
            name: 'JFIN Coin',
            symbol: 'jfin',
            decimals: 18,
        },
        infoURL: 'https://jfinchain.com',
        shortName: 'jfin',
        chainId: 3501,
        networkId: 3501,
        explorers: [
            {
                name: 'JFIN Chain Explorer',
                url: 'https://exp.jfinchain.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Bittex Mainnet',
        chain: 'BTX',
        rpc: ['https://rpc1.bittexscan.info', 'https://rpc2.bittexscan.info'],
        faucets: [],
        nativeCurrency: {
            name: 'Bittex',
            symbol: 'BTX',
            decimals: 18,
        },
        infoURL: 'https://bittexscan.com',
        shortName: 'btx',
        chainId: 3690,
        networkId: 3690,
        icon: 'ethereum',
        explorers: [
            {
                name: 'bittexscan',
                url: 'https://bittexscan.com',
                icon: 'etherscan',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Crossbell',
        chain: 'Crossbell',
        network: 'mainnet',
        rpc: ['https://rpc.crossbell.io'],
        faucets: ['https://faucet.crossbell.io'],
        nativeCurrency: {
            name: 'Crossbell Token',
            symbol: 'CSB',
            decimals: 18,
        },
        infoURL: 'https://crossbell.io',
        shortName: 'csb',
        chainId: 3737,
        networkId: 3737,
        icon: 'crossbell',
        explorers: [
            {
                name: 'Crossbell Explorer',
                url: 'https://scan.crossbell.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'DYNO Mainnet',
        chain: 'DYNO',
        rpc: ['https://api.dynoprotocol.com'],
        faucets: ['https://faucet.dynoscan.io'],
        nativeCurrency: {
            name: 'DYNO Token',
            symbol: 'DYNO',
            decimals: 18,
        },
        infoURL: 'https://dynoprotocol.com',
        shortName: 'dyno',
        chainId: 3966,
        networkId: 3966,
        explorers: [
            {
                name: 'DYNO Explorer',
                url: 'https://dynoscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'DYNO Testnet',
        chain: 'DYNO',
        rpc: ['https://tapi.dynoprotocol.com'],
        faucets: ['https://faucet.dynoscan.io'],
        nativeCurrency: {
            name: 'DYNO Token',
            symbol: 'tDYNO',
            decimals: 18,
        },
        infoURL: 'https://dynoprotocol.com',
        shortName: 'tdyno',
        chainId: 3967,
        networkId: 3967,
        explorers: [
            {
                name: 'DYNO Explorer',
                url: 'https://testnet.dynoscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'YuanChain Mainnet',
        chain: 'YCC',
        network: 'mainnet',
        rpc: ['https://mainnet.yuan.org/eth'],
        faucets: [],
        nativeCurrency: {
            name: 'YCC',
            symbol: 'YCC',
            decimals: 18,
        },
        infoURL: 'https://www.yuan.org',
        shortName: 'ycc',
        chainId: 3999,
        networkId: 3999,
        icon: 'ycc',
        explorers: [
            {
                name: 'YuanChain Explorer',
                url: 'https://mainnet.yuan.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Fantom Testnet',
        chain: 'FTM',
        rpc: ['https://rpc.testnet.fantom.network'],
        faucets: ['https://faucet.fantom.network'],
        nativeCurrency: {
            name: 'Fantom',
            symbol: 'FTM',
            decimals: 18,
        },
        infoURL: 'https://docs.fantom.foundation/quick-start/short-guide#fantom-testnet',
        shortName: 'tftm',
        chainId: 4002,
        networkId: 4002,
        icon: 'fantom',
        explorers: [
            {
                name: 'ftmscan',
                url: 'https://testnet.ftmscan.com',
                icon: 'ftmscan',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Boba Network Bobaopera Testnet',
        chain: 'Bobaopera Testnet',
        rpc: [
            'https://testnet.bobaopera.boba.network',
            'wss://wss.testnet.bobaopera.boba.network',
            'https://replica.testnet.bobaopera.boba.network',
            'wss://replica-wss.testnet.bobaopera.boba.network',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Boba Token',
            symbol: 'BOBA',
            decimals: 18,
        },
        infoURL: 'https://boba.network',
        shortName: 'Bobaopera Testnet',
        chainId: 4051,
        networkId: 4051,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://blockexplorer.testnet.bobaopera.boba.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'AIOZ Network Testnet',
        chain: 'AIOZ',
        network: 'testnet',
        icon: 'aioz',
        rpc: ['https://eth-ds.testnet.aioz.network'],
        faucets: [],
        nativeCurrency: {
            name: 'testAIOZ',
            symbol: 'AIOZ',
            decimals: 18,
        },
        infoURL: 'https://aioz.network',
        shortName: 'aioz-testnet',
        chainId: 4102,
        networkId: 4102,
        slip44: 60,
        explorers: [
            {
                name: 'AIOZ Network Testnet Explorer',
                url: 'https://testnet.explorer.aioz.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'PHI Network',
        chain: 'PHI',
        network: 'mainnet',
        rpc: ['https://rpc1.phi.network', 'https://rpc2.phi.network'],
        faucets: [],
        nativeCurrency: {
            name: 'PHI',
            symbol: 'Φ',
            decimals: 18,
        },
        infoURL: 'https://phi.network',
        shortName: 'PHI',
        chainId: 4181,
        networkId: 4181,
        icon: 'phi',
        explorers: [
            {
                name: 'PHI Explorer',
                url: 'https://explorer.phi.network',
                icon: 'phi',
                standard: 'none',
            },
        ],
    },
    {
        name: 'IoTeX Network Mainnet',
        chain: 'iotex.io',
        rpc: ['https://babel-api.mainnet.iotex.io'],
        faucets: [],
        nativeCurrency: {
            name: 'IoTeX',
            symbol: 'IOTX',
            decimals: 18,
        },
        infoURL: 'https://iotex.io',
        shortName: 'iotex-mainnet',
        chainId: 4689,
        networkId: 4689,
        explorers: [
            {
                name: 'iotexscan',
                url: 'https://iotexscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'IoTeX Network Testnet',
        chain: 'iotex.io',
        rpc: ['https://babel-api.testnet.iotex.io'],
        faucets: ['https://faucet.iotex.io/'],
        nativeCurrency: {
            name: 'IoTeX',
            symbol: 'IOTX',
            decimals: 18,
        },
        infoURL: 'https://iotex.io',
        shortName: 'iotex-testnet',
        chainId: 4690,
        networkId: 4690,
        explorers: [
            {
                name: 'testnet iotexscan',
                url: 'https://testnet.iotexscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Venidium Testnet',
        chain: 'XVM',
        rpc: ['https://rpc-evm-testnet.venidium.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Venidium',
            symbol: 'XVM',
            decimals: 18,
        },
        infoURL: 'https://venidium.io',
        shortName: 'txvm',
        chainId: 4918,
        networkId: 4918,
        explorers: [
            {
                name: 'Venidium EVM Testnet Explorer',
                url: 'https://evm-testnet.venidiumexplorer.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Venidium Mainnet',
        chain: 'XVM',
        icon: 'venidium',
        rpc: ['https://rpc.venidium.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Venidium',
            symbol: 'XVM',
            decimals: 18,
        },
        infoURL: 'https://venidium.io',
        shortName: 'xvm',
        chainId: 4919,
        networkId: 4919,
        explorers: [
            {
                name: 'Venidium Explorer',
                url: 'https://evm.venidiumexplorer.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'TLChain Network Mainnet',
        chain: 'TLC',
        icon: 'tlc',
        rpc: ['https://mainnet-rpc.tlxscan.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'TLChain Network',
            symbol: 'TLC',
            decimals: 18,
        },
        infoURL: 'https://tlchain.network/',
        shortName: 'tlc',
        chainId: 5177,
        networkId: 5177,
        explorers: [
            {
                name: 'TLChain Explorer',
                url: 'https://explorer.tlchain.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'EraSwap Mainnet',
        chain: 'ESN',
        icon: 'eraswap',
        rpc: ['https://mainnet.eraswap.network', 'https://rpc-mumbai.mainnet.eraswap.network'],
        faucets: [],
        nativeCurrency: {
            name: 'EraSwap',
            symbol: 'ES',
            decimals: 18,
        },
        infoURL: 'https://eraswap.info/',
        shortName: 'es',
        chainId: 5197,
        networkId: 5197,
    },
    {
        name: 'Uzmi Network Mainnet',
        chain: 'UZMI',
        rpc: ['https://network.uzmigames.com.br/'],
        faucets: [],
        nativeCurrency: {
            name: 'UZMI',
            symbol: 'UZMI',
            decimals: 18,
        },
        infoURL: 'https://uzmigames.com.br/',
        shortName: 'UZMI',
        chainId: 5315,
        networkId: 5315,
    },
    {
        name: 'Nahmii Mainnet',
        chain: 'Nahmii',
        network: 'mainnet',
        rpc: ['https://l2.nahmii.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://nahmii.io',
        shortName: 'Nahmii',
        chainId: 5551,
        networkId: 5551,
        icon: 'nahmii',
        explorers: [
            {
                name: 'Nahmii mainnet explorer',
                url: 'https://explorer.nahmii.io',
                icon: 'nahmii',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-1',
            bridges: [
                {
                    url: 'https://bridge.nahmii.io',
                },
            ],
        },
    },
    {
        name: 'Nahmii Testnet',
        chain: 'Nahmii',
        network: 'testnet',
        rpc: ['https://l2.testnet.nahmii.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://nahmii.io',
        shortName: 'Nahmii testnet',
        chainId: 5553,
        networkId: 5553,
        icon: 'nahmii',
        explorers: [
            {
                name: 'blockscout',
                url: 'https://explorer.testnet.nahmii.io',
                icon: 'nahmii',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-3',
            bridges: [
                {
                    url: 'https://bridge.nahmii.io',
                },
            ],
        },
    },
    {
        name: 'Syscoin Tanenbaum Testnet',
        chain: 'SYS',
        rpc: ['https://rpc.tanenbaum.io', 'wss://rpc.tanenbaum.io/wss'],
        faucets: ['https://faucet.tanenbaum.io'],
        nativeCurrency: {
            name: 'Testnet Syscoin',
            symbol: 'tSYS',
            decimals: 18,
        },
        infoURL: 'https://syscoin.org',
        shortName: 'tsys',
        chainId: 5700,
        networkId: 5700,
        explorers: [
            {
                name: 'Syscoin Testnet Block Explorer',
                url: 'https://tanenbaum.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Digest Swarm Chain',
        chain: 'DSC',
        icon: 'swarmchain',
        rpc: ['https://rpc.digestgroup.ltd'],
        faucets: [],
        nativeCurrency: {
            name: 'DigestCoin',
            symbol: 'DGCC',
            decimals: 18,
        },
        infoURL: 'https://digestgroup.ltd',
        shortName: 'dgcc',
        chainId: 5777,
        networkId: 5777,
        explorers: [
            {
                name: 'swarmexplorer',
                url: 'https://explorer.digestgroup.ltd',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Ontology Testnet',
        chain: 'Ontology',
        rpc: [
            'http://polaris1.ont.io:20339',
            'http://polaris2.ont.io:20339',
            'http://polaris3.ont.io:20339',
            'http://polaris4.ont.io:20339',
            'https://polaris1.ont.io:10339',
            'https://polaris2.ont.io:10339',
            'https://polaris3.ont.io:10339',
            'https://polaris4.ont.io:10339',
        ],
        faucets: ['https://developer.ont.io/'],
        nativeCurrency: {
            name: 'ONG',
            symbol: 'ONG',
            decimals: 18,
        },
        infoURL: 'https://ont.io/',
        shortName: 'Ontology Testnet',
        chainId: 5851,
        networkId: 5851,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.ont.io/testnet',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Wegochain Rubidium Mainnet',
        chain: 'RBD',
        rpc: ['https://proxy.wegochain.io', 'http://wallet.wegochain.io:7764'],
        faucets: [],
        nativeCurrency: {
            name: 'Rubid',
            symbol: 'RBD',
            decimals: 18,
        },
        infoURL: 'https://www.wegochain.io',
        shortName: 'rbd',
        chainId: 5869,
        networkId: 5869,
        explorers: [
            {
                name: 'wegoscan2',
                url: 'https://scan2.wegochain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Pixie Chain Mainnet',
        chain: 'PixieChain',
        rpc: ['https://http-mainnet.chain.pixie.xyz', 'wss://ws-mainnet.chain.pixie.xyz'],
        faucets: [],
        nativeCurrency: {
            name: 'Pixie Chain Native Token',
            symbol: 'PIX',
            decimals: 18,
        },
        infoURL: 'https://chain.pixie.xyz',
        shortName: 'pixie-chain',
        chainId: 6626,
        networkId: 6626,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://scan.chain.pixie.xyz',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Tomb Chain Mainnet',
        chain: 'Tomb Chain',
        rpc: ['https://rpc.tombchain.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'Tomb',
            symbol: 'TOMB',
            decimals: 18,
        },
        infoURL: 'https://tombchain.com/',
        shortName: 'tombchain',
        chainId: 6969,
        networkId: 6969,
        explorers: [
            {
                name: 'tombscout',
                url: 'https://tombscout.com',
                standard: 'none',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-250',
            bridges: [
                {
                    url: 'https://beta-bridge.lif3.com/',
                },
            ],
        },
    },
    {
        name: 'Ella the heart',
        chain: 'ella',
        icon: 'ella',
        rpc: ['https://rpc.ella.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Ella',
            symbol: 'ELLA',
            decimals: 18,
        },
        infoURL: 'https://ella.network',
        shortName: 'ELLA',
        chainId: 7027,
        networkId: 7027,
        explorers: [
            {
                name: 'Ella',
                url: 'https://ella.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Shyft Mainnet',
        chain: 'SHYFT',
        icon: 'shyft',
        rpc: ['https://rpc.shyft.network/'],
        faucets: [],
        nativeCurrency: {
            name: 'Shyft',
            symbol: 'SHYFT',
            decimals: 18,
        },
        infoURL: 'https://shyft.network',
        shortName: 'shyft',
        chainId: 7341,
        networkId: 7341,
        slip44: 2147490989,
        explorers: [
            {
                name: 'Shyft BX',
                url: 'https://bx.shyft.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Rise of the Warbots Testnet',
        chain: 'nmactest',
        rpc: [
            'https://testnet1.riseofthewarbots.com',
            'https://testnet2.riseofthewarbots.com',
            'https://testnet3.riseofthewarbots.com',
            'https://testnet4.riseofthewarbots.com',
            'https://testnet5.riseofthewarbots.com',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Nano Machines',
            symbol: 'NMAC',
            decimals: 18,
        },
        infoURL: 'https://riseofthewarbots.com/',
        shortName: 'Rise of the Warbots Testnet',
        chainId: 7777,
        networkId: 7777,
        explorers: [
            {
                name: 'avascan',
                url: 'https://testnet.avascan.info/blockchain/2mZ9doojfwHzXN3VXDQELKnKyZYxv7833U8Yq5eTfFx3hxJtiy',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Hazlor Testnet',
        chain: 'SCAS',
        rpc: ['https://hatlas.rpc.hazlor.com:8545', 'wss://hatlas.rpc.hazlor.com:8546'],
        faucets: ['https://faucet.hazlor.com'],
        nativeCurrency: {
            name: 'Hazlor Test Coin',
            symbol: 'TSCAS',
            decimals: 18,
        },
        infoURL: 'https://hazlor.com',
        shortName: 'tscas',
        chainId: 7878,
        networkId: 7878,
        explorers: [
            {
                name: 'Hazlor Testnet Explorer',
                url: 'https://explorer.hazlor.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Teleport',
        chain: 'Teleport',
        rpc: ['https://evm-rpc.teleport.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Tele',
            symbol: 'TELE',
            decimals: 18,
        },
        infoURL: 'https://teleport.network',
        shortName: 'teleport',
        chainId: 8000,
        networkId: 8000,
        icon: 'teleport',
        explorers: [
            {
                name: 'Teleport EVM Explorer (Blockscout)',
                url: 'https://evm-explorer.teleport.network',
                standard: 'none',
                icon: 'teleport',
            },
            {
                name: 'Teleport Cosmos Explorer (Big Dipper)',
                url: 'https://explorer.teleport.network',
                standard: 'none',
                icon: 'teleport',
            },
        ],
    },
    {
        name: 'Teleport Testnet',
        chain: 'Teleport',
        rpc: ['https://evm-rpc.testnet.teleport.network'],
        faucets: ['https://chain-docs.teleport.network/testnet/faucet.html'],
        nativeCurrency: {
            name: 'Tele',
            symbol: 'TELE',
            decimals: 18,
        },
        infoURL: 'https://teleport.network',
        shortName: 'teleport-testnet',
        chainId: 8001,
        networkId: 8001,
        icon: 'teleport',
        explorers: [
            {
                name: 'Teleport EVM Explorer (Blockscout)',
                url: 'https://evm-explorer.testnet.teleport.network',
                standard: 'none',
                icon: 'teleport',
            },
            {
                name: 'Teleport Cosmos Explorer (Big Dipper)',
                url: 'https://explorer.testnet.teleport.network',
                standard: 'none',
                icon: 'teleport',
            },
        ],
    },
    {
        name: 'MDGL Testnet',
        chain: 'MDGL',
        rpc: ['https://testnet.mdgl.io'],
        faucets: [],
        nativeCurrency: {
            name: 'MDGL Token',
            symbol: 'MDGLT',
            decimals: 18,
        },
        infoURL: 'https://mdgl.io',
        shortName: 'mdgl',
        chainId: 8029,
        networkId: 8029,
    },
    {
        name: 'GeneChain Adenine Testnet',
        chain: 'GeneChain',
        rpc: ['https://rpc-testnet.genechain.io'],
        faucets: ['https://faucet.genechain.io'],
        nativeCurrency: {
            name: 'Testnet RNA',
            symbol: 'tRNA',
            decimals: 18,
        },
        infoURL: 'https://scan-testnet.genechain.io/',
        shortName: 'GeneChainAdn',
        chainId: 8080,
        networkId: 8080,
        explorers: [
            {
                name: 'GeneChain Adenine Testnet Scan',
                url: 'https://scan-testnet.genechain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Klaytn Mainnet Cypress',
        chain: 'KLAY',
        rpc: ['https://public-node-api.klaytnapi.com/v1/cypress'],
        faucets: [],
        nativeCurrency: {
            name: 'KLAY',
            symbol: 'KLAY',
            decimals: 18,
        },
        infoURL: 'https://www.klaytn.com/',
        shortName: 'Cypress',
        chainId: 8217,
        networkId: 8217,
        slip44: 8217,
        explorers: [
            {
                name: 'Klaytnscope',
                url: 'https://scope.klaytn.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'KorthoTest',
        chain: 'Kortho',
        rpc: ['https://www.krotho-test.net'],
        faucets: [],
        nativeCurrency: {
            name: 'Kortho Test',
            symbol: 'KTO',
            decimals: 11,
        },
        infoURL: 'https://www.kortho.io/',
        shortName: 'Kortho',
        chainId: 8285,
        networkId: 8285,
    },
    {
        name: 'TOOL Global Mainnet',
        chain: 'OLO',
        rpc: ['https://mainnet-web3.wolot.io'],
        faucets: [],
        nativeCurrency: {
            name: 'TOOL Global',
            symbol: 'OLO',
            decimals: 18,
        },
        infoURL: 'https://ibdt.io',
        shortName: 'olo',
        chainId: 8723,
        networkId: 8723,
        slip44: 479,
        explorers: [
            {
                name: 'OLO Block Explorer',
                url: 'https://www.olo.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'TOOL Global Testnet',
        chain: 'OLO',
        rpc: ['https://testnet-web3.wolot.io'],
        faucets: ['https://testnet-explorer.wolot.io'],
        nativeCurrency: {
            name: 'TOOL Global',
            symbol: 'OLO',
            decimals: 18,
        },
        infoURL: 'https://testnet-explorer.wolot.io',
        shortName: 'tolo',
        chainId: 8724,
        networkId: 8724,
        slip44: 479,
    },
    {
        name: 'Ambros Chain Testnet',
        chain: 'ambroschain',
        rpc: ['https://api.testnet.ambros.network'],
        faucets: [],
        nativeCurrency: {
            name: 'AMBROS',
            symbol: 'AMBROS',
            decimals: 18,
        },
        infoURL: 'https://test.ambros.network',
        shortName: 'ambrostestnet',
        chainId: 8888,
        networkId: 8888,
        explorers: [
            {
                name: 'Ambros Chain Explorer',
                url: 'https://testnet.ambrosscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Mammoth Mainnet',
        title: 'Mammoth Chain',
        chain: 'MMT',
        rpc: ['https://dataseed.mmtscan.io', 'https://dataseed1.mmtscan.io', 'https://dataseed2.mmtscan.io'],
        faucets: ['https://faucet.mmtscan.io/'],
        nativeCurrency: {
            name: 'Mammoth Token',
            symbol: 'MMT',
            decimals: 18,
        },
        infoURL: 'https://mmtchain.io/',
        shortName: 'mmt',
        chainId: 8898,
        networkId: 8898,
        icon: 'mmt',
        explorers: [
            {
                name: 'mmtscan',
                url: 'https://mmtscan.io',
                standard: 'EIP3091',
                icon: 'mmt',
            },
        ],
    },
    {
        name: 'bloxberg',
        chain: 'bloxberg',
        rpc: ['https://core.bloxberg.org'],
        faucets: ['https://faucet.bloxberg.org/'],
        nativeCurrency: {
            name: 'BERG',
            symbol: 'U+25B3',
            decimals: 18,
        },
        infoURL: 'https://bloxberg.org',
        shortName: 'berg',
        chainId: 8995,
        networkId: 8995,
    },
    {
        name: 'Evmos Testnet',
        chain: 'Evmos',
        rpc: ['https://eth.bd.evmos.dev:8545'],
        faucets: ['https://faucet.evmos.dev'],
        nativeCurrency: {
            name: 'test-Evmos',
            symbol: 'tEVMOS',
            decimals: 18,
        },
        infoURL: 'https://evmos.org',
        shortName: 'evmos-testnet',
        chainId: 9000,
        networkId: 9000,
        icon: 'evmos',
        explorers: [
            {
                name: 'Evmos EVM Explorer',
                url: 'https://evm.evmos.dev',
                standard: 'EIP3091',
                icon: 'evmos',
            },
            {
                name: 'Evmos Cosmos Explorer',
                url: 'https://explorer.evmos.dev',
                standard: 'none',
                icon: 'evmos',
            },
        ],
    },
    {
        name: 'Evmos',
        chain: 'Evmos',
        rpc: ['https://eth.bd.evmos.org:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'Evmos',
            symbol: 'EVMOS',
            decimals: 18,
        },
        infoURL: 'https://evmos.org',
        shortName: 'evmos',
        chainId: 9001,
        networkId: 9001,
        icon: 'evmos',
        explorers: [
            {
                name: 'Evmos EVM Explorer (Blockscout)',
                url: 'https://evm.evmos.org',
                standard: 'none',
                icon: 'evmos',
            },
            {
                name: 'Evmos Cosmos Explorer (Mintscan)',
                url: 'https://www.mintscan.io/evmos',
                standard: 'none',
                icon: 'evmos',
            },
        ],
    },
    {
        name: 'BerylBit Mainnet',
        chain: 'BRB',
        rpc: ['https://mainnet.berylbit.io'],
        faucets: ['https://t.me/BerylBit'],
        nativeCurrency: {
            name: 'BerylBit Chain Native Token',
            symbol: 'BRB',
            decimals: 18,
        },
        infoURL: 'https://www.beryl-bit.com',
        shortName: 'brb',
        chainId: 9012,
        networkId: 9012,
        icon: 'berylbit',
        explorers: [
            {
                name: 'berylbit-explorer',
                url: 'https://explorer.berylbit.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Genesis Coin',
        chain: 'Genesis',
        rpc: ['https://genesis-gn.com', 'wss://genesis-gn.com'],
        faucets: [],
        nativeCurrency: {
            name: 'GN Coin',
            symbol: 'GNC',
            decimals: 18,
        },
        infoURL: 'https://genesis-gn.com',
        shortName: 'GENEC',
        chainId: 9100,
        networkId: 9100,
    },
    {
        name: 'Rangers Protocol Testnet Robin',
        chain: 'Rangers',
        icon: 'rangers',
        rpc: ['https://robin.rangersprotocol.com/api/jsonrpc'],
        faucets: ['https://robin-faucet.rangersprotocol.com'],
        nativeCurrency: {
            name: 'Rangers Protocol Gas',
            symbol: 'tRPG',
            decimals: 18,
        },
        infoURL: 'https://rangersprotocol.com',
        shortName: 'trpg',
        chainId: 9527,
        networkId: 9527,
        explorers: [
            {
                name: 'rangersscan-robin',
                url: 'https://robin-rangersscan.rangersprotocol.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'myOwn Testnet',
        chain: 'myOwn',
        rpc: ['https://geth.dev.bccloud.net'],
        faucets: [],
        nativeCurrency: {
            name: 'MYN',
            symbol: 'MYN',
            decimals: 18,
        },
        infoURL: 'https://docs.bccloud.net/',
        shortName: 'myn',
        chainId: 9999,
        networkId: 9999,
    },
    {
        name: 'Smart Bitcoin Cash',
        chain: 'smartBCH',
        rpc: [
            'https://smartbch.greyh.at',
            'https://rpc-mainnet.smartbch.org',
            'https://smartbch.fountainhead.cash/mainnet',
            'https://smartbch.devops.cash/mainnet',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Bitcoin Cash',
            symbol: 'BCH',
            decimals: 18,
        },
        infoURL: 'https://smartbch.org/',
        shortName: 'smartbch',
        chainId: 10000,
        networkId: 10000,
    },
    {
        name: 'Smart Bitcoin Cash Testnet',
        chain: 'smartBCHTest',
        rpc: ['https://rpc-testnet.smartbch.org', 'https://smartbch.devops.cash/testnet'],
        faucets: [],
        nativeCurrency: {
            name: 'Bitcoin Cash Test Token',
            symbol: 'BCHT',
            decimals: 18,
        },
        infoURL: 'http://smartbch.org/',
        shortName: 'smartbchtest',
        chainId: 10001,
        networkId: 10001,
    },
    {
        name: 'Blockchain Genesis Mainnet',
        chain: 'GEN',
        rpc: ['https://eu.mainnet.xixoio.com', 'https://us.mainnet.xixoio.com', 'https://asia.mainnet.xixoio.com'],
        faucets: [],
        nativeCurrency: {
            name: 'GEN',
            symbol: 'GEN',
            decimals: 18,
        },
        infoURL: 'https://www.xixoio.com/',
        shortName: 'GEN',
        chainId: 10101,
        networkId: 10101,
    },
    {
        name: 'CryptoCoinPay',
        chain: 'CCP',
        rpc: ['http://node106.cryptocoinpay.info:8545', 'ws://node106.cryptocoinpay.info:8546'],
        faucets: [],
        icon: 'ccp',
        nativeCurrency: {
            name: 'CryptoCoinPay',
            symbol: 'CCP',
            decimals: 18,
        },
        infoURL: 'https://www.cryptocoinpay.co',
        shortName: 'CCP',
        chainId: 10823,
        networkId: 10823,
        explorers: [
            {
                name: 'CCP Explorer',
                url: 'https://cryptocoinpay.info',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Quadrans Blockchain',
        chain: 'QDC',
        network: 'mainnet',
        icon: 'quadrans',
        rpc: ['https://rpc.quadrans.io', 'https://rpcna.quadrans.io', 'https://rpceu.quadrans.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Quadrans Coin',
            symbol: 'QDC',
            decimals: 18,
        },
        infoURL: 'https://quadrans.io',
        shortName: 'quadrans',
        chainId: 10946,
        networkId: 10946,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.quadrans.io',
                icon: 'quadrans',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Quadrans Blockchain Testnet',
        chain: 'tQDC',
        network: 'testnet',
        icon: 'quadrans',
        rpc: ['https://rpctest.quadrans.io', 'https://rpctest2.quadrans.io'],
        faucets: ['https://faucetpage.quadrans.io'],
        nativeCurrency: {
            name: 'Quadrans Testnet Coin',
            symbol: 'tQDC',
            decimals: 18,
        },
        infoURL: 'https://quadrans.io',
        shortName: 'quadranstestnet',
        chainId: 10947,
        networkId: 10947,
        explorers: [
            {
                name: 'explorer',
                url: 'https://explorer.testnet.quadrans.io',
                icon: 'quadrans',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'WAGMI',
        chain: 'WAGMI',
        icon: 'wagmi',
        rpc: ['https://subnets.avax.network/wagmi/wagmi-chain-testnet/rpc'],
        faucets: ['https://faucet.trywagmi.xyz'],
        nativeCurrency: {
            name: 'WAGMI',
            symbol: 'WGM',
            decimals: 18,
        },
        infoURL: 'https://trywagmi.xyz',
        shortName: 'WAGMI',
        chainId: 11111,
        networkId: 11111,
        explorers: [
            {
                name: 'WAGMI Explorer',
                url: 'https://subnets.avax.network/wagmi/wagmi-chain-testnet/explorer',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Shyft Testnet',
        chain: 'SHYFTT',
        icon: 'shyft',
        rpc: ['https://rpc.testnet.shyft.network/'],
        faucets: [],
        nativeCurrency: {
            name: 'Shyft Test Token',
            symbol: 'SHYFTT',
            decimals: 18,
        },
        infoURL: 'https://shyft.network',
        shortName: 'shyftt',
        chainId: 11437,
        networkId: 11437,
        explorers: [
            {
                name: 'Shyft Testnet BX',
                url: 'https://bx.testnet.shyft.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Singularity ZERO Testnet',
        chain: 'ZERO',
        rpc: ['https://betaenv.singularity.gold:18545'],
        faucets: ['https://nft.singularity.gold'],
        nativeCurrency: {
            name: 'ZERO',
            symbol: 'tZERO',
            decimals: 18,
        },
        infoURL: 'https://www.singularity.gold',
        shortName: 'tZERO',
        chainId: 12051,
        networkId: 12051,
        explorers: [
            {
                name: 'zeroscan',
                url: 'https://betaenv.singularity.gold:18002',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Singularity ZERO Mainnet',
        chain: 'ZERO',
        rpc: ['https://zerorpc.singularity.gold'],
        faucets: ['https://zeroscan.singularity.gold'],
        nativeCurrency: {
            name: 'ZERO',
            symbol: 'ZERO',
            decimals: 18,
        },
        infoURL: 'https://www.singularity.gold',
        shortName: 'ZERO',
        chainId: 12052,
        networkId: 12052,
        slip44: 621,
        explorers: [
            {
                name: 'zeroscan',
                url: 'https://zeroscan.singularity.gold',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Phoenix Mainnet',
        chain: 'Phoenix',
        network: 'mainnet',
        rpc: ['https://rpc.phoenixplorer.com/'],
        faucets: [],
        nativeCurrency: {
            name: 'Phoenix',
            symbol: 'PHX',
            decimals: 18,
        },
        infoURL: 'https://cryptophoenix.org/phoenix',
        shortName: 'Phoenix',
        chainId: 13381,
        networkId: 13381,
        icon: 'phoenix',
        explorers: [
            {
                name: 'phoenixplorer',
                url: 'https://phoenixplorer.com',
                icon: 'phoenixplorer',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'MetaDot Mainnet',
        chain: 'MTT',
        rpc: ['https://mainnet.metadot.network'],
        faucets: [],
        nativeCurrency: {
            name: 'MetaDot Token',
            symbol: 'MTT',
            decimals: 18,
        },
        infoURL: 'https://metadot.network',
        shortName: 'mtt',
        chainId: 16000,
        networkId: 16000,
    },
    {
        name: 'MetaDot Testnet',
        chain: 'MTTTest',
        rpc: ['https://testnet.metadot.network'],
        faucets: ['https://faucet.metadot.network/'],
        nativeCurrency: {
            name: 'MetaDot Token TestNet',
            symbol: 'MTTest',
            decimals: 18,
        },
        infoURL: 'https://metadot.network',
        shortName: 'mtttest',
        chainId: 16001,
        networkId: 16001,
    },
    {
        name: 'IVAR Chain Testnet',
        chain: 'IVAR',
        icon: 'ivar',
        rpc: ['https://testnet-rpc.ivarex.com'],
        faucets: ['https://tfaucet.ivarex.com/'],
        nativeCurrency: {
            name: 'tIvar',
            symbol: 'tIVAR',
            decimals: 18,
        },
        infoURL: 'https://ivarex.com',
        shortName: 'tivar',
        chainId: 16888,
        networkId: 16888,
        explorers: [
            {
                name: 'ivarscan',
                url: 'https://testnet.ivarscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'BTCIX Network',
        chain: 'BTCIX',
        rpc: ['https://seed.btcix.org/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'BTCIX Network',
            symbol: 'BTCIX',
            decimals: 18,
        },
        infoURL: 'https://bitcolojix.org',
        shortName: 'btcix',
        chainId: 19845,
        networkId: 19845,
        explorers: [
            {
                name: 'BTCIXScan',
                url: 'https://btcixscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'CENNZnet Azalea',
        chain: 'CENNZnet',
        network: 'azalea',
        rpc: ['https://cennznet.unfrastructure.io/public'],
        faucets: [],
        nativeCurrency: {
            name: 'CPAY',
            symbol: 'CPAY',
            decimals: 18,
        },
        infoURL: 'https://cennz.net',
        shortName: 'cennz-a',
        chainId: 21337,
        networkId: 21337,
        icon: 'cennz',
        explorers: [
            {
                name: 'UNcover',
                url: 'https://uncoverexplorer.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'omChain Mainnet',
        chain: 'OML',
        icon: 'omlira',
        rpc: ['https://seed.omchain.io'],
        faucets: [],
        nativeCurrency: {
            name: 'omChain',
            symbol: 'OMC',
            decimals: 18,
        },
        infoURL: 'https://omchain.io',
        shortName: 'omc',
        chainId: 21816,
        networkId: 21816,
        explorers: [
            {
                name: 'omChain Explorer',
                url: 'https://explorer.omchain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Taycan',
        chain: 'Taycan',
        network: 'mainnet',
        rpc: ['https://taycan-rpc.hupayx.io:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'shuffle',
            symbol: 'SFL',
            decimals: 18,
        },
        infoURL: 'https://hupayx.io',
        shortName: 'SFL',
        chainId: 22023,
        networkId: 22023,
        explorers: [
            {
                name: 'Taycan Explorer(Blockscout)',
                url: 'https://taycan-evmscan.hupayx.io',
                standard: 'none',
            },
            {
                name: 'Taycan Cosmos Explorer(BigDipper)',
                url: 'https://taycan-cosmoscan.hupayx.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Webchain',
        chain: 'WEB',
        rpc: ['https://node1.webchain.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Webchain Ether',
            symbol: 'WEB',
            decimals: 18,
        },
        infoURL: 'https://webchain.network',
        shortName: 'web',
        chainId: 24484,
        networkId: 37129,
        slip44: 227,
    },
    {
        name: 'MintMe.com Coin',
        chain: 'MINTME',
        rpc: ['https://node1.mintme.com'],
        faucets: [],
        nativeCurrency: {
            name: 'MintMe.com Coin',
            symbol: 'MINTME',
            decimals: 18,
        },
        infoURL: 'https://www.mintme.com',
        shortName: 'mintme',
        chainId: 24734,
        networkId: 37480,
    },
    {
        name: 'OasisChain Mainnet',
        chain: 'OasisChain',
        rpc: ['https://rpc1.oasischain.io', 'https://rpc2.oasischain.io', 'https://rpc3.oasischain.io'],
        faucets: ['http://faucet.oasischain.io'],
        nativeCurrency: {
            name: 'OAC',
            symbol: 'OAC',
            decimals: 18,
        },
        infoURL: 'https://scan.oasischain.io',
        shortName: 'OAC',
        chainId: 26863,
        networkId: 26863,
        explorers: [
            {
                name: 'OasisChain Explorer',
                url: 'https://scan.oasischain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Piece testnet',
        chain: 'PieceNetwork',
        icon: 'piecechain',
        rpc: ['https://testnet-rpc0.piecenetwork.com'],
        faucets: ['https://piecenetwork.com/faucet'],
        nativeCurrency: {
            name: 'ECE',
            symbol: 'ECE',
            decimals: 18,
        },
        infoURL: 'https://piecenetwork.com',
        shortName: 'Piece',
        chainId: 30067,
        networkId: 30067,
        explorers: [
            {
                name: 'Piece Scan',
                url: 'https://testnet-scan.piecenetwork.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Ethersocial Network',
        chain: 'ESN',
        rpc: ['https://api.esn.gonspool.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Ethersocial Network Ether',
            symbol: 'ESN',
            decimals: 18,
        },
        infoURL: 'https://ethersocial.org',
        shortName: 'esn',
        chainId: 31102,
        networkId: 1,
        slip44: 31102,
    },
    {
        name: 'GoChain Testnet',
        chain: 'GO',
        rpc: ['https://testnet-rpc.gochain.io'],
        faucets: [],
        nativeCurrency: {
            name: 'GoChain Coin',
            symbol: 'GO',
            decimals: 18,
        },
        infoURL: 'https://gochain.io',
        shortName: 'got',
        chainId: 31337,
        networkId: 31337,
        slip44: 6060,
        explorers: [
            {
                name: 'GoChain Testnet Explorer',
                url: 'https://testnet-explorer.gochain.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Bitgert Mainnet',
        chain: 'Brise',
        rpc: [
            'https://rpc.icecreamswap.com',
            'https://mainnet-rpc.brisescan.com',
            'https://chainrpc.com',
            'https://serverrpc.com',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Bitrise Token',
            symbol: 'Brise',
            decimals: 18,
        },
        infoURL: 'https://bitgert.com/',
        shortName: 'Brise',
        chainId: 32520,
        networkId: 32520,
        icon: 'brise',
        explorers: [
            {
                name: 'Brise Scan',
                url: 'https://brisescan.com',
                icon: 'brise',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Fusion Mainnet',
        chain: 'FSN',
        rpc: ['https://mainnet.anyswap.exchange', 'https://fsn.dev/api'],
        faucets: [],
        nativeCurrency: {
            name: 'Fusion',
            symbol: 'FSN',
            decimals: 18,
        },
        infoURL: 'https://www.fusion.org/',
        shortName: 'fsn',
        chainId: 32659,
        networkId: 32659,
    },
    {
        name: 'Q Mainnet',
        chain: 'Q',
        network: 'mainnet',
        rpc: ['https://rpc.q.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Q token',
            symbol: 'Q',
            decimals: 18,
        },
        infoURL: 'https://q.org',
        shortName: 'q',
        chainId: 35441,
        networkId: 35441,
        icon: 'q',
        explorers: [
            {
                name: 'Q explorer',
                url: 'https://explorer.q.org',
                icon: 'q',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Q Testnet',
        chain: 'Q',
        network: 'testnet',
        rpc: ['https://rpc.qtestnet.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Q token',
            symbol: 'Q',
            decimals: 18,
        },
        infoURL: 'https://q.org/',
        shortName: 'q-testnet',
        chainId: 35443,
        networkId: 35443,
        icon: 'q',
        explorers: [
            {
                name: 'Q explorer',
                url: 'https://explorer.qtestnet.org',
                icon: 'q',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Energi Mainnet',
        chain: 'NRG',
        rpc: ['https://nodeapi.energi.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Energi',
            symbol: 'NRG',
            decimals: 18,
        },
        infoURL: 'https://www.energi.world/',
        shortName: 'nrg',
        chainId: 39797,
        networkId: 39797,
        slip44: 39797,
    },
    {
        name: 'pegglecoin',
        chain: '42069',
        rpc: [],
        faucets: [],
        nativeCurrency: {
            name: 'pegglecoin',
            symbol: 'peggle',
            decimals: 18,
        },
        infoURL: 'https://teampeggle.com',
        shortName: 'PC',
        chainId: 42069,
        networkId: 42069,
    },
    {
        name: 'Arbitrum One',
        chainId: 42161,
        shortName: 'arb1',
        chain: 'ETH',
        networkId: 42161,
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        rpc: [
            'https://arbitrum-mainnet.infura.io/v3/${INFURA_API_KEY}',
            'https://arb-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}',
            'https://arb1.arbitrum.io/rpc',
        ],
        faucets: [],
        explorers: [
            {
                name: 'Arbiscan',
                url: 'https://arbiscan.io',
                standard: 'EIP3091',
            },
            {
                name: 'Arbitrum Explorer',
                url: 'https://explorer.arbitrum.io',
                standard: 'EIP3091',
            },
        ],
        infoURL: 'https://arbitrum.io',
        parent: {
            type: 'L2',
            chain: 'eip155-1',
            bridges: [
                {
                    url: 'https://bridge.arbitrum.io',
                },
            ],
        },
    },
    {
        name: 'Arbitrum Nova',
        chainId: 42170,
        shortName: 'arb-nova',
        chain: 'ETH',
        networkId: 42170,
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        rpc: ['https://nova.arbitrum.io/rpc'],
        faucets: [],
        explorers: [
            {
                name: 'Arbitrum Nova Chain Explorer',
                url: 'https://nova-explorer.arbitrum.io',
                icon: 'blockscout',
                standard: 'EIP3091',
            },
        ],
        infoURL: 'https://arbitrum.io',
        parent: {
            type: 'L2',
            chain: 'eip155-1',
            bridges: [
                {
                    url: 'https://bridge.arbitrum.io',
                },
            ],
        },
    },
    {
        name: 'Celo Mainnet',
        chainId: 42220,
        shortName: 'CELO',
        chain: 'CELO',
        networkId: 42220,
        nativeCurrency: {
            name: 'CELO',
            symbol: 'CELO',
            decimals: 18,
        },
        rpc: ['https://forno.celo.org', 'wss://forno.celo.org/ws'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        infoURL: 'https://docs.celo.org/',
        explorers: [
            {
                name: 'blockscout',
                url: 'https://explorer.celo.org',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Emerald Paratime Testnet',
        chain: 'Emerald',
        icon: 'oasis',
        rpc: ['https://testnet.emerald.oasis.dev/', 'wss://testnet.emerald.oasis.dev/ws'],
        faucets: [],
        nativeCurrency: {
            name: 'Emerald Rose',
            symbol: 'ROSE',
            decimals: 18,
        },
        infoURL: 'https://docs.oasis.dev/general/developer-resources/overview',
        shortName: 'emerald',
        chainId: 42261,
        networkId: 42261,
        explorers: [
            {
                name: 'Emerald Paratime Testnet Explorer',
                url: 'https://testnet.explorer.emerald.oasis.dev',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Emerald Paratime Mainnet',
        chain: 'Emerald',
        icon: 'oasis',
        rpc: ['https://emerald.oasis.dev', 'wss://emerald.oasis.dev/ws'],
        faucets: [],
        nativeCurrency: {
            name: 'Emerald Rose',
            symbol: 'ROSE',
            decimals: 18,
        },
        infoURL: 'https://docs.oasis.dev/general/developer-resources/overview',
        shortName: 'oasis',
        chainId: 42262,
        networkId: 42262,
        explorers: [
            {
                name: 'Emerald Paratime Mainnet Explorer',
                url: 'https://explorer.emerald.oasis.dev',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Athereum',
        chain: 'ATH',
        rpc: ['https://ava.network:21015/ext/evm/rpc'],
        faucets: ['http://athfaucet.ava.network//?address=${ADDRESS}'],
        nativeCurrency: {
            name: 'Athereum Ether',
            symbol: 'ATH',
            decimals: 18,
        },
        infoURL: 'https://athereum.ava.network',
        shortName: 'avaeth',
        chainId: 43110,
        networkId: 43110,
    },
    {
        name: 'Avalanche Fuji Testnet',
        chain: 'AVAX',
        rpc: ['https://api.avax-test.network/ext/bc/C/rpc'],
        faucets: ['https://faucet.avax-test.network/'],
        nativeCurrency: {
            name: 'Avalanche',
            symbol: 'AVAX',
            decimals: 18,
        },
        infoURL: 'https://cchain.explorer.avax-test.network',
        shortName: 'Fuji',
        chainId: 43113,
        networkId: 1,
        explorers: [
            {
                name: 'snowtrace',
                url: 'https://testnet.snowtrace.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Avalanche C-Chain',
        chain: 'AVAX',
        rpc: ['https://api.avax.network/ext/bc/C/rpc'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'Avalanche',
            symbol: 'AVAX',
            decimals: 18,
        },
        infoURL: 'https://www.avax.network/',
        shortName: 'avax',
        chainId: 43114,
        networkId: 43114,
        slip44: 9005,
        explorers: [
            {
                name: 'snowtrace',
                url: 'https://snowtrace.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Celo Alfajores Testnet',
        chainId: 44787,
        shortName: 'ALFA',
        chain: 'CELO',
        networkId: 44787,
        nativeCurrency: {
            name: 'CELO',
            symbol: 'CELO',
            decimals: 18,
        },
        rpc: ['https://alfajores-forno.celo-testnet.org', 'wss://alfajores-forno.celo-testnet.org/ws'],
        faucets: ['https://celo.org/developers/faucet', 'https://cauldron.pretoriaresearchlab.io/alfajores-faucet'],
        infoURL: 'https://docs.celo.org/',
    },
    {
        name: 'Autobahn Network',
        chain: 'TXL',
        network: 'mainnet',
        rpc: ['https://rpc.autobahn.network'],
        faucets: [],
        nativeCurrency: {
            name: 'TXL',
            symbol: 'TXL',
            decimals: 18,
        },
        infoURL: 'https://autobahn.network',
        shortName: 'Autobahn Network',
        chainId: 45000,
        networkId: 45000,
        icon: 'autobahn',
        explorers: [
            {
                name: 'autobahn explorer',
                url: 'https://explorer.autobahn.network',
                icon: 'autobahn',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'REI Network',
        chain: 'REI',
        rpc: ['https://rpc.rei.network', 'wss://rpc.rei.network'],
        faucets: [],
        nativeCurrency: {
            name: 'REI',
            symbol: 'REI',
            decimals: 18,
        },
        infoURL: 'https://rei.network/',
        shortName: 'REI',
        chainId: 47805,
        networkId: 47805,
        explorers: [
            {
                name: 'rei-scan',
                url: 'https://scan.rei.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Energi Testnet',
        chain: 'NRG',
        rpc: ['https://nodeapi.test.energi.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Energi',
            symbol: 'NRG',
            decimals: 18,
        },
        infoURL: 'https://www.energi.world/',
        shortName: 'tnrg',
        chainId: 49797,
        networkId: 49797,
        slip44: 49797,
    },
    {
        name: 'GTON Testnet',
        chain: 'GTON Testnet',
        rpc: ['https://testnet.gton.network/'],
        faucets: [],
        nativeCurrency: {
            name: 'GCD',
            symbol: 'GCD',
            decimals: 18,
        },
        infoURL: 'https://gton.capital',
        shortName: 'tgton',
        chainId: 50021,
        networkId: 50021,
        explorers: [
            {
                name: 'GTON Testnet Network Explorer',
                url: 'https://explorer.testnet.gton.network',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-3',
        },
    },
    {
        name: 'DFK Chain',
        chain: 'DFK',
        icon: 'dfk',
        network: 'mainnet',
        rpc: ['https://subnets.avax.network/defi-kingdoms/dfk-chain/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'Jewel',
            symbol: 'JEWEL',
            decimals: 18,
        },
        infoURL: 'https://defikingdoms.com',
        shortName: 'DFK',
        chainId: 53935,
        networkId: 53935,
        explorers: [
            {
                name: 'ethernal',
                url: 'https://explorer.dfkchain.com',
                icon: 'ethereum',
                standard: 'none',
            },
        ],
    },
    {
        name: 'REI Chain Mainnet',
        chain: 'REI',
        icon: 'reichain',
        rpc: ['https://rei-rpc.moonrhythm.io'],
        faucets: ['http://kururu.finance/faucet?chainId=55555'],
        nativeCurrency: {
            name: 'Rei',
            symbol: 'REI',
            decimals: 18,
        },
        infoURL: 'https://reichain.io',
        shortName: 'reichain',
        chainId: 55555,
        networkId: 55555,
        explorers: [
            {
                name: 'reiscan',
                url: 'https://reiscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'REI Chain Testnet',
        chain: 'REI',
        icon: 'reichain',
        rpc: ['https://rei-testnet-rpc.moonrhythm.io'],
        faucets: ['http://kururu.finance/faucet?chainId=55556'],
        nativeCurrency: {
            name: 'tRei',
            symbol: 'tREI',
            decimals: 18,
        },
        infoURL: 'https://reichain.io',
        shortName: 'trei',
        chainId: 55556,
        networkId: 55556,
        explorers: [
            {
                name: 'reiscan',
                url: 'https://testnet.reiscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Thinkium Testnet Chain 0',
        chain: 'Thinkium',
        rpc: ['https://test.thinkiumrpc.net/'],
        faucets: ['https://www.thinkiumdev.net/faucet'],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM-test0',
        chainId: 60000,
        networkId: 60000,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://test0.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Thinkium Testnet Chain 1',
        chain: 'Thinkium',
        rpc: ['https://test1.thinkiumrpc.net/'],
        faucets: ['https://www.thinkiumdev.net/faucet'],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM-test1',
        chainId: 60001,
        networkId: 60001,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://test1.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Thinkium Testnet Chain 2',
        chain: 'Thinkium',
        rpc: ['https://test2.thinkiumrpc.net/'],
        faucets: ['https://www.thinkiumdev.net/faucet'],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM-test2',
        chainId: 60002,
        networkId: 60002,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://test2.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Thinkium Testnet Chain 103',
        chain: 'Thinkium',
        rpc: ['https://test103.thinkiumrpc.net/'],
        faucets: ['https://www.thinkiumdev.net/faucet'],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM-test103',
        chainId: 60103,
        networkId: 60103,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://test103.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Celo Baklava Testnet',
        chainId: 62320,
        shortName: 'BKLV',
        chain: 'CELO',
        networkId: 62320,
        nativeCurrency: {
            name: 'CELO',
            symbol: 'CELO',
            decimals: 18,
        },
        rpc: ['https://baklava-forno.celo-testnet.org'],
        faucets: [
            'https://docs.google.com/forms/d/e/1FAIpQLSdfr1BwUTYepVmmvfVUDRCwALejZ-TUva2YujNpvrEmPAX2pg/viewform',
            'https://cauldron.pretoriaresearchlab.io/baklava-faucet',
        ],
        infoURL: 'https://docs.celo.org/',
    },
    {
        name: 'MultiVAC Mainnet',
        chain: 'MultiVAC',
        icon: 'multivac',
        rpc: ['https://rpc.mtv.ac', 'https://rpc-eu.mtv.ac'],
        faucets: [],
        nativeCurrency: {
            name: 'MultiVAC',
            symbol: 'MTV',
            decimals: 18,
        },
        infoURL: 'https://mtv.ac',
        shortName: 'mtv',
        chainId: 62621,
        networkId: 62621,
        explorers: [
            {
                name: 'MultiVAC Explorer',
                url: 'https://e.mtv.ac',
                standard: 'none',
            },
        ],
    },
    {
        name: 'eCredits Mainnet',
        chain: 'ECS',
        network: 'mainnet',
        rpc: ['https://rpc.ecredits.com'],
        faucets: [],
        nativeCurrency: {
            name: 'eCredits',
            symbol: 'ECS',
            decimals: 18,
        },
        infoURL: 'https://ecredits.com',
        shortName: 'ecs',
        chainId: 63000,
        networkId: 63000,
        icon: 'ecredits',
        explorers: [
            {
                name: 'eCredits MainNet Explorer',
                url: 'https://explorer.ecredits.com',
                icon: 'ecredits',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'eCredits Testnet',
        chain: 'ECS',
        network: 'testnet',
        rpc: ['https://rpc.tst.ecredits.com'],
        faucets: ['https://faucet.tst.ecredits.com'],
        nativeCurrency: {
            name: 'eCredits',
            symbol: 'ECS',
            decimals: 18,
        },
        infoURL: 'https://ecredits.com',
        shortName: 'ecs-testnet',
        chainId: 63001,
        networkId: 63001,
        icon: 'ecredits',
        explorers: [
            {
                name: 'eCredits TestNet Explorer',
                url: 'https://explorer.tst.ecredits.com',
                icon: 'ecredits',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Condrieu',
        title: 'Ethereum Verkle Testnet Condrieu',
        chain: 'ETH',
        rpc: ['https://rpc.condrieu.ethdevops.io:8545'],
        faucets: ['https://faucet.condrieu.ethdevops.io'],
        nativeCurrency: {
            name: 'Condrieu Testnet Ether',
            symbol: 'CTE',
            decimals: 18,
        },
        infoURL: 'https://condrieu.ethdevops.io',
        shortName: 'cndr',
        chainId: 69420,
        networkId: 69420,
        explorers: [
            {
                name: 'Condrieu explorer',
                url: 'https://explorer.condrieu.ethdevops.io',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Thinkium Mainnet Chain 0',
        chain: 'Thinkium',
        rpc: ['https://proxy.thinkiumrpc.net/'],
        faucets: [],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM0',
        chainId: 70000,
        networkId: 70000,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://chain0.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Thinkium Mainnet Chain 1',
        chain: 'Thinkium',
        rpc: ['https://proxy1.thinkiumrpc.net/'],
        faucets: [],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM1',
        chainId: 70001,
        networkId: 70001,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://chain1.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Thinkium Mainnet Chain 2',
        chain: 'Thinkium',
        rpc: ['https://proxy2.thinkiumrpc.net/'],
        faucets: [],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM2',
        chainId: 70002,
        networkId: 70002,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://chain2.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Thinkium Mainnet Chain 103',
        chain: 'Thinkium',
        rpc: ['https://proxy103.thinkiumrpc.net/'],
        faucets: [],
        nativeCurrency: {
            name: 'TKM',
            symbol: 'TKM',
            decimals: 18,
        },
        infoURL: 'https://thinkium.net/',
        shortName: 'TKM103',
        chainId: 70103,
        networkId: 70103,
        explorers: [
            {
                name: 'thinkiumscan',
                url: 'https://chain103.thinkiumscan.net',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Polyjuice Testnet',
        chain: 'CKB',
        icon: 'polyjuice',
        rpc: ['https://godwoken-testnet-web3-rpc.ckbapp.dev', 'ws://godwoken-testnet-web3-rpc.ckbapp.dev/ws'],
        faucets: ['https://faucet.nervos.org/'],
        nativeCurrency: {
            name: 'CKB',
            symbol: 'CKB',
            decimals: 8,
        },
        infoURL: 'https://github.com/nervosnetwork/godwoken',
        shortName: 'ckb',
        chainId: 71393,
        networkId: 1,
    },
    {
        name: 'Godwoken Testnet (V1.1)',
        chain: 'GWT',
        rpc: ['https://godwoken-testnet-v1.ckbapp.dev'],
        faucets: ['https://testnet.bridge.godwoken.io'],
        nativeCurrency: {
            name: 'pCKB',
            symbol: 'pCKB',
            decimals: 18,
        },
        infoURL: 'https://www.nervos.org',
        shortName: 'gw-testnet-v1',
        chainId: 71401,
        networkId: 71401,
        explorers: [
            {
                name: 'GWScout Explorer',
                url: 'https://gw-testnet-explorer.nervosdao.community',
                standard: 'none',
            },
            {
                name: 'GWScan Block Explorer',
                url: 'https://v1.testnet.gwscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Godwoken Mainnet',
        chain: 'GWT',
        rpc: ['https://v1.mainnet.godwoken.io/rpc'],
        faucets: [],
        nativeCurrency: {
            name: 'pCKB',
            symbol: 'pCKB',
            decimals: 18,
        },
        infoURL: 'https://www.nervos.org',
        shortName: 'gw-mainnet-v1',
        chainId: 71402,
        networkId: 71402,
        explorers: [
            {
                name: 'GWScout Explorer',
                url: 'https://gw-mainnet-explorer.nervosdao.community',
                standard: 'none',
            },
            {
                name: 'GWScan Block Explorer',
                url: 'https://v1.gwscan.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Energy Web Volta Testnet',
        chain: 'Volta',
        rpc: ['https://volta-rpc.energyweb.org', 'wss://volta-rpc.energyweb.org/ws'],
        faucets: ['https://voltafaucet.energyweb.org'],
        nativeCurrency: {
            name: 'Volta Token',
            symbol: 'VT',
            decimals: 18,
        },
        infoURL: 'https://energyweb.org',
        shortName: 'vt',
        chainId: 73799,
        networkId: 73799,
    },
    {
        name: 'Mixin Virtual Machine',
        chain: 'MVM',
        network: 'mainnet',
        rpc: ['https://geth.mvm.dev'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://mvm.dev',
        shortName: 'mvm',
        chainId: 73927,
        networkId: 73927,
        icon: 'mvm',
        explorers: [
            {
                name: 'mvmscan',
                url: 'https://scan.mvm.dev',
                icon: 'mvm',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'ResinCoin Mainnet',
        chain: 'RESIN',
        rpc: ['https://mainnet.resincoin.ml'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'RESIN',
            decimals: 18,
        },
        infoURL: 'https://resincoin.ml',
        shortName: 'resin',
        chainId: 75000,
        networkId: 75000,
        explorers: [
            {
                name: 'ResinScan',
                url: 'https://explorer.resincoin.ml',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Firenze test network',
        chain: 'ETH',
        rpc: ['https://ethnode.primusmoney.com/firenze'],
        faucets: [],
        nativeCurrency: {
            name: 'Firenze Ether',
            symbol: 'FIN',
            decimals: 18,
        },
        infoURL: 'https://primusmoney.com',
        shortName: 'firenze',
        chainId: 78110,
        networkId: 78110,
    },
    {
        name: 'Mumbai',
        title: 'Polygon Testnet Mumbai',
        chain: 'Polygon',
        rpc: [
            'https://matic-mumbai.chainstacklabs.com',
            'https://rpc-mumbai.maticvigil.com',
            'https://matic-testnet-archive-rpc.bwarelabs.com',
        ],
        faucets: ['https://faucet.polygon.technology/'],
        nativeCurrency: {
            name: 'MATIC',
            symbol: 'MATIC',
            decimals: 18,
        },
        infoURL: 'https://polygon.technology/',
        shortName: 'maticmum',
        chainId: 80001,
        networkId: 80001,
        explorers: [
            {
                name: 'polygonscan',
                url: 'https://mumbai.polygonscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'IVAR Chain Mainnet',
        chain: 'IVAR',
        icon: 'ivar',
        rpc: ['https://mainnet-rpc.ivarex.com'],
        faucets: ['https://faucet.ivarex.com/'],
        nativeCurrency: {
            name: 'Ivar',
            symbol: 'IVAR',
            decimals: 18,
        },
        infoURL: 'https://ivarex.com',
        shortName: 'ivar',
        chainId: 88888,
        networkId: 88888,
        explorers: [
            {
                name: 'ivarscan',
                url: 'https://ivarscan.com',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'UB Smart Chain(testnet)',
        chain: 'USC',
        network: 'testnet',
        rpc: ['https://testnet.rpc.uschain.network'],
        faucets: [],
        nativeCurrency: {
            name: 'UBC',
            symbol: 'UBC',
            decimals: 18,
        },
        infoURL: 'https://www.ubchain.site',
        shortName: 'usctest',
        chainId: 99998,
        networkId: 99998,
    },
    {
        name: 'UB Smart Chain',
        chain: 'USC',
        network: 'mainnet',
        rpc: ['https://rpc.uschain.network'],
        faucets: [],
        nativeCurrency: {
            name: 'UBC',
            symbol: 'UBC',
            decimals: 18,
        },
        infoURL: 'https://www.ubchain.site/',
        shortName: 'usc',
        chainId: 99999,
        networkId: 99999,
    },
    {
        name: 'QuarkChain Mainnet Root',
        chain: 'QuarkChain',
        rpc: ['http://jrpc.mainnet.quarkchain.io:38391'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-r',
        chainId: 100000,
        networkId: 100000,
    },
    {
        name: 'QuarkChain Mainnet Shard 0',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s0-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39000'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s0',
        chainId: 100001,
        networkId: 100001,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/0',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Mainnet Shard 1',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s1-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39001'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s1',
        chainId: 100002,
        networkId: 100002,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/1',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Mainnet Shard 2',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s2-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39002'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s2',
        chainId: 100003,
        networkId: 100003,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/2',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Mainnet Shard 3',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s3-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39003'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s3',
        chainId: 100004,
        networkId: 100004,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/3',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Mainnet Shard 4',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s4-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39004'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s4',
        chainId: 100005,
        networkId: 100005,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/4',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Mainnet Shard 5',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s5-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39005'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s5',
        chainId: 100006,
        networkId: 100006,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/5',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Mainnet Shard 6',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s6-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39006'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s6',
        chainId: 100007,
        networkId: 100007,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/6',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Mainnet Shard 7',
        chain: 'QuarkChain',
        rpc: ['https://mainnet-s7-ethapi.quarkchain.io', 'http://eth-jrpc.mainnet.quarkchain.io:39007'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-s7',
        chainId: 100008,
        networkId: 100008,
        parent: {
            chain: 'eip155-100000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-mainnet',
                url: 'https://mainnet.quarkchain.io/7',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Crystaleum',
        chain: 'crystal',
        network: 'mainnet',
        rpc: ['https://evm.cryptocurrencydevs.org', 'https://rpc.crystaleum.org'],
        faucets: [],
        nativeCurrency: {
            name: 'CRFI',
            symbol: '◈',
            decimals: 18,
        },
        infoURL: 'https://crystaleum.org',
        shortName: 'CRFI',
        chainId: 103090,
        networkId: 1,
        icon: 'crystal',
        explorers: [
            {
                name: 'blockscout',
                url: 'https://scan.crystaleum.org',
                icon: 'crystal',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'BROChain Mainnet',
        chain: 'BRO',
        network: 'mainnet',
        rpc: [
            'https://rpc.brochain.org',
            'http://rpc.brochain.org',
            'https://rpc.brochain.org/mainnet',
            'http://rpc.brochain.org/mainnet',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'Brother',
            symbol: 'BRO',
            decimals: 18,
        },
        infoURL: 'https://brochain.org',
        shortName: 'bro',
        chainId: 108801,
        networkId: 108801,
        explorers: [
            {
                name: 'BROChain Explorer',
                url: 'https://explorer.brochain.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Root',
        chain: 'QuarkChain',
        rpc: ['http://jrpc.devnet.quarkchain.io:38391'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-r',
        chainId: 110000,
        networkId: 110000,
    },
    {
        name: 'QuarkChain Devnet Shard 0',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s0-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39900'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s0',
        chainId: 110001,
        networkId: 110001,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/0',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Shard 1',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s1-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39901'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s1',
        chainId: 110002,
        networkId: 110002,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/1',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Shard 2',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s2-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39902'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s2',
        chainId: 110003,
        networkId: 110003,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/2',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Shard 3',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s3-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39903'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s3',
        chainId: 110004,
        networkId: 110004,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/3',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Shard 4',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s4-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39904'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s4',
        chainId: 110005,
        networkId: 110005,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/4',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Shard 5',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s5-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39905'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s5',
        chainId: 110006,
        networkId: 110006,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/5',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Shard 6',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s6-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39906'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s6',
        chainId: 110007,
        networkId: 110007,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/6',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'QuarkChain Devnet Shard 7',
        chain: 'QuarkChain',
        rpc: ['https://devnet-s7-ethapi.quarkchain.io', 'http://eth-jrpc.devnet.quarkchain.io:39907'],
        faucets: [],
        nativeCurrency: {
            name: 'QKC',
            symbol: 'QKC',
            decimals: 18,
        },
        infoURL: 'https://www.quarkchain.io',
        shortName: 'qkc-d-s7',
        chainId: 110008,
        networkId: 110008,
        parent: {
            chain: 'eip155-110000',
            type: 'shard',
        },
        explorers: [
            {
                name: 'quarkchain-devnet',
                url: 'https://devnet.quarkchain.io/7',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'ETND Chain Mainnets',
        chain: 'ETND',
        network: 'mainnet',
        rpc: ['https://rpc.node1.etnd.pro/'],
        faucets: [],
        nativeCurrency: {
            name: 'ETND',
            symbol: 'ETND',
            decimals: 18,
        },
        infoURL: 'https://www.etnd.pro',
        shortName: 'ETND',
        chainId: 131419,
        networkId: 131419,
        icon: 'ETND',
        explorers: [
            {
                name: 'etndscan',
                url: 'https://scan.etnd.pro',
                icon: 'ETND',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Milkomeda C1 Testnet',
        chain: 'milkTAda',
        icon: 'milkomeda',
        network: 'testnet',
        rpc: ['https://rpc-devnet-cardano-evm.c1.milkomeda.com', 'wss://rpc-devnet-cardano-evm.c1.milkomeda.com'],
        faucets: [],
        nativeCurrency: {
            name: 'milkTAda',
            symbol: 'mTAda',
            decimals: 18,
        },
        infoURL: 'https://milkomeda.com',
        shortName: 'milkTAda',
        chainId: 200101,
        networkId: 200101,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://explorer-devnet-cardano-evm.c1.milkomeda.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Akroma',
        chain: 'AKA',
        rpc: ['https://remote.akroma.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Akroma Ether',
            symbol: 'AKA',
            decimals: 18,
        },
        infoURL: 'https://akroma.io',
        shortName: 'aka',
        chainId: 200625,
        networkId: 200625,
        slip44: 200625,
    },
    {
        name: 'Alaya Mainnet',
        chain: 'Alaya',
        rpc: ['https://openapi.alaya.network/rpc', 'wss://openapi.alaya.network/ws'],
        faucets: [],
        nativeCurrency: {
            name: 'ATP',
            symbol: 'atp',
            decimals: 18,
        },
        infoURL: 'https://www.alaya.network/',
        shortName: 'alaya',
        chainId: 201018,
        networkId: 1,
        icon: 'alaya',
        explorers: [
            {
                name: 'alaya explorer',
                url: 'https://scan.alaya.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Alaya Dev Testnet',
        chain: 'Alaya',
        rpc: ['https://devnetopenapi.alaya.network/rpc', 'wss://devnetopenapi.alaya.network/ws'],
        faucets: ['https://faucet.alaya.network/faucet/?id=f93426c0887f11eb83b900163e06151c'],
        nativeCurrency: {
            name: 'ATP',
            symbol: 'atp',
            decimals: 18,
        },
        infoURL: 'https://www.alaya.network/',
        shortName: 'alayadev',
        chainId: 201030,
        networkId: 1,
        icon: 'alaya',
        explorers: [
            {
                name: 'alaya explorer',
                url: 'https://devnetscan.alaya.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'PlatON Mainnet',
        chain: 'PlatON',
        network: 'mainnet',
        rpc: ['https://openapi2.platon.network/rpc', 'wss://openapi2.platon.network/ws'],
        faucets: [],
        nativeCurrency: {
            name: 'LAT',
            symbol: 'lat',
            decimals: 18,
        },
        infoURL: 'https://www.platon.network',
        shortName: 'platon',
        chainId: 210425,
        networkId: 1,
        icon: 'platon',
        explorers: [
            {
                name: 'PlatON explorer',
                url: 'https://scan.platon.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Haymo Testnet',
        chain: 'tHYM',
        network: 'testnet',
        rpc: ['https://testnet1.haymo.network'],
        faucets: [],
        nativeCurrency: {
            name: 'HAYMO',
            symbol: 'HYM',
            decimals: 18,
        },
        infoURL: 'https://haymoswap.web.app/',
        shortName: 'hym',
        chainId: 234666,
        networkId: 234666,
    },
    {
        name: 'ARTIS sigma1',
        chain: 'ARTIS',
        rpc: ['https://rpc.sigma1.artis.network'],
        faucets: [],
        nativeCurrency: {
            name: 'ARTIS sigma1 Ether',
            symbol: 'ATS',
            decimals: 18,
        },
        infoURL: 'https://artis.eco',
        shortName: 'ats',
        chainId: 246529,
        networkId: 246529,
        slip44: 246529,
    },
    {
        name: 'ARTIS Testnet tau1',
        chain: 'ARTIS',
        rpc: ['https://rpc.tau1.artis.network'],
        faucets: [],
        nativeCurrency: {
            name: 'ARTIS tau1 Ether',
            symbol: 'tATS',
            decimals: 18,
        },
        infoURL: 'https://artis.network',
        shortName: 'atstau',
        chainId: 246785,
        networkId: 246785,
    },
    {
        name: 'Social Smart Chain Mainnet',
        chain: 'SoChain',
        rpc: ['https://socialsmartchain.digitalnext.business'],
        faucets: [],
        nativeCurrency: {
            name: 'SoChain',
            symbol: '$OC',
            decimals: 18,
        },
        infoURL: 'https://digitalnext.business/SocialSmartChain',
        shortName: 'SoChain',
        chainId: 281121,
        networkId: 281121,
        explorers: [],
    },
    {
        name: 'Polis Testnet',
        chain: 'Sparta',
        icon: 'polis',
        rpc: ['https://sparta-rpc.polis.tech'],
        faucets: ['https://faucet.polis.tech'],
        nativeCurrency: {
            name: 'tPolis',
            symbol: 'tPOLIS',
            decimals: 18,
        },
        infoURL: 'https://polis.tech',
        shortName: 'sparta',
        chainId: 333888,
        networkId: 333888,
    },
    {
        name: 'Polis Mainnet',
        chain: 'Olympus',
        icon: 'polis',
        rpc: ['https://rpc.polis.tech'],
        faucets: ['https://faucet.polis.tech'],
        nativeCurrency: {
            name: 'Polis',
            symbol: 'POLIS',
            decimals: 18,
        },
        infoURL: 'https://polis.tech',
        shortName: 'olympus',
        chainId: 333999,
        networkId: 333999,
    },
    {
        name: 'Arbitrum Rinkeby',
        title: 'Arbitrum Testnet Rinkeby',
        chainId: 421611,
        shortName: 'arb-rinkeby',
        chain: 'ETH',
        networkId: 421611,
        nativeCurrency: {
            name: 'Arbitrum Rinkeby Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        rpc: ['https://rinkeby.arbitrum.io/rpc'],
        faucets: ['http://fauceth.komputing.org?chain=421611&address=${ADDRESS}'],
        infoURL: 'https://arbitrum.io',
        explorers: [
            {
                name: 'arbiscan-testnet',
                url: 'https://testnet.arbiscan.io',
                standard: 'EIP3091',
            },
            {
                name: 'arbitrum-rinkeby',
                url: 'https://rinkeby-explorer.arbitrum.io',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-4',
            bridges: [
                {
                    url: 'https://bridge.arbitrum.io',
                },
            ],
        },
    },
    {
        name: 'Arbitrum Görli',
        title: 'Arbitrum Görli Rollup Testnet',
        chainId: 421613,
        shortName: 'arb-goerli',
        chain: 'ETH',
        networkId: 421613,
        nativeCurrency: {
            name: 'Arbitrum Görli Ether',
            symbol: 'AGOR',
            decimals: 18,
        },
        rpc: ['https://goerli-rollup.arbitrum.io/rpc/'],
        faucets: [],
        infoURL: 'https://arbitrum.io/',
        explorers: [
            {
                name: 'Arbitrum Görli Rollup Explorer',
                url: 'https://goerli-rollup-explorer.arbitrum.io',
                standard: 'EIP3091',
            },
        ],
        parent: {
            type: 'L2',
            chain: 'eip155-5',
            bridges: [
                {
                    url: 'https://bridge.arbitrum.io/',
                },
            ],
        },
    },
    {
        name: 'Dexalot Testnet',
        chain: 'DEXALOT',
        network: 'testnet',
        rpc: ['https://subnets.avax.network/dexalot/testnet/rpc'],
        faucets: ['https://sfaucet.dexalot-test.com'],
        nativeCurrency: {
            name: 'Dexalot',
            symbol: 'ALOT',
            decimals: 18,
        },
        infoURL: 'https://dexalot.com',
        shortName: 'Dexalot',
        chainId: 432201,
        networkId: 432201,
        explorers: [
            {
                name: 'Avalanche Subnet Explorer',
                url: 'https://subnets.avax.network/dexalot/testnet/explorer',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Weelink Testnet',
        chain: 'WLK',
        rpc: ['https://weelinknode1c.gw002.oneitfarm.com'],
        faucets: ['https://faucet.weelink.gw002.oneitfarm.com'],
        nativeCurrency: {
            name: 'Weelink Chain Token',
            symbol: 'tWLK',
            decimals: 18,
        },
        infoURL: 'https://weelink.cloud',
        shortName: 'wlkt',
        chainId: 444900,
        networkId: 444900,
        explorers: [
            {
                name: 'weelink-testnet',
                url: 'https://weelink.cloud/#/blockView/overview',
                standard: 'none',
            },
        ],
    },
    {
        name: 'OpenChain Mainnet',
        chain: 'OpenChain',
        rpc: ['https://baas-rpc.luniverse.io:18545?lChainId=1641349324562974539'],
        faucets: [],
        nativeCurrency: {
            name: 'OpenCoin',
            symbol: 'OPC',
            decimals: 10,
        },
        infoURL: 'https://www.openchain.live',
        shortName: 'oc',
        chainId: 474142,
        networkId: 474142,
        explorers: [
            {
                name: 'SIDE SCAN',
                url: 'https://sidescan.luniverse.io/1641349324562974539',
                standard: 'none',
            },
        ],
    },
    {
        name: 'CMP-Testnet',
        chain: 'CMP',
        network: 'testnet',
        rpc: ['https://galaxy.block.caduceus.foundation', 'wss://galaxy.block.caduceus.foundation'],
        faucets: ['https://dev.caduceus.foundation/testNetwork'],
        nativeCurrency: {
            name: 'Caduceus Testnet Token',
            symbol: 'CMP',
            decimals: 18,
        },
        infoURL: 'https://caduceus.foundation/',
        shortName: 'cmp',
        chainId: 512512,
        networkId: 512512,
        explorers: [
            {
                name: 'Galaxy Scan',
                url: 'https://galaxy.scan.caduceus.foundation',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Vision - Vpioneer Test Chain',
        chain: 'Vision-Vpioneer',
        rpc: ['https://vpioneer.infragrid.v.network/ethereum/compatible'],
        faucets: ['https://vpioneerfaucet.visionscan.org'],
        nativeCurrency: {
            name: 'VS',
            symbol: 'VS',
            decimals: 18,
        },
        infoURL: 'https://visionscan.org',
        shortName: 'vpioneer',
        chainId: 666666,
        networkId: 666666,
        slip44: 60,
    },
    {
        name: '4GoodNetwork',
        chain: '4GN',
        rpc: ['https://chain.deptofgood.com'],
        faucets: [],
        nativeCurrency: {
            name: 'APTA',
            symbol: 'APTA',
            decimals: 18,
        },
        infoURL: 'https://bloqs4good.com',
        shortName: 'bloqs4good',
        chainId: 846000,
        networkId: 846000,
    },
    {
        name: 'Vision - Mainnet',
        chain: 'Vision',
        rpc: ['https://infragrid.v.network/ethereum/compatible'],
        faucets: [],
        nativeCurrency: {
            name: 'VS',
            symbol: 'VS',
            decimals: 18,
        },
        infoURL: 'https://www.v.network',
        explorers: [
            {
                name: 'Visionscan',
                url: 'https://www.visionscan.org',
                standard: 'EIP3091',
            },
        ],
        shortName: 'vision',
        chainId: 888888,
        networkId: 888888,
        slip44: 60,
    },
    {
        name: 'Eluvio Content Fabric',
        chain: 'Eluvio',
        rpc: [
            'https://host-76-74-28-226.contentfabric.io/eth/',
            'https://host-76-74-28-232.contentfabric.io/eth/',
            'https://host-76-74-29-2.contentfabric.io/eth/',
            'https://host-76-74-29-8.contentfabric.io/eth/',
            'https://host-76-74-29-34.contentfabric.io/eth/',
            'https://host-76-74-29-35.contentfabric.io/eth/',
            'https://host-154-14-211-98.contentfabric.io/eth/',
            'https://host-154-14-192-66.contentfabric.io/eth/',
            'https://host-60-240-133-202.contentfabric.io/eth/',
            'https://host-64-235-250-98.contentfabric.io/eth/',
        ],
        faucets: [],
        nativeCurrency: {
            name: 'ELV',
            symbol: 'ELV',
            decimals: 18,
        },
        infoURL: 'https://eluv.io',
        shortName: 'elv',
        chainId: 955305,
        networkId: 955305,
        slip44: 1011,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://explorer.eluv.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Etho Protocol',
        chain: 'ETHO',
        rpc: ['https://rpc.ethoprotocol.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Etho Protocol',
            symbol: 'ETHO',
            decimals: 18,
        },
        infoURL: 'https://ethoprotocol.com',
        shortName: 'etho',
        chainId: 1313114,
        networkId: 1313114,
        slip44: 1313114,
        explorers: [
            {
                name: 'blockscout',
                url: 'https://explorer.ethoprotocol.com',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Xerom',
        chain: 'XERO',
        rpc: ['https://rpc.xerom.org'],
        faucets: [],
        nativeCurrency: {
            name: 'Xerom Ether',
            symbol: 'XERO',
            decimals: 18,
        },
        infoURL: 'https://xerom.org',
        shortName: 'xero',
        chainId: 1313500,
        networkId: 1313500,
    },
    {
        name: 'Kintsugi',
        title: 'Kintsugi merge testnet',
        chain: 'ETH',
        rpc: ['https://rpc.kintsugi.themerge.dev'],
        faucets: ['http://fauceth.komputing.org?chain=1337702&address=${ADDRESS}', 'https://faucet.kintsugi.themerge.dev'],
        nativeCurrency: {
            name: 'kintsugi Ethere',
            symbol: 'kiETH',
            decimals: 18,
        },
        infoURL: 'https://kintsugi.themerge.dev/',
        shortName: 'kintsugi',
        chainId: 1337702,
        networkId: 1337702,
        explorers: [
            {
                name: 'kintsugi explorer',
                url: 'https://explorer.kintsugi.themerge.dev',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Kiln',
        chain: 'ETH',
        network: 'testnet',
        rpc: ['https://rpc.kiln.themerge.dev'],
        faucets: ['https://faucet.kiln.themerge.dev', 'https://kiln-faucet.pk910.de', 'https://kilnfaucet.com'],
        nativeCurrency: {
            name: 'Testnet ETH',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://kiln.themerge.dev/',
        shortName: 'kiln',
        chainId: 1337802,
        networkId: 1337802,
        icon: 'ethereum',
        explorers: [
            {
                name: 'Kiln Explorer',
                url: 'https://explorer.kiln.themerge.dev',
                icon: 'ethereum',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'PlatON Dev Testnet',
        chain: 'PlatON',
        rpc: ['https://devnetopenapi2.platon.network/rpc', 'wss://devnetopenapi2.platon.network/ws'],
        faucets: ['https://faucet.platon.network/faucet/?id=e5d32df10aee11ec911142010a667c03'],
        nativeCurrency: {
            name: 'LAT',
            symbol: 'lat',
            decimals: 18,
        },
        infoURL: 'https://www.platon.network',
        shortName: 'platondev',
        chainId: 2203181,
        networkId: 1,
        icon: 'platon',
        explorers: [
            {
                name: 'PlatON explorer',
                url: 'https://devnetscan.platon.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'PlatON Dev Testnet2',
        chain: 'PlatON',
        rpc: ['https://devnet2openapi.platon.network/rpc', 'wss://devnet2openapi.platon.network/ws'],
        faucets: ['https://devnet2faucet.platon.network/faucet'],
        nativeCurrency: {
            name: 'LAT',
            symbol: 'lat',
            decimals: 18,
        },
        infoURL: 'https://www.platon.network',
        shortName: 'platondev2',
        chainId: 2206132,
        networkId: 1,
        icon: 'platon',
        explorers: [
            {
                name: 'PlatON explorer',
                url: 'https://devnet2scan.platon.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Musicoin',
        chain: 'MUSIC',
        rpc: ['https://mewapi.musicoin.tw'],
        faucets: [],
        nativeCurrency: {
            name: 'Musicoin',
            symbol: 'MUSIC',
            decimals: 18,
        },
        infoURL: 'https://musicoin.tw',
        shortName: 'music',
        chainId: 7762959,
        networkId: 7762959,
        slip44: 184,
    },
    {
        name: 'Sepolia',
        title: 'Ethereum Testnet Sepolia',
        chain: 'ETH',
        network: 'testnet',
        rpc: [
            'https://rpc.sepolia.dev',
            'https://rpc.sepolia.online',
            'https://www.sepoliarpc.space',
            'https://rpc.sepolia.org',
            'https://rpc-sepolia.rockx.com',
        ],
        faucets: ['http://fauceth.komputing.org?chain=11155111&address=${ADDRESS}'],
        nativeCurrency: {
            name: 'Sepolia Ether',
            symbol: 'SEP',
            decimals: 18,
        },
        infoURL: 'https://sepolia.otterscan.io',
        shortName: 'sep',
        chainId: 11155111,
        networkId: 11155111,
        explorers: [
            {
                name: 'otterscan-sepolia',
                url: 'https://sepolia.otterscan.io',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'PepChain Churchill',
        chain: 'PEP',
        rpc: ['https://churchill-rpc.pepchain.io'],
        faucets: [],
        nativeCurrency: {
            name: 'PepChain Churchill Ether',
            symbol: 'TPEP',
            decimals: 18,
        },
        infoURL: 'https://pepchain.io',
        shortName: 'tpep',
        chainId: 13371337,
        networkId: 13371337,
    },
    {
        name: 'IOLite',
        chain: 'ILT',
        rpc: ['https://net.iolite.io'],
        faucets: [],
        nativeCurrency: {
            name: 'IOLite Ether',
            symbol: 'ILT',
            decimals: 18,
        },
        infoURL: 'https://iolite.io',
        shortName: 'ilt',
        chainId: 18289463,
        networkId: 18289463,
    },
    {
        name: 'SmartMesh Mainnet',
        chain: 'Spectrum',
        rpc: ['https://jsonapi1.smartmesh.cn'],
        faucets: [],
        nativeCurrency: {
            name: 'SmartMesh Native Token',
            symbol: 'SMT',
            decimals: 18,
        },
        infoURL: 'https://smartmesh.io',
        shortName: 'spectrum',
        chainId: 20180430,
        networkId: 1,
        explorers: [
            {
                name: 'spectrum',
                url: 'https://spectrum.pub',
                standard: 'none',
            },
        ],
    },
    {
        name: 'quarkblockchain',
        chain: 'QKI',
        rpc: ['https://hz.rpc.qkiscan.cn', 'https://jp.rpc.qkiscan.io'],
        faucets: [],
        nativeCurrency: {
            name: 'quarkblockchain Native Token',
            symbol: 'QKI',
            decimals: 18,
        },
        infoURL: 'https://quarkblockchain.org/',
        shortName: 'qki',
        chainId: 20181205,
        networkId: 20181205,
    },
    {
        name: 'Auxilium Network Mainnet',
        chain: 'AUX',
        rpc: ['https://rpc.auxilium.global'],
        faucets: [],
        nativeCurrency: {
            name: 'Auxilium coin',
            symbol: 'AUX',
            decimals: 18,
        },
        infoURL: 'https://auxilium.global',
        shortName: 'auxi',
        chainId: 28945486,
        networkId: 28945486,
        slip44: 344,
    },
    {
        name: 'Joys Digital Mainnet',
        chain: 'JOYS',
        rpc: ['https://node.joys.digital'],
        faucets: [],
        nativeCurrency: {
            name: 'JOYS',
            symbol: 'JOYS',
            decimals: 18,
        },
        infoURL: 'https://joys.digital',
        shortName: 'JOYS',
        chainId: 35855456,
        networkId: 35855456,
    },
    {
        name: 'Aquachain',
        chain: 'AQUA',
        rpc: ['https://c.onical.org', 'https://tx.aquacha.in/api'],
        faucets: ['https://aquacha.in/faucet'],
        nativeCurrency: {
            name: 'Aquachain Ether',
            symbol: 'AQUA',
            decimals: 18,
        },
        infoURL: 'https://aquachain.github.io',
        shortName: 'aqua',
        chainId: 61717561,
        networkId: 61717561,
        slip44: 61717561,
    },
    {
        name: 'Joys Digital TestNet',
        chain: 'TOYS',
        rpc: ['https://toys.joys.cash/'],
        faucets: ['https://faucet.joys.digital/'],
        nativeCurrency: {
            name: 'TOYS',
            symbol: 'TOYS',
            decimals: 18,
        },
        infoURL: 'https://joys.digital',
        shortName: 'TOYS',
        chainId: 99415706,
        networkId: 99415706,
    },
    {
        name: 'Gather Mainnet Network',
        chain: 'GTH',
        rpc: ['https://mainnet.gather.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Gather',
            symbol: 'GTH',
            decimals: 18,
        },
        infoURL: 'https://gather.network',
        shortName: 'GTH',
        chainId: 192837465,
        networkId: 192837465,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://explorer.gather.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Neon EVM DevNet',
        chain: 'Solana',
        rpc: ['https://devnet.neonevm.org'],
        faucets: ['https://neonfaucet.org'],
        icon: 'neon',
        nativeCurrency: {
            name: 'Neon',
            symbol: 'NEON',
            decimals: 18,
        },
        infoURL: 'https://neon-labs.org',
        shortName: 'neonevm-devnet',
        chainId: 245022926,
        networkId: 245022926,
        explorers: [
            {
                name: 'native',
                url: 'https://devnet.explorer.neon-labs.org',
                standard: 'EIP3091',
            },
            {
                name: 'neonscan',
                url: 'https://devnet.neonscan.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Neon EVM MainNet',
        chain: 'Solana',
        rpc: ['https://mainnet.neonevm.org'],
        faucets: [],
        icon: 'neon',
        nativeCurrency: {
            name: 'Neon',
            symbol: 'NEON',
            decimals: 18,
        },
        infoURL: 'https://neon-labs.org',
        shortName: 'neonevm-mainnet',
        chainId: 245022934,
        networkId: 245022934,
        explorers: [
            {
                name: 'native',
                url: 'https://mainnet.explorer.neon-labs.org',
                standard: 'EIP3091',
            },
            {
                name: 'neonscan',
                url: 'https://mainnet.neonscan.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Neon EVM TestNet',
        chain: 'Solana',
        rpc: ['https://testnet.neonevm.org'],
        faucets: [],
        icon: 'neon',
        nativeCurrency: {
            name: 'Neon',
            symbol: 'NEON',
            decimals: 18,
        },
        infoURL: 'https://neon-labs.org',
        shortName: 'neonevm-testnet',
        chainId: 245022940,
        networkId: 245022940,
        explorers: [
            {
                name: 'native',
                url: 'https://testnet.explorer.neon-labs.org',
                standard: 'EIP3091',
            },
            {
                name: 'neonscan',
                url: 'https://testnet.neonscan.org',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'OneLedger Mainnet',
        chain: 'OLT',
        icon: 'oneledger',
        rpc: ['https://mainnet-rpc.oneledger.network'],
        faucets: [],
        nativeCurrency: {
            name: 'OLT',
            symbol: 'OLT',
            decimals: 18,
        },
        infoURL: 'https://oneledger.io',
        shortName: 'oneledger',
        chainId: 311752642,
        networkId: 311752642,
        explorers: [
            {
                name: 'OneLedger Block Explorer',
                url: 'https://mainnet-explorer.oneledger.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Gather Testnet Network',
        chain: 'GTH',
        rpc: ['https://testnet.gather.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Gather',
            symbol: 'GTH',
            decimals: 18,
        },
        infoURL: 'https://gather.network',
        shortName: 'tGTH',
        chainId: 356256156,
        networkId: 356256156,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://testnet-explorer.gather.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'Gather Devnet Network',
        chain: 'GTH',
        rpc: ['https://devnet.gather.network'],
        faucets: [],
        nativeCurrency: {
            name: 'Gather',
            symbol: 'GTH',
            decimals: 18,
        },
        infoURL: 'https://gather.network',
        shortName: 'dGTH',
        chainId: 486217935,
        networkId: 486217935,
        explorers: [
            {
                name: 'Blockscout',
                url: 'https://devnet-explorer.gather.network',
                standard: 'none',
            },
        ],
    },
    {
        name: 'IPOS Network',
        chain: 'IPOS',
        rpc: ['https://rpc.iposlab.com', 'https://rpc2.iposlab.com'],
        faucets: [],
        nativeCurrency: {
            name: 'IPOS Network Ether',
            symbol: 'IPOS',
            decimals: 18,
        },
        infoURL: 'https://iposlab.com',
        shortName: 'ipos',
        chainId: 1122334455,
        networkId: 1122334455,
    },
    {
        name: 'Aurora Mainnet',
        chain: 'NEAR',
        rpc: ['https://mainnet.aurora.dev'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://aurora.dev',
        shortName: 'aurora',
        chainId: 1313161554,
        networkId: 1313161554,
        explorers: [
            {
                name: 'aurorascan.dev',
                url: 'https://aurorascan.dev',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Aurora Testnet',
        chain: 'NEAR',
        rpc: ['https://testnet.aurora.dev/'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://aurora.dev',
        shortName: 'aurora-testnet',
        chainId: 1313161555,
        networkId: 1313161555,
        explorers: [
            {
                name: 'aurorascan.dev',
                url: 'https://testnet.aurorascan.dev',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Aurora Betanet',
        chain: 'NEAR',
        rpc: ['https://betanet.aurora.dev/'],
        faucets: [],
        nativeCurrency: {
            name: 'Ether',
            symbol: 'ETH',
            decimals: 18,
        },
        infoURL: 'https://aurora.dev',
        shortName: 'aurora-betanet',
        chainId: 1313161556,
        networkId: 1313161556,
    },
    {
        name: 'Harmony Mainnet Shard 0',
        chain: 'Harmony',
        rpc: ['https://api.harmony.one', 'https://api.s0.t.hmny.io'],
        faucets: ['https://free-online-app.com/faucet-for-eth-evm-chains/'],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-s0',
        chainId: 1666600000,
        networkId: 1666600000,
        explorers: [
            {
                name: 'Harmony Block Explorer',
                url: 'https://explorer.harmony.one',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Harmony Mainnet Shard 1',
        chain: 'Harmony',
        rpc: ['https://api.s1.t.hmny.io'],
        faucets: [],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-s1',
        chainId: 1666600001,
        networkId: 1666600001,
    },
    {
        name: 'Harmony Mainnet Shard 2',
        chain: 'Harmony',
        rpc: ['https://api.s2.t.hmny.io'],
        faucets: [],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-s2',
        chainId: 1666600002,
        networkId: 1666600002,
    },
    {
        name: 'Harmony Mainnet Shard 3',
        chain: 'Harmony',
        rpc: ['https://api.s3.t.hmny.io'],
        faucets: [],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-s3',
        chainId: 1666600003,
        networkId: 1666600003,
    },
    {
        name: 'Harmony Testnet Shard 0',
        chain: 'Harmony',
        rpc: ['https://api.s0.b.hmny.io'],
        faucets: ['https://faucet.pops.one'],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-b-s0',
        chainId: 1666700000,
        networkId: 1666700000,
        explorers: [
            {
                name: 'Harmony Testnet Block Explorer',
                url: 'https://explorer.pops.one',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Harmony Testnet Shard 1',
        chain: 'Harmony',
        rpc: ['https://api.s1.b.hmny.io'],
        faucets: [],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-b-s1',
        chainId: 1666700001,
        networkId: 1666700001,
    },
    {
        name: 'Harmony Testnet Shard 2',
        chain: 'Harmony',
        rpc: ['https://api.s2.b.hmny.io'],
        faucets: [],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-b-s2',
        chainId: 1666700002,
        networkId: 1666700002,
    },
    {
        name: 'Harmony Testnet Shard 3',
        chain: 'Harmony',
        rpc: ['https://api.s3.b.hmny.io'],
        faucets: [],
        nativeCurrency: {
            name: 'ONE',
            symbol: 'ONE',
            decimals: 18,
        },
        infoURL: 'https://www.harmony.one/',
        shortName: 'hmy-b-s3',
        chainId: 1666700003,
        networkId: 1666700003,
    },
    {
        name: 'DataHopper',
        chain: 'HOP',
        rpc: ['https://23.92.21.121:8545'],
        faucets: [],
        nativeCurrency: {
            name: 'DataHoppers',
            symbol: 'HOP',
            decimals: 18,
        },
        infoURL: 'https://www.DataHopper.com',
        shortName: 'hop',
        chainId: 2021121117,
        networkId: 2021121117,
    },
    {
        name: 'Pirl',
        chain: 'PIRL',
        rpc: ['https://wallrpc.pirl.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Pirl Ether',
            symbol: 'PIRL',
            decimals: 18,
        },
        infoURL: 'https://pirl.io',
        shortName: 'pirl',
        chainId: 3125659152,
        networkId: 3125659152,
        slip44: 164,
    },
    {
        name: 'OneLedger Testnet Frankenstein',
        chain: 'OLT',
        icon: 'oneledger',
        rpc: ['https://frankenstein-rpc.oneledger.network'],
        faucets: ['https://frankenstein-faucet.oneledger.network'],
        nativeCurrency: {
            name: 'OLT',
            symbol: 'OLT',
            decimals: 18,
        },
        infoURL: 'https://oneledger.io',
        shortName: 'frankenstein',
        chainId: 4216137055,
        networkId: 4216137055,
        explorers: [
            {
                name: 'OneLedger Block Explorer',
                url: 'https://frankenstein-explorer.oneledger.network',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Palm Testnet',
        chain: 'Palm',
        icon: 'palm',
        rpc: ['https://palm-testnet.infura.io/v3/${INFURA_API_KEY}'],
        faucets: [],
        nativeCurrency: {
            name: 'PALM',
            symbol: 'PALM',
            decimals: 18,
        },
        infoURL: 'https://palm.io',
        shortName: 'tpalm',
        chainId: 11297108099,
        networkId: 11297108099,
        explorers: [
            {
                name: 'Palm Testnet Explorer',
                url: 'https://explorer.palm-uat.xyz',
                standard: 'EIP3091',
                icon: 'palm',
            },
        ],
    },
    {
        name: 'Palm',
        chain: 'Palm',
        icon: 'palm',
        rpc: ['https://palm-mainnet.infura.io/v3/${INFURA_API_KEY}'],
        faucets: [],
        nativeCurrency: {
            name: 'PALM',
            symbol: 'PALM',
            decimals: 18,
        },
        infoURL: 'https://palm.io',
        shortName: 'palm',
        chainId: 11297108109,
        networkId: 11297108109,
        explorers: [
            {
                name: 'Palm Explorer',
                url: 'https://explorer.palm.io',
                standard: 'EIP3091',
                icon: 'palm',
            },
        ],
    },
    {
        name: 'Ntity Mainnet',
        chain: 'Ntity',
        rpc: ['https://rpc.ntity.io'],
        faucets: [],
        nativeCurrency: {
            name: 'Ntity',
            symbol: 'NTT',
            decimals: 18,
        },
        infoURL: 'https://ntity.io',
        shortName: 'ntt',
        chainId: 197710212030,
        networkId: 197710212030,
        icon: 'ntity',
        explorers: [
            {
                name: 'Ntity Blockscout',
                url: 'https://blockscout.ntity.io',
                icon: 'ntity',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Haradev Testnet',
        chain: 'Ntity',
        rpc: ['https://blockchain.haradev.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Ntity Haradev',
            symbol: 'NTTH',
            decimals: 18,
        },
        infoURL: 'https://ntity.io',
        shortName: 'ntt-haradev',
        chainId: 197710212031,
        networkId: 197710212031,
        icon: 'ntity',
        explorers: [
            {
                name: 'Ntity Haradev Blockscout',
                url: 'https://blockscout.haradev.com',
                icon: 'ntity',
                standard: 'EIP3091',
            },
        ],
    },
    {
        name: 'Molereum Network',
        chain: 'ETH',
        rpc: ['https://molereum.jdubedition.com'],
        faucets: [],
        nativeCurrency: {
            name: 'Molereum Ether',
            symbol: 'MOLE',
            decimals: 18,
        },
        infoURL: 'https://github.com/Jdubedition/molereum',
        shortName: 'mole',
        chainId: 6022140761023,
        networkId: 6022140761023,
    },
    {
        name: 'Godwoken Testnet (V1)',
        chain: 'GWT',
        rpc: ['https://godwoken-testnet-web3-v1-rpc.ckbapp.dev'],
        faucets: ['https://homura.github.io/light-godwoken'],
        nativeCurrency: {
            name: 'CKB',
            symbol: 'CKB',
            decimals: 8,
        },
        infoURL: 'https://www.nervos.org',
        shortName: 'gw-testnet-v1-deprecated',
        chainId: 868455272153094,
        networkId: 868455272153094,
        status: 'deprecated',
        explorers: [
            {
                name: 'GWScan Block Explorer',
                url: 'https://v1.aggron.gwscan.com',
                standard: 'none',
            },
        ],
    },
];
//# sourceMappingURL=chaindata.js.map

/***/ }),

/***/ 1559:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Erc20Token = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
/**
 * The Erc20Token class is a MoralisData that references to a Erc20 Token
 * It holds data about the data and metadata of an Erc20 token
 *
 * @category DataType
 */
var Erc20Token = /** @class */ (function () {
    function Erc20Token(value, core) {
        this._value = Erc20Token.parse(value, core);
    }
    /**
     *  Create a new instance of Erc20Token from any valid Erc20Token input
     *
     * @param value - the Erc20Tokenish type
     * @example
     * ```ts
     * const token = Erc20Token.create(value);
     * ```
     */
    Erc20Token.create = function (value, core) {
        if (value instanceof Erc20Token) {
            return value;
        }
        var finalCore = core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault();
        return new Erc20Token(value, finalCore);
    };
    /**
     * Compares two Erc20Token instances. This checks if the chain and contractAddress of both tokens are equal.
     *
     * @param valueA - the first Erc20Token to compare
     * @param valueB - the second Erc20Token to compare
     * @returns true if the two Erc20Tokens are equal
     * @example
     * ```ts
     * Erc20Token.equals(valueA, valueB);
     * ```
     */
    Erc20Token.equals = function (valueA, valueB) {
        var erc20A = Erc20Token.create(valueA);
        var erc20B = Erc20Token.create(valueB);
        if (!erc20A._value.chain.equals(erc20B._value.chain)) {
            return false;
        }
        if (!erc20A._value.contractAddress.equals(erc20B._value.contractAddress)) {
            return false;
        }
        return true;
    };
    /**
     * Compares Erc20Token instance to current instance
     *
     * @param value - the Erc20Tokenish to compare
     * @returns true if the Erc20Token is equals given token
     * @example
     * ```ts
     * token.equals(value);
     * ```
     */
    Erc20Token.prototype.equals = function (value) {
        return Erc20Token.equals(this, value);
    };
    /**
     * Returns the token as JSON
     *
     * @returns the Erc20Token as a JSON object
     * @example
     * ```ts
     * token.toJSON();
     * ```
     */
    Erc20Token.prototype.toJSON = function () {
        var value = this._value;
        return __assign(__assign({}, value), { contractAddress: value.contractAddress.format(), chain: value.chain.format() });
    };
    /**
     * Returns the token as JSON
     *
     * @returns the Erc20Token as a JSON object
     * @example
     * ```ts
     * token.format();
     * ```
     */
    Erc20Token.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(Erc20Token.prototype, "result", {
        /**
         * Returns the processed Erc20Token.
         *
         * @returns the Erc20Token value
         * @example
         * ```ts
         * token.result;
         *  ```
         */
        get: function () {
            return this._value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "decimals", {
        /**
         * @returns the decimals of the token.
         *
         * @example
         * ```ts
         * token.decimals;
         * ```
         */
        get: function () {
            return this._value.decimals;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "name", {
        /**
         * @returns The name of the token.
         *
         * @example
         * ```ts
         * token.name;
         * ```
         */
        get: function () {
            return this._value.name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "symbol", {
        /**
         * @returns The symbol of the token.
         *
         * @example
         * ```ts
         * token.symbol;
         * ```
         */
        get: function () {
            return this._value.symbol;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "contractAddress", {
        /**
         * @returns The contract address of the token.
         *
         * @example
         * ```ts
         * token.contractAddress;
         * ```
         */
        get: function () {
            return this._value.contractAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "chain", {
        /**
         * @returns The chain of the token.
         *
         * @example
         * ```ts
         * token.chain;
         * ```
         */
        get: function () {
            return this._value.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "logo", {
        /**
         * @returns The logo of the token.
         *
         * @example
         * ```ts
         * token.logo;
         * ```
         */
        get: function () {
            return this._value.logo;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "logoHash", {
        /**
         * @returns The logo hash of the token.
         *
         * @example
         * ```ts
         * token.logoHash;
         * ```
         */
        get: function () {
            return this._value.logoHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Token.prototype, "thumbnail", {
        /**
         * @returns The thumbnail of the token.
         *
         * @example
         * ```ts
         * token.thumbnail;
         * ```
         */
        get: function () {
            return this._value.thumbnail;
        },
        enumerable: false,
        configurable: true
    });
    Erc20Token.parse = function (value, core) { return ({
        decimals: +value.decimals,
        name: value.name,
        symbol: value.symbol,
        contractAddress: EvmAddress_1.EvmAddress.create(value.contractAddress, core),
        logo: (0, core_1.maybe)(value.logo),
        logoHash: (0, core_1.maybe)(value.logoHash),
        thumbnail: (0, core_1.maybe)(value.thumbnail),
        chain: EvmChain_1.EvmChain.create(value.chain, core),
    }); };
    return Erc20Token;
}());
exports.Erc20Token = Erc20Token;
//# sourceMappingURL=Erc20.js.map

/***/ }),

/***/ 1339:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(1559), exports);
__exportStar(__webpack_require__(3186), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 3186:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 123:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Erc20Transfer = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
/**
 * The Erc20Transfer is a representation of an Erc20 token transfer.
 *
 * @category DataType
 */
var Erc20Transfer = /** @class */ (function () {
    function Erc20Transfer(data) {
        this._data = Erc20Transfer.parse(data);
    }
    /**
     * Create a new instance of Erc20Transfer from any valid input
     * @param data - the Erc20Transferish type
     * @example
     * ```
     * const transfer = Erc20Transfer.create(data);
     *```
     */
    Erc20Transfer.create = function (data) {
        if (data instanceof Erc20Transfer) {
            return data;
        }
        return new Erc20Transfer(data);
    };
    /**
     * Check the equality between two Erc20 transfers
     * @param dataA - The first transfer to compare
     * @param dataB - The second transfer to compare
     * @example Erc20Transfer.equals(dataA, dataB)
     * @returns true if the transfers are equal, false otherwise
     */
    Erc20Transfer.equals = function (dataA, dataB) {
        var tokenA = Erc20Transfer.create(dataA);
        var tokenB = Erc20Transfer.create(dataB);
        return JSON.stringify(tokenA.toJSON()) === JSON.stringify(tokenB.toJSON());
    };
    /**
     * Checks the equality of the current trnasfer with another erc20 trnasfer
     * @param data - the trnasfer to compare with
     * @example transfer.equals(data)
     * @returns true if the transfers are equal, false otherwise
     */
    Erc20Transfer.prototype.equals = function (data) {
        return Erc20Transfer.equals(this, data);
    };
    /**
     * @returns a JSON represention of the transfer.
     * @example transfer.toJSON()
     */
    Erc20Transfer.prototype.toJSON = function () {
        var data = this._data;
        return __assign(__assign({}, data), { chain: data.chain.format(), address: data.address.format(), blockNumber: data.blockNumber.toString(), toAddress: data.toAddress.format(), fromAddress: data.fromAddress.format(), value: data.value.toString() });
    };
    /**
     * @returns a JSON represention of the transfer.
     * @example transfer.format()
     */
    Erc20Transfer.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(Erc20Transfer.prototype, "result", {
        /**
         * @returns all the data without casting it to JSON.
         * @example transfer.result
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "address", {
        /**
         * @returns the address of the tranfer
         * @example transfer.address // EvmAddress
         */
        get: function () {
            return this._data.address;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "blockHash", {
        /**
         * @returns the block hash of the tranfer
         * @example transfer.blockHash // "0x0372c302e3c52e8f2e15d155e2c545e6d802e479236564af052759253b20fd86"
         */
        get: function () {
            return this._data.blockHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "blockNumber", {
        /**
         * @returns the block number of the tranfer
         * @example transfer.blockNumber // BigNumber
         */
        get: function () {
            return this._data.blockNumber;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "blockTimestamp", {
        /**
         * @returns the block timestamp of the tranfer
         * @example transfer.blockTimestamp // Date
         */
        get: function () {
            return this._data.blockTimestamp;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "chain", {
        /**
         * @returns the chain of the tranfer
         * @example transfer.chain // EvmChain
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "fromAddress", {
        /**
         * @returns the from address of the tranfer
         * @example transfer.fromAddress // EvmAddress
         */
        get: function () {
            return this._data.fromAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "toAddress", {
        /**
         * @returns the to address of the tranfer
         * @example transfer.toAddress // EvmAddress
         */
        get: function () {
            return this._data.toAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "transactionHash", {
        /**
         * @returns the transaction hash of the tranfer
         * @example transfer.transactionHash // "0x0372c302e3c52e8f2e15d155e2c545e6d802e479236564af052759253b20fd86"
         */
        get: function () {
            return this._data.transactionHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "value", {
        /**
         * @returns the value of the tranfer
         * @example transfer.value // BigNumber
         */
        get: function () {
            return this._data.value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "transactionIndex", {
        /**
         * @returns the transactionIndex of the tranfer
         * @example transfer.transactionIndex // 3
         */
        get: function () {
            return this._data.transactionIndex;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Transfer.prototype, "logIndex", {
        /**
         * @returns the logIndex of the tranfer
         * @example transfer.logIndex // 2
         */
        get: function () {
            return this._data.logIndex;
        },
        enumerable: false,
        configurable: true
    });
    Erc20Transfer.parse = function (data) { return (__assign(__assign({}, data), { chain: EvmChain_1.EvmChain.create(data.chain), address: EvmAddress_1.EvmAddress.create(data.address), blockTimestamp: (0, core_1.dateInputToDate)(data.blockTimestamp), blockNumber: core_1.BigNumber.create(data.blockNumber), toAddress: EvmAddress_1.EvmAddress.create(data.toAddress), fromAddress: EvmAddress_1.EvmAddress.create(data.fromAddress), value: core_1.BigNumber.create(data.value) })); };
    return Erc20Transfer;
}());
exports.Erc20Transfer = Erc20Transfer;
//# sourceMappingURL=Erc20Transfer.js.map

/***/ }),

/***/ 3500:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(123), exports);
__exportStar(__webpack_require__(6858), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6858:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 494:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Erc20Value = void 0;
var core_1 = __webpack_require__(4243);
var Erc20_1 = __webpack_require__(1559);
var EVM_ERC20_DEFAULT_DECIMALS = 18;
/**
 * The Erc20Value class is a MoralisData that references to a the value of an Erc20Token
 * It holds data about the data about the amount of tokens and the number of decimals.
 *
 * @category DataType
 */
var Erc20Value = /** @class */ (function () {
    function Erc20Value(amount, options) {
        var _this = this;
        var _a, _b, _c;
        /**
         * Displays the token in text format
         * @returns the value and also the token symbol if available
         * @example value.display();
         */
        this.display = function () {
            if (!_this._token) {
                return "".concat(_this.value);
            }
            return "".concat(_this.value, " ").concat(_this._token.symbol);
        };
        this._value = Erc20Value.parse({
            amount: amount,
            decimals: (_c = (_a = options === null || options === void 0 ? void 0 : options.decimals) !== null && _a !== void 0 ? _a : (_b = options === null || options === void 0 ? void 0 : options.token) === null || _b === void 0 ? void 0 : _b.decimals) !== null && _c !== void 0 ? _c : EVM_ERC20_DEFAULT_DECIMALS,
            token: options === null || options === void 0 ? void 0 : options.token,
        });
        if (options === null || options === void 0 ? void 0 : options.token) {
            this._token = Erc20_1.Erc20Token.create(options.token);
        }
    }
    /**
     * Create a new instance of Erc20Value from any valid input
     * @param value - The value to create
     * @param options - The options for the token
     * @example Erc20Value.create(1000, { decimals: 3 });
     * @returns The created value
     * @throws MoralisCoreError if the value is invalid
     */
    Erc20Value.create = function (value, options) {
        if (value instanceof Erc20Value) {
            return value;
        }
        return new Erc20Value(value, options);
    };
    /**
     * Compares two Erc20Valueish instances.
     * @param valueA - The first value to compare
     * @param valueB - The second value to compare
     * @returns True if the values are equal
     * @example
     * ```ts
     * const valueA = Erc20Value.create(1000, { decimals: 3 });
     * const valueB = Erc20Value.create(10000, { decimals: 4 });
     * Erc20Value.equals(valueA, valueB); // true
     * ```
     */
    Erc20Value.equals = function (valueA, valueB) {
        var erc20ValueA = Erc20Value.create(valueA);
        var erc20ValueB = Erc20Value.create(valueB);
        return erc20ValueA.value === erc20ValueB.value;
    };
    /**
     * Compares Erc20Value with current instance.
     * @param value - The value to compare
     * @returns True if the values are equal
     * @example value.equals(valueA);
     */
    Erc20Value.prototype.equals = function (value) {
        return Erc20Value.equals(this, value);
    };
    /**
     * Convert the value to a number
     * @returns the value in number format
     * @example value.toNumber();
     */
    Erc20Value.prototype.toNumber = function () {
        return +this.value;
    };
    /**
     * Convert the value to a string
     * @returns the value in string format
     * @example value.toString();
     */
    Erc20Value.prototype.toString = function () {
        return this.value;
    };
    /**
     * Convert the value to a string
     * @returns the value in string format
     * @example value.format();
     */
    Erc20Value.prototype.format = function () {
        return this.toString();
    };
    /**
     * Displays the token in JSON format
     * @returns the value and also the token if available
     * @example value.toJSON();
     */
    Erc20Value.prototype.toJSON = function () {
        if (this.token) {
            return { value: this.value, token: this.token.toJSON() };
        }
        return { value: this.value };
    };
    Object.defineProperty(Erc20Value.prototype, "decimals", {
        /**
         * @returns the token decimals
         * @example value.decimals; // 15
         */
        get: function () {
            return this._value.decimals;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Value.prototype, "amount", {
        /**
         * @returns the token amount
         * @example value.amount; // BigNumber
         */
        get: function () {
            return this._value.amount;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Value.prototype, "value", {
        /**
         * @returns the token value
         * @example value.value; // "1000"
         */
        get: function () {
            return this._value.amount.toDecimal(this.decimals);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Erc20Value.prototype, "token", {
        /**
         * @returns the token
         * @example value.token; // Erc20Token
         */
        get: function () {
            var _a;
            return (_a = this._token) !== null && _a !== void 0 ? _a : null;
        },
        enumerable: false,
        configurable: true
    });
    Erc20Value.parse = function (_a) {
        var amount = _a.amount, decimals = _a.decimals, token = _a.token;
        if (token && token.decimals && +token.decimals !== +decimals) {
            throw new core_1.MoralisCoreError({
                code: core_1.CoreErrorCode.INVALID_DATA,
                message: 'Decimals do not match',
            });
        }
        return {
            amount: core_1.BigNumber.create(amount),
            decimals: +decimals,
        };
    };
    return Erc20Value;
}());
exports.Erc20Value = Erc20Value;
//# sourceMappingURL=Erc20Value.js.map

/***/ }),

/***/ 8856:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(494), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 4827:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmAddress = void 0;
var core_1 = __webpack_require__(4243);
var address_1 = __webpack_require__(1541);
var EvmUtilsConfig_1 = __webpack_require__(4362);
/**
 * A representation of an address on the EVM network.
 *
 * Use this class any time you work with an address, as it will provide utilities to validate the address,
 * and format it to lowercase and checksum format.
 *
 * @category DataType
 */
var EvmAddress = /** @class */ (function () {
    function EvmAddress(address, config) {
        this.config = config;
        this._value = EvmAddress.parse(address);
    }
    Object.defineProperty(EvmAddress, "ZERO_ADDRESS", {
        /**
         * @returns EvmAddress instance of the zero address: "0x0000000000000000000000000000000000000000"
         * @example `EvmAddress.ZERO_ADDRESS`
         */
        get: function () {
            return EvmAddress.create('0x0000000000000000000000000000000000000000');
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Create a new instance of EvmAddress from any valid address input
     *
     * @example
     * ```
     * const address = EvmAddress.create("0xfb6916095ca1df60bb79ce92ce3ea74c37c5d359")
     * const address = EvmAddress.create("0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359")
     * const address = EvmAddress.ZERO_ADDRESS
     * ```
     */
    EvmAddress.create = function (address, core) {
        if (address instanceof EvmAddress) {
            return address;
        }
        var finalCore = core || core_1.MoralisCoreProvider.getDefault();
        return new EvmAddress(address, finalCore.config);
    };
    EvmAddress.parse = function (address) {
        if (!(0, address_1.isAddress)(address)) {
            throw new core_1.MoralisCoreError({
                code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                message: 'Invalid address provided',
            });
        }
        return (0, address_1.getAddress)(address);
    };
    /**
     * Check the equality between two Evm addresses
     * @example `EvmAddress.equals("0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359", "0xfb6916095ca1df60bb79ce92ce3ea74c37c5d359")`
     */
    EvmAddress.equals = function (addressA, addressB) {
        return EvmAddress.create(addressA)._value === EvmAddress.create(addressB)._value;
    };
    /**
     * Checks the equality of the current address with another evm address
     * @example `address.equals("0xfb6916095ca1df60bb79ce92ce3ea74c37c5d359")`
     */
    EvmAddress.prototype.equals = function (address) {
        return EvmAddress.equals(this, address);
    };
    /**
     * Formats the address to a specific format.
     * If no formatStyle is provided as argument, it will use the `formatEvmAddress` set in the config.
     * @example `address.format() // "0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359"`
     */
    EvmAddress.prototype.format = function (style) {
        var formatStyle = style !== null && style !== void 0 ? style : this.config.get(EvmUtilsConfig_1.EvmUtilsConfig.formatEvmAddress);
        if (formatStyle === 'checksum') {
            return this.checksum;
        }
        if (formatStyle === 'lowercase') {
            return this.lowercase;
        }
        throw new core_1.MoralisCoreError({
            code: core_1.CoreErrorCode.INVALID_ARGUMENT,
            message: 'Cannot format address, invalid config.formatAddress',
        });
    };
    Object.defineProperty(EvmAddress.prototype, "checksum", {
        /**
         * @returns the address value in checksum (EIP-55) format (see https://eips.ethereum.org/EIPS/eip-55)
         * @example `address.checksum // "0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359"`
         */
        get: function () {
            return this._value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmAddress.prototype, "lowercase", {
        /**
         * @returns the address value in lowercase format
         * @example `address.lowercase // "0xfb6916095ca1df60bb79ce92ce3ea74c37c5d359"`
         */
        get: function () {
            return this._value.toLowerCase();
        },
        enumerable: false,
        configurable: true
    });
    return EvmAddress;
}());
exports.EvmAddress = EvmAddress;
//# sourceMappingURL=EvmAddress.js.map

/***/ }),

/***/ 4142:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(4827), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7542:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmBlock = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
var EvmTransaction_1 = __webpack_require__(7048);
/**
 * The EvmBlock is a representation of a block.
 *
 * @category DataType
 */
var EvmBlock = /** @class */ (function () {
    function EvmBlock(data, core) {
        this._data = EvmBlock.parse(data, core);
    }
    /**
     * Create a new instance of EvmBlock from any valid transaction input
     * @param data - the EvmBlockish type
     * @example const transaction = EvmTransaction.create(data);
     */
    EvmBlock.create = function (data, core) {
        if (data instanceof EvmBlock) {
            return data;
        }
        var finalCore = core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault();
        return new EvmBlock(data, finalCore);
    };
    /**
     * Check the equality between two Evm blocks. It compares their hashes and blocks.
     * @param dataA - The first block to compare
     * @param dataB - The second block to compare
     * @example EvmTransaction.equals(dataA, dataB)
     */
    EvmBlock.equals = function (dataA, dataB) {
        var blockA = EvmBlock.create(dataA);
        var blockB = EvmBlock.create(dataB);
        if (!blockA._data.chain.equals(blockB._data.chain)) {
            return false;
        }
        if (blockA._data.hash !== blockB._data.hash) {
            return false;
        }
        return true;
    };
    /**
     * Checks the equality of the current block with another evm block
     * @param data - the block to compare with
     * @example
     * ```ts
     * block.equals(data)
     * ```
     */
    EvmBlock.prototype.equals = function (data) {
        return EvmBlock.equals(this, data);
    };
    /**
     * @returns a JSON represention of the block.
     * @example
     * ```
     * block.toJSON()
     * ```
     */
    EvmBlock.prototype.toJSON = function () {
        var data = this._data;
        return __assign(__assign({}, data), { number: data.number.toString(), difficulty: data.difficulty.toString(), totalDifficulty: data.totalDifficulty.toString(), size: data.size.toString(), gasLimit: data.gasLimit.toString(), gasUsed: data.gasUsed.toString(), chain: data.chain.format(), miner: data.miner.format(), transactions: data.transactions.map(function (transaction) { return transaction.toJSON(); }) });
    };
    /**
     * @returns a JSON represention of the block.
     * @example
     * ```
     * block.format()
     * ```
     */
    EvmBlock.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmBlock.prototype, "result", {
        /**
         * @returns all the data without casting it to JSON.
         * @example block.result
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "number", {
        /**
         * @returns the block number.
         * @example block.number // BigNumber
         */
        get: function () {
            return this._data.number;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "hash", {
        /**
         * @returns the block hash.
         * @example block.hash // "0x9b559aef7ea858608c2e554246fe4a24287e7aeeb976848df2b9a2531f4b9171"
         */
        get: function () {
            return this._data.hash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "timestamp", {
        /**
         * @returns the block timestamp.
         * @example block.timestamp // Date
         */
        get: function () {
            return this._data.timestamp;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "miner", {
        /**
         * @returns the block miner.
         * @example block.miner // EvmAddress
         */
        get: function () {
            return this._data.miner;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "difficulty", {
        /**
         * @returns the block difficulty.
         * @example block.difficulty // BigNumber
         */
        get: function () {
            return this._data.difficulty;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "totalDifficulty", {
        /**
         * @returns the block total difficulty.
         * @example block.totalDifficulty // BigNumber
         */
        get: function () {
            return this._data.totalDifficulty;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "size", {
        /**
         * @returns the block size.
         * @example block.size // BigNumber
         */
        get: function () {
            return this._data.size;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "gasLimit", {
        /**
         * @returns the block gas limit.
         * @example block.gasLimit // BigNumber
         */
        get: function () {
            return this._data.gasLimit;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "gasUsed", {
        /**
         * @returns the block gas used.
         * @example block.gasUsed // BigNumber
         */
        get: function () {
            return this._data.gasUsed;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "transactions", {
        /**
         * @returns the block transactions.
         * @example block.transactions // EvmTransaction[]
         */
        get: function () {
            return this._data.transactions;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "chain", {
        /**
         * @returns the block chain.
         * @example block.chain // EvmChain
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "transactionCount", {
        /**
         * @returns the block transaction count.
         * @example block.transactionCount // 252
         */
        get: function () {
            return this._data.transactionCount;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "transactionsRoot", {
        /**
         * @returns the block transactions root.
         * @example block.transactionsRoot // "0xe4c7bf3aff7ad07f9e80d57f7189f0252592fee6321c2a9bd9b09b6ce0690d27"
         */
        get: function () {
            return this._data.transactionsRoot;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "stateRoot", {
        /**
         * @returns the block state root.
         * @example block.stateRoot // "0x49e3bfe7b618e27fde8fa08884803a8458b502c6534af69873a3cc926a7c724b"
         */
        get: function () {
            return this._data.stateRoot;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "receiptsRoot", {
        /**
         * @returns the block receipts root.
         * @example block.receiptsRoot // "0x7cf43d7e837284f036cf92c56973f5e27bdd253ca46168fa195a6b07fa719f23"
         */
        get: function () {
            return this._data.receiptsRoot;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "logsBloom", {
        /**
         * @returns the block logs bloom.
         * @example block.logsBloom // "0xdde5fc46c5d8bcbd58207bc9f267bf43298e23791a326ff02661e99790da9996b3e0dd912c0b8202d389d282c56e4d11eb2dec4898a32b6b165f1f4cae6aa0079498eab50293f3b8defbf6af11bb75f0408a563ddfc26a3323d1ff5f9849e95d5f034d88a757ddea032c75c00708c9ff34d2207f997cc7d93fd1fa160a6bfaf62a54e31f9fe67ab95752106ba9d185bfdc9b6dc3e17427f844ee74e5c09b17b83ad6e8fc7360f5c7c3e4e1939e77a6374bee57d1fa6b2322b11ad56ad0398302de9b26d6fbfe414aa416bff141fad9d4af6aea19322e47595e342cd377403f417dfd396ab5f151095a5535f51cbc34a40ce9648927b7d1d72ab9daf253e31daf"
         */
        get: function () {
            return this._data.logsBloom;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "extraData", {
        /**
         * @returns the block extra data.
         * @example block.extraData // "0x65746865726d696e652d6575726f70652d7765737433"
         */
        get: function () {
            return this._data.extraData;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "parentHash", {
        /**
         * @returns the block parent hash.
         * @example block.parentHash // "0x011d1fc45839de975cc55d758943f9f1d204f80a90eb631f3bf064b80d53e045"
         */
        get: function () {
            return this._data.parentHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "sha3Uncles", {
        /**
         * @returns the block sha3Uncles.
         * @example block.sha3Uncles // "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347"
         */
        get: function () {
            return this._data.sha3Uncles;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmBlock.prototype, "nonce", {
        /**
         * @returns the block nonce.
         * @example block.nonce // "0xedeb2d8fd2b2bdec"
         */
        get: function () {
            return this._data.nonce;
        },
        enumerable: false,
        configurable: true
    });
    EvmBlock.parse = function (data, core) { return (__assign(__assign({}, data), { miner: EvmAddress_1.EvmAddress.create(data.miner, core), timestamp: (0, core_1.dateInputToDate)(data.timestamp), number: core_1.BigNumber.create(data.number), difficulty: core_1.BigNumber.create(data.difficulty), totalDifficulty: core_1.BigNumber.create(data.totalDifficulty), size: core_1.BigNumber.create(data.size), gasLimit: core_1.BigNumber.create(data.gasLimit), gasUsed: core_1.BigNumber.create(data.gasUsed), transactions: data.transactions.map(function (transaction) { return EvmTransaction_1.EvmTransaction.create(transaction, core); }), chain: EvmChain_1.EvmChain.create(data.chain, core), transactionCount: +data.transactionCount })); };
    return EvmBlock;
}());
exports.EvmBlock = EvmBlock;
//# sourceMappingURL=EvmBlock.js.map

/***/ }),

/***/ 7145:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(7542), exports);
__exportStar(__webpack_require__(9377), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9377:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 83:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmChain = void 0;
var chaindata_1 = __webpack_require__(1385);
var EvmChainParser_1 = __webpack_require__(3607);
var core_1 = __webpack_require__(4243);
var EvmUtilsConfig_1 = __webpack_require__(4362);
/**
 * The EvmChain class is a MoralisData that references to a EVM chain
 * @category DataType
 */
var EvmChain = /** @class */ (function () {
    function EvmChain(value, config) {
        var _this = this;
        var _a;
        this.config = config;
        this._value = EvmChainParser_1.EvmChainParser.parse(value);
        this._chainlistData = (_a = chaindata_1.chainList.find(function (chainData) { return chainData.chainId === _this.decimal; })) !== null && _a !== void 0 ? _a : null;
    }
    Object.defineProperty(EvmChain, "ETHEREUM", {
        /**
         * Returns ETHEREUM chain
         *
         * @example EvmChain.ETHEREUM
         */
        get: function () {
            return EvmChain.create(1);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "GOERLI", {
        /**
         * Returns GOERLI chain
         *
         * @example EvmChain.GOERLI
         */
        get: function () {
            return EvmChain.create(5);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "SEPOLIA", {
        get: function () {
            return EvmChain.create(11155111);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "POLYGON", {
        /**
         * Returns POLYGON chain
         *
         * @example EvmChain.POLYGON
         */
        get: function () {
            return EvmChain.create(137);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "MUMBAI", {
        /**
         * Returns MUMBAI chain
         *
         * @example EvmChain.MUMBAI
         */
        get: function () {
            return EvmChain.create(80001);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "BSC", {
        /**
         * Returns BSC chain
         *
         * @example EvmChain.BSC
         */
        get: function () {
            return EvmChain.create(56);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "BSC_TESTNET", {
        /**
         * Returns BSC_TESTNET chain
         *
         * @example EvmChain.BSC_TESTNET
         */
        get: function () {
            return EvmChain.create(97);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "AVALANCHE", {
        /**
         * Returns AVALANCHE chain
         *
         * @example EvmChain.AVALANCHE
         */
        get: function () {
            return EvmChain.create(43114);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "FUJI", {
        /**
         * Returns FUJI chain
         *
         * @example EvmChain.FUJI
         */
        get: function () {
            return EvmChain.create(43113);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "FANTOM", {
        /**
         * Returns FANTOM chain
         *
         * @example EvmChain.FANTOM
         */
        get: function () {
            return EvmChain.create(250);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "CRONOS", {
        /**
         * Returns CRONOS chain
         *
         * @example EvmChain.CRONOS
         */
        get: function () {
            return EvmChain.create(25);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain, "CRONOS_TESTNET", {
        /**
         * Returns CRONOS_TESTNET chain
         *
         * @example EvmChain.CRONOS_TESTNET
         */
        get: function () {
            return EvmChain.create(338);
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Create a new instance of EvmChain from any valid address input.
     *
     * @example
     * ```ts
     * const chain = EvmChain.create(1)
     * const chain = EvmChain.create("0x3")
     * ```
     */
    EvmChain.create = function (chain, core) {
        if (chain instanceof EvmChain) {
            return chain;
        }
        var c = core || core_1.MoralisCoreProvider.getDefault();
        return new EvmChain(chain, c.config);
    };
    // Getter to return _chainlistData and throws an error if it is not defined
    EvmChain.prototype._getChainlistData = function () {
        if (!this._chainlistData) {
            return null;
        }
        return this._chainlistData;
    };
    /**
     * Compares if 2 chains are equal, based on the chainId
     *
     * @param chainA - The first chain to compare
     * @param chainB - The second chain to compare
     *
     * @returns true if the chains are equal, false otherwise
     * @example
     * ```ts
     * EvmChain.equals("1", "0x1")
     * ```
     */
    EvmChain.equals = function (chainA, chainB) {
        return EvmChain.create(chainA)._value === EvmChain.create(chainB)._value;
    };
    /**
     * Compares if the current chain is equal to the provided chain, based on the chainId
     * @param chain - The chain to compare to
     * @returns true if the chains are equal, false otherwise
     * @example
     * ```ts
     * chain.equals(EvmChain.ETHEREUM)
     * ```
     */
    EvmChain.prototype.equals = function (chain) {
        return EvmChain.equals(this, chain);
    };
    /**
     * Formats the chain to the given output; in decimal value or as hex-string.
     * The default formatting can be set in MoralisConfig
     * @param _formatStyle - The output format to use
     * @example chain.format() // 1
     * @example chain.format('hex') // "0x1"
     * @example chain.format('decimal') // 1
     *
     * @returns The formatted chain
     */
    EvmChain.prototype.format = function (_formatStyle) {
        var formatStyle = _formatStyle !== null && _formatStyle !== void 0 ? _formatStyle : this.config.get(EvmUtilsConfig_1.EvmUtilsConfig.formatEvmChainId);
        if (formatStyle === 'decimal') {
            return this.decimal;
        }
        if (formatStyle === 'hex') {
            return this.hex;
        }
        return (0, core_1.assertUnreachable)(formatStyle);
    };
    /**
     * Displays the chain hex-string representation of the chain and also the chain name if not null
     *
     * @example chain.display() // "Ethereum (0x1)" | "0x1"
     */
    EvmChain.prototype.display = function () {
        return this.name ? "".concat(this.name, " (").concat(this.hex, ")") : this.hex;
    };
    /**
     * This function returns the explorer url of a block, transaction, account or token.
     *
     * @param value - An object containing the `block`, `transaction`, `account` or `erc20` to get the explorer url for.
     *
     * @example chain.getExplorerUrl({ block: 'block_here' }) // "https://etherscan.io/block/block_here"
     * @example chain.getExplorerUrl({ transaction: 'some_transaction' }) // "https://etherscan.io/tx/some_transaction"
     * @example chain.getExplorerUrl({ account: 'accoun_here' }) // "https://etherscan.io/address/accoun_here"
     * @example chain.getExplorerUrl({ erc20: 'token_here' }) // "https://etherscan.io/token/token_here"
     */
    EvmChain.prototype.getExplorerPath = function (value) {
        var explorer = this.explorer;
        if (!explorer || explorer.standard !== 'EIP3091') {
            return null;
        }
        var url = explorer.url;
        // See https://eips.ethereum.org/EIPS/eip-3091 for paths
        if ('block' in value) {
            return "".concat(url, "/block/").concat(value.block);
        }
        if ('transaction' in value) {
            return "".concat(url, "/tx/").concat(value.transaction);
        }
        if ('account' in value) {
            return "".concat(url, "/address/").concat(value.account);
        }
        if ('erc20' in value) {
            return "".concat(url, "/token/").concat(value.erc20);
        }
        return null;
    };
    Object.defineProperty(EvmChain.prototype, "decimal", {
        /**
         * Returns the decimal representation of the chain
         * @example chain.decimal // 1
         */
        get: function () {
            return parseInt(this._value, 16);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain.prototype, "hex", {
        /**
         * Returns the hex-string representation of the chain
         * @example chain.hex // "0x1"
         */
        get: function () {
            return this._value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain.prototype, "apiHex", {
        /**
         * Validate and cast to api compatible hex
         *
         * @example chain.apiHex // "0x1"
         */
        get: function () {
            return this._value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain.prototype, "apiId", {
        /**
         * Validate and cast to api compatible id
         *
         * @example chain.apiId // 1
         */
        get: function () {
            return this._value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain.prototype, "name", {
        /**
         * Returns the name of the chain
         * @example chain.name // "Ethereum"
         */
        get: function () {
            var _a;
            return (_a = this._getChainlistData()) === null || _a === void 0 ? void 0 : _a.name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain.prototype, "currency", {
        /**
         * Returns the currency of the chain
         * @returns The cuurrency of the chain or undefined if not found
         *
         * @example chain.currency // EvmNativeCurrency
         */
        get: function () {
            var _a;
            return (_a = this._getChainlistData()) === null || _a === void 0 ? void 0 : _a.nativeCurrency;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain.prototype, "rpcUrls", {
        /**
         * Returns the rpc Urls of the chain
         *
         * @example chain.rpcUrls // ["https://mainnet.infura.io/v3/<infura-key>"]
         */
        get: function () {
            var _a;
            return (_a = this._getChainlistData()) === null || _a === void 0 ? void 0 : _a.rpc;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmChain.prototype, "explorer", {
        /**
         * Returns the explorer Urls of the chain
         *
         * @example chain.explorerUrls // ["https://etherscan.io/"]
         */
        get: function () {
            var _a;
            var explorers = (_a = this._getChainlistData()) === null || _a === void 0 ? void 0 : _a.explorers;
            if (!explorers || explorers.length === 0) {
                return null;
            }
            return explorers[0];
        },
        enumerable: false,
        configurable: true
    });
    return EvmChain;
}());
exports.EvmChain = EvmChain;
//# sourceMappingURL=EvmChain.js.map

/***/ }),

/***/ 3607:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmChainParser = void 0;
var core_1 = __webpack_require__(4243);
var INVALID_VALUES = ['0x', '0x0', '0', 0];
var EvmChainParser = /** @class */ (function () {
    function EvmChainParser() {
    }
    EvmChainParser.parse = function (chain) {
        if (INVALID_VALUES.includes(chain)) {
            throw new core_1.MoralisCoreError({
                code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                message: "Invalid provided chain, value must be a positive number, or a hex-string starting with '0x'",
            });
        }
        if (typeof chain === 'string') {
            if (chain.startsWith('0x')) {
                return chain;
            }
            try {
                var parsed = parseInt(chain, 10);
                if (Number.isNaN(parsed)) {
                    throw new Error('Cannot parse the provided string value to a valid chain number');
                }
                return "0x".concat(parsed.toString(16));
            }
            catch (error) {
                throw new core_1.MoralisCoreError({
                    code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                    message: "Invalid provided chain, value must be a positive number, or a hex-string starting with '0x'",
                });
            }
        }
        if (chain <= 0) {
            throw new core_1.MoralisCoreError({
                code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                message: "Invalid provided chain, value must be a positive number, or a hex-string starting with '0x'",
            });
        }
        return "0x".concat(chain.toString(16));
    };
    return EvmChainParser;
}());
exports.EvmChainParser = EvmChainParser;
//# sourceMappingURL=EvmChainParser.js.map

/***/ }),

/***/ 7436:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=EvmChainish.js.map

/***/ }),

/***/ 43:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(83), exports);
__exportStar(__webpack_require__(7436), exports);
__exportStar(__webpack_require__(3607), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 5600:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmEvent = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
var EvmNative_1 = __webpack_require__(3912);
/**
 * The EvmEvent is a representation of an event.
 *
 * Use this class any time you work with an event.
 *
 * @category DataType
 */
var EvmEvent = /** @class */ (function () {
    function EvmEvent(_data) {
        this._data = _data;
    }
    /**
     * Create a new instance of EvmEvent from any valid event input
     * @param data - the EvmEventish type
     * @example
     * ```
     * const event = EvmEventish.create(data);
     *```
     */
    EvmEvent.create = function (data, core) {
        if (data instanceof EvmEvent) {
            return data;
        }
        var finalCore = core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault();
        return new EvmEvent(EvmEvent.parse(data, finalCore));
    };
    /**
     * Check the equality between two Evm events. It checks if the chain, block number, address and data are equal.
     * @param dataA - The first event
     * @param dataB - The second event
     * @example
     * ```ts
     * EvmEvent.equals(dataA, dataB)
     * ```
     * @returns true if the events are equal, false otherwise
     */
    EvmEvent.equals = function (dataA, dataB) {
        var eventA = EvmEvent.create(dataA);
        var eventB = EvmEvent.create(dataB);
        if (!eventA._data.chain.equals(eventB._data.chain)) {
            return false;
        }
        if (!eventA._data.blockNumber.equals(eventB._data.blockNumber)) {
            return false;
        }
        if (!eventA._data.address.equals(eventB._data.address)) {
            return false;
        }
        if (eventA._data.data !== eventB._data.data) {
            return false;
        }
        return true;
    };
    /**
     * Checks the equality of the current event instance with another evm event
     * @param data - the event to compare with
     * @example
     * ```ts
     * event.equals(data)
     * ```
     * @returns true if the events are equal, false otherwise
     */
    EvmEvent.prototype.equals = function (data) {
        return EvmEvent.equals(this, data);
    };
    /**
     * @returns a JSON represention of the event.
     * @example
     * ```
     * event.toJSON()
     * ```
     */
    EvmEvent.prototype.toJSON = function () {
        var _a, _b, _c;
        var data = this._data;
        return __assign(__assign({}, data), { chain: data.chain.format(), address: data.address.format(), blockNumber: data.blockNumber.toString(), data: {
                from: (_a = data.data.from) === null || _a === void 0 ? void 0 : _a.format(),
                to: (_b = data.data.to) === null || _b === void 0 ? void 0 : _b.format(),
                value: (_c = data.data.value) === null || _c === void 0 ? void 0 : _c.format(),
            } });
    };
    /**
     * @returns a JSON represention of the event.
     * @example event.format()
     */
    EvmEvent.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmEvent.prototype, "result", {
        /**
         * @returns all the data without casting it to JSON.
         * @example event.result
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmEvent.prototype, "chain", {
        /**
         * @returns the event chain
         * @example event.chain // EvmChain
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmEvent.prototype, "address", {
        /**
         * @returns the event address
         * @example event.address // EvmAddress
         */
        get: function () {
            return this._data.address;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmEvent.prototype, "blockNumber", {
        /**
         * @returns the event block number
         * @example event.blockNumber // BigNumber
         */
        get: function () {
            return this._data.blockNumber;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmEvent.prototype, "blockTimestamp", {
        /**
         * @returns the event block timestamp
         * @example event.blockTimestamp // Date
         */
        get: function () {
            return this._data.blockTimestamp;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmEvent.prototype, "data", {
        /**
         * @returns the event data with from address, to address and value
         * @example event.data
         */
        get: function () {
            return this._data.data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmEvent.prototype, "transactionHash", {
        /**
         * @returns the event block trannsaciton hash
         * @example event.transactionHash // "0xc9f62f4f6ab505a96c1a84ec2899c6bfd86245ef1effaa689fc997798be763d5"
         */
        get: function () {
            return this._data.transactionHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmEvent.prototype, "blockHash", {
        /**
         * @returns the event block hash
         * @example event.blockHash // "0xc9f62f4f6ab505a96c1a84ec2899c6bfd86245ef1effaa689fc997798be763d5"
         */
        get: function () {
            return this._data.blockHash;
        },
        enumerable: false,
        configurable: true
    });
    EvmEvent.parse = function (data, core) { return (__assign(__assign({}, data), { chain: EvmChain_1.EvmChain.create(data.chain, core), address: EvmAddress_1.EvmAddress.create(data.address, core), blockNumber: core_1.BigNumber.create(data.blockNumber), blockTimestamp: (0, core_1.dateInputToDate)(data.blockTimestamp), data: {
            from: (0, core_1.maybe)(data.data.from, function (from) { return EvmAddress_1.EvmAddress.create(from, core); }),
            to: (0, core_1.maybe)(data.data.to, function (to) { return EvmAddress_1.EvmAddress.create(to, core); }),
            value: (0, core_1.maybe)(data.data.value, EvmNative_1.EvmNative.create),
        } })); };
    return EvmEvent;
}());
exports.EvmEvent = EvmEvent;
//# sourceMappingURL=EvmEvent.js.map

/***/ }),

/***/ 5177:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(5600), exports);
__exportStar(__webpack_require__(1177), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 1177:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 6314:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmNative = void 0;
var core_1 = __webpack_require__(4243);
var unitToDecimals = {
    ether: 18,
    finney: 15,
    szabo: 12,
    gwei: 9,
    mwei: 6,
    kwei: 3,
    wei: 0,
};
/**
 * The EvmNative class is a MoralisData that references to a the value of a native currency (like ETH, BNB etc.)
 *
 * @category DataType
 */
var EvmNative = /** @class */ (function () {
    function EvmNative(native, unit) {
        if (unit === void 0) { unit = 'ether'; }
        this.rawValue = EvmNative.parse(native, unit);
    }
    Object.defineProperty(EvmNative, "ONE_ETH", {
        /**
         * Returns value of one ether.
         *
         * @example EvmNative.ONE_ETH
         */
        get: function () {
            return EvmNative.create(1, 'ether');
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNative, "ONE_GWEI", {
        /**
         * Returns value of one gwei.
         *
         * @example EvmNative.ONE_GWEI
         */
        get: function () {
            return EvmNative.create(1, 'gwei');
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNative, "ONE_WEI", {
        /**
         * Returns value of one wei.
         *
         * @example EvmNative.ONE_WEI
         */
        get: function () {
            return EvmNative.create(1, 'wei');
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Create a new instance of EvmNative from any valid {@link EvmNativeish} value.
     * @param native - the value to create the EvmNative from
     * @param unit - the unit of the value (optional), defaults to `ether`
     * @returns a new instance of EvmNative
     * @example
     * ```ts
     * const native = EvmNative.create(2, 'gwei');
     * const native = EvmNative.create(2);
     * const native = EvmNative.create(2, 'wei');
     *```
     */
    EvmNative.create = function (native, unit) {
        if (native instanceof EvmNative) {
            return native;
        }
        return new EvmNative(native, unit);
    };
    EvmNative.parse = function (native, unit) {
        var decimals;
        if (typeof unit === 'number') {
            decimals = unit;
        }
        else {
            if (unitToDecimals[unit] == null) {
                throw new core_1.MoralisCoreError({
                    code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                    message: 'Unit should be a decimal number or valid EvmNativeUnit string',
                });
            }
            decimals = unitToDecimals[unit];
        }
        return core_1.BigNumber.fromDecimal(native.toString(), decimals);
    };
    /**
     * Compares two EvmNative values.
     * @param valueA - the first value to compare
     * @param valueB - the second value to compare
     * @returns true if the values are equal
     * @example
     * ```ts
     * EvmNative.equals(EvmNative.create(1, 'ether'), EvmNative.create(1, 'ether')); // true
     * ```
     */
    EvmNative.equals = function (valueA, valueB) {
        var evmNativeA = EvmNative.create(valueA);
        var evmNativeB = EvmNative.create(valueB);
        return evmNativeA.rawValue.equals(evmNativeB.rawValue);
    };
    /**
     * Compares EvmNative with current instance.
     * @param value - the value to compare with
     * @returns true if the values are equal
     * @example
     * ```ts
     * const native = EvmNative.create(1, 'gwei');
     * native.equals(EvmNative.create(1, 'ether')); // false
     * ```
     */
    EvmNative.prototype.equals = function (value) {
        return EvmNative.equals(this, value);
    };
    /**
     * Converts the EvmNative to a string.
     * @returns the value of the EvmNative as a string
     * @example `native.toString()`
     */
    EvmNative.prototype.toString = function () {
        return this.wei;
    };
    /**
     * Converts the EvmNative to a string.
     * @returns the value of the EvmNative as a string
     * @example `native.format()`
     */
    EvmNative.prototype.format = function () {
        return this.toString();
    };
    Object.defineProperty(EvmNative.prototype, "value", {
        /**
         * @returns the value of the EvmNative as a BigNumber
         * @example `native.value`
         */
        get: function () {
            return this.rawValue;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNative.prototype, "wei", {
        /**
         * Converts the EvmNative to a string representation of the value in wei.
         * @returns the value of the EvmNative as a string
         * @example `native.wei`
         */
        get: function () {
            return this.value.toString();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNative.prototype, "gwei", {
        /**
         * Converts the EvmNative to a string representation of the value in gwei.
         * @returns the value of the EvmNative as a string
         * @example `native.gwei`
         */
        get: function () {
            return this.rawValue.toDecimal(unitToDecimals['gwei']);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNative.prototype, "ether", {
        /**
         * Converts the EvmNative to a string representation of the value in ether.
         * @returns the value of the EvmNative as a string
         * @example `native.ether`
         */
        get: function () {
            return this.rawValue.toDecimal(unitToDecimals['ether']);
        },
        enumerable: false,
        configurable: true
    });
    return EvmNative;
}());
exports.EvmNative = EvmNative;
//# sourceMappingURL=EvmNative.js.map

/***/ }),

/***/ 3912:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(6314), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7739:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmNft = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
/**
 * The EvmNft class is a MoralisData that references to a the NFT of the type; Erc721 or Erc1155
 *
 * @category DataType
 */
var EvmNft = /** @class */ (function () {
    function EvmNft(data, core) {
        this._data = EvmNft.parse(data, core);
    }
    /**
     * Create a new instance of EvmNft from any valid address input
     *
     * @param data - the EvmNftish type
     * @param core - the MoralisCore instance
     * @example
     * ```ts
     * const nft = EvmNft.create(data);
     * ```
     * @returns an instance of EvmNft
     */
    EvmNft.create = function (data, core) {
        if (data instanceof EvmNft) {
            return data;
        }
        var finalCore = core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault();
        return new EvmNft(data, finalCore);
    };
    // TODO: refactor to reduce complexity
    /**
     * Compares two EvmNftish data. verifies that the chain, tokenAddress and owner of values are equal.
     * @param valueA - the first EvmNftish data to compare
     * @param valueB - the second EvmNftish data to compare
     * @returns true if the values are equal, false otherwise
     * @example
     * ```ts
     *  EvmNft.equals(valueA, valueB);
     * ```
     */
    // eslint-disable-next-line complexity
    EvmNft.equals = function (valueA, valueB) {
        var nftA = EvmNft.create(valueA);
        var nftB = EvmNft.create(valueB);
        if (!nftA._data.chain.equals(nftB._data.chain)) {
            return false;
        }
        if (!nftA._data.tokenAddress.equals(nftB._data.tokenAddress)) {
            return false;
        }
        // Owners are different between tokens
        if (nftA._data.ownerOf && nftB._data.ownerOf && !nftA._data.ownerOf.equals(nftB._data.ownerOf)) {
            return false;
        }
        // Owner is defined in only one token
        if ((nftA._data.ownerOf && !nftB._data.ownerOf) || (!nftA._data.ownerOf && nftB._data.ownerOf)) {
            return false;
        }
        return true;
    };
    /**
     * Compares an EvmNftish data to this EvmNft instance.
     * @param value - the value to compare
     * @returns true if the value is equal to the current instance, false otherwise
     * @example
     * ```ts
     * nft.equals(value);
     * ```
     */
    EvmNft.prototype.equals = function (value) {
        return EvmNft.equals(this, value);
    };
    /**
     * Converts the EvmNft instance to a JSON object.
     * @returns JSON object of the EvmNft instance
     * @example `nft.toJSON()`
     */
    EvmNft.prototype.toJSON = function () {
        var _b, _c, _d;
        var data = this._data;
        return __assign(__assign({}, data), { tokenAddress: data.tokenAddress.format(), chain: data.chain.format(), ownerOf: (_b = data.ownerOf) === null || _b === void 0 ? void 0 : _b.format(), blockNumberMinted: (_c = data.blockNumberMinted) === null || _c === void 0 ? void 0 : _c.toString(), blockNumber: (_d = data.blockNumber) === null || _d === void 0 ? void 0 : _d.toString() });
    };
    /**
     * Converts the EvmNft instance to a JSON object.
     * @returns JSON object of the EvmNft instance
     * @example `nft.format()`
     */
    EvmNft.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmNft.prototype, "result", {
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "chain", {
        /**
         * @returns the NFT chain
         * @example
         * ```
         * nft.chain // EvmChain
         * ```
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "contractType", {
        /**
         * @returns the NFT contract type
         * @example
         * ```
         * nft.contractType // "ERC721" | "ERC1155"
         * ```
         */
        get: function () {
            return this._data.contractType;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "tokenAddress", {
        /**
         * @returns the NFT token address
         * @example
         * ```
         * nft.tokenAddress // EvmAddress
         * ```
         */
        get: function () {
            return this._data.tokenAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "metadata", {
        /**
         * @returns the NFT metadata
         * @example
         * ```ts
         * nft.metadata
         * // {
         * // name: 'Pancake',
         * // description: 'The dessert series 1',
         * // image: 'ipfs://QmNQFXCZ6LGzvpMW9Q5PWbCrEnLknQrPwr2r8pbQAgzQ9A/4863BD6B-6C92-4B96-BF80-8020B2F7C3A5.jpeg',
         * // }
         * ```
         */
        get: function () {
            return this._data.metadata;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "tokenUri", {
        /**
         * @returns the NFT token URI
         * @example
         * ```
         * nft.tokenUri // "https://gateway.moralisipfs.com/ipfs/QmajSqgxY3cWBgBeRm38vasJAcTit1kp5EwqVHxszJYgUC/728.json"
         * ```
         */
        get: function () {
            return this._data.tokenUri;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "tokenHash", {
        /**
         * @returns the NFT token hash
         * @example
         * ```
         * nft.tokenHash // "QmajSqgxY3cWBgBeRm38vasJAcTit1kp5EwqVHxszJYgUC"
         * ```
         */
        get: function () {
            return this._data.tokenHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "name", {
        /**
         * @returns the NFT name
         * @example
         * ```
         * nft.name // "Tether USD"
         * ```
         */
        get: function () {
            return this._data.name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "symbol", {
        /**
         * @returns the NFT symbol
         * @example
         * ```
         * nft.symbol // "USDT"
         * ```
         */
        get: function () {
            return this._data.symbol;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "ownerOf", {
        /**
         * @returns the NFT owner of address
         * @example
         * ```
         * nft.ownerOf // EvmAddress
         * ```
         */
        get: function () {
            return this._data.ownerOf;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "blockNumberMinted", {
        /**
         * @returns the NFT block number minted from
         * @example
         * ```
         * nft.blockNumberMinted // BigNumber
         * ```
         */
        get: function () {
            return this._data.blockNumberMinted;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "blockNumber", {
        /**
         * @returns the NFT block number
         * @example
         * ```
         * nft.blockNumber // BigNumber
         * ```
         */
        get: function () {
            return this._data.blockNumber;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "lastMetadataSync", {
        /**
         * @returns the NFT latest metadata sync date
         * @example
         * ```
         * nft.latestMetadataSync // Date
         * ```
         */
        get: function () {
            return this._data.lastMetadataSync;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "lastTokenUriSync", {
        /**
         * @returns the NFT latest token URI sync date
         * @example
         * ```
         * nft.latestTokenUriSync // Date
         * ```
         */
        get: function () {
            return this._data.lastTokenUriSync;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNft.prototype, "amount", {
        /**
         * @returns the NFT amount
         * @example
         * ```
         * nft.amount // 2
         * ```
         */
        get: function () {
            return this._data.amount;
        },
        enumerable: false,
        configurable: true
    });
    var _a;
    _a = EvmNft;
    EvmNft.parse = function (data, core) { return (__assign(__assign({}, data), { chain: EvmChain_1.EvmChain.create(data.chain, core), contractType: (0, core_1.maybe)(data.contractType), tokenAddress: EvmAddress_1.EvmAddress.create(data.tokenAddress, core), metadata: (0, core_1.maybe)(data.metadata, _a.validateMetadata), tokenUri: (0, core_1.maybe)(data.tokenUri), tokenHash: (0, core_1.maybe)(data.tokenHash), name: (0, core_1.maybe)(data.name), symbol: (0, core_1.maybe)(data.symbol), ownerOf: (0, core_1.maybe)(data.ownerOf, function (ownerOf) { return EvmAddress_1.EvmAddress.create(ownerOf, core); }), blockNumberMinted: (0, core_1.maybe)(data.blockNumberMinted, core_1.BigNumber.create), blockNumber: (0, core_1.maybe)(data.blockNumber, core_1.BigNumber.create), lastMetadataSync: (0, core_1.maybe)(data.lastMetadataSync, core_1.dateInputToDate), lastTokenUriSync: (0, core_1.maybe)(data.lastTokenUriSync, core_1.dateInputToDate), amount: (0, core_1.maybe)(data.amount, function (value) { return +value; }) })); };
    /**
     * This function confirms that the NFT metadata is a valid JSON string.
     *
     * @param value - the new value for the NFT metadata
     * @returns the parsed value of the JSON string
     * @throws {MoralisCoreError} if the value is not a valid JSON string
     */
    EvmNft.validateMetadata = function (value) {
        try {
            return JSON.parse(value);
        }
        catch (error) {
            throw new core_1.MoralisCoreError({
                code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                message: 'Invalid metadata provided, cannot parse the value to JSON',
            });
        }
    };
    return EvmNft;
}());
exports.EvmNft = EvmNft;
//# sourceMappingURL=EvmNft.js.map

/***/ }),

/***/ 8703:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(7739), exports);
__exportStar(__webpack_require__(7600), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7600:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 6090:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmNftCollection = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
/**
 * The EvmNftCollection is a representation of an nft collection.
 *
 * @category DataType
 */
var EvmNftCollection = /** @class */ (function () {
    function EvmNftCollection(data, core) {
        this._data = EvmNftCollection.parse(data, core);
    }
    /**
     * Create a new instance of EvmNftCollection from any valid transaction input
     * @param data - the EvmNftCollectionish type
     * @example const collection = EvmTransaction.create(data);
     */
    EvmNftCollection.create = function (data, core) {
        if (data instanceof EvmNftCollection) {
            return data;
        }
        var finalCore = core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault();
        return new EvmNftCollection(data, finalCore);
    };
    /**
     * Check the equality between two Evm collections. It compares their hashes and collections.
     * @param dataA - The first collection to compare
     * @param dataB - The second collection to compare
     * @example EvmNftCollection.equals(dataA, dataB)
     */
    EvmNftCollection.equals = function (dataA, dataB) {
        var collectionA = EvmNftCollection.create(dataA);
        var collectionB = EvmNftCollection.create(dataB);
        if (!collectionA.chain.equals(collectionB.chain)) {
            return false;
        }
        if (!collectionA.tokenAddress.equals(collectionB.tokenAddress)) {
            return false;
        }
        return true;
    };
    /**
     * Checks the equality of the current collection with another evm collection
     * @param data - the collection to compare with
     * @example
     * ```ts
     * collection.equals(data)
     * ```
     */
    EvmNftCollection.prototype.equals = function (data) {
        return EvmNftCollection.equals(this, data);
    };
    /**
     * @returns a JSON represention of the collection.
     * @example
     * ```
     * collection.toJSON()
     * ```
     */
    EvmNftCollection.prototype.toJSON = function () {
        var data = this._data;
        return __assign(__assign({}, data), { chain: data.chain.format(), tokenAddress: data.tokenAddress.format() });
    };
    /**
     * @returns a JSON represention of the collection.
     * @example
     * ```
     * collection.format()
     * ```
     */
    EvmNftCollection.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmNftCollection.prototype, "result", {
        /**
         * @returns all the data without casting it to JSON.
         * @example collection.result
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftCollection.prototype, "chain", {
        /**
         * @returns the chain where the collection is deployed.
         * @example collection.chain // EvmChain
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftCollection.prototype, "tokenAddress", {
        /**
         * @returns the token address of collection.
         * @example collection.tokenAddress // EvmAddress
         */
        get: function () {
            return this._data.tokenAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftCollection.prototype, "contractType", {
        /**
         * @returns the token type of collection.
         * @example collection.tokenAddress // 'ERC721'
         */
        get: function () {
            return this._data.contractType;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftCollection.prototype, "name", {
        /**
         * @returns the token name of collection.
         * @example collection.tokenAddress // 'Test NFT'
         */
        get: function () {
            return this._data.name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftCollection.prototype, "symbol", {
        /**
         * @returns the token symbol of collection.
         * @example collection.symbol // 'TEST'
         */
        get: function () {
            return this._data.symbol;
        },
        enumerable: false,
        configurable: true
    });
    EvmNftCollection.parse = function (data, core) { return (__assign(__assign({}, data), { tokenAddress: EvmAddress_1.EvmAddress.create(data.tokenAddress, core), chain: EvmChain_1.EvmChain.create(data.chain, core), contractType: (0, core_1.maybe)(data.contractType) })); };
    return EvmNftCollection;
}());
exports.EvmNftCollection = EvmNftCollection;
//# sourceMappingURL=EvmNftCollection.js.map

/***/ }),

/***/ 4589:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(6090), exports);
__exportStar(__webpack_require__(9285), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9285:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 8318:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmNftMetadata = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
/**
 * The EvmNftMetadata contains metadata of an NFT.
 *
 * @category DataType
 */
var EvmNftMetadata = /** @class */ (function () {
    function EvmNftMetadata(data) {
        this._data = EvmNftMetadata.parse(data);
    }
    /**
     *  Create a new instance of EvmNftMetadata from any valid EvmNftMetadata input
     *
     * @param data - the EvmNftMetadataish type
     * @example
     * ```ts
     * const token = EvmNftMetadataish.create(value);
     * ```
     */
    EvmNftMetadata.create = function (data) {
        if (data instanceof EvmNftMetadata) {
            return data;
        }
        return new EvmNftMetadata(data);
    };
    /**
     * Compares two EvmNftMetadata instances. This checks if the chain and tokenAddress of both meatdatas are equal.
     *
     * @param dataA - the first EvmNftMetadataish to compare
     * @param dataB - the second EvmNftMetadataish to compare
     * @returns true if the two EvmNftMetadataData are equal
     * @example
     * ```ts
     * EvmNftMetadata.equals(dataA, dataB);
     * ```
     */
    EvmNftMetadata.equals = function (dataA, dataB) {
        var metadataA = EvmNftMetadata.create(dataA);
        var metadataB = EvmNftMetadata.create(dataB);
        if (!metadataA._data.chain.equals(metadataB._data.chain)) {
            return false;
        }
        if (!metadataA._data.tokenAddress.equals(metadataB._data.tokenAddress)) {
            return false;
        }
        return true;
    };
    /**
     * Compares EvmNftMetadata instance to current instance
     *
     * @param data - the EvmNftMetadataish to compare
     * @returns true if the EvmNftMetadataish is equals given metadata
     * @example
     * ```ts
     * metadata.equals(data);
     * ```
     */
    EvmNftMetadata.prototype.equals = function (data) {
        return EvmNftMetadata.equals(this, data);
    };
    /**
     * @returns the data as JSON.
     * @example metadata.toJSON();
     */
    EvmNftMetadata.prototype.toJSON = function () {
        var data = this._data;
        return __assign(__assign({}, data), { chain: data.chain.format(), tokenAddress: data.tokenAddress.format() });
    };
    /**
     * @returns the data as JSON.
     * @example metadata.format();
     */
    EvmNftMetadata.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmNftMetadata.prototype, "result", {
        /**
         * @returns all the data without casting it to JSON.
         * @example metadata.result;
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftMetadata.prototype, "name", {
        /**
         * @returns the name in the metadata.
         * @example metadata.name; // "Baby Ape Mutant Club"
         */
        get: function () {
            return this._data.name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftMetadata.prototype, "symbol", {
        /**
         * @returns the symbol in the metadata.
         * @example metadata.symbol; // "BAMC"
         */
        get: function () {
            return this._data.symbol;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftMetadata.prototype, "contractType", {
        /**
         * @returns the contract type of the NFT.
         * @example metadata.contractType; // "ERC721"
         */
        get: function () {
            return this._data.contractType;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftMetadata.prototype, "chain", {
        /**
         * @returns the chain in the metadata.
         * @example metadata.chain; // EvmChain
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftMetadata.prototype, "tokenAddress", {
        /**
         * @returns the token address in the metadata.
         * @example metadata.tokenAddress; // EvmAddress
         */
        get: function () {
            return this._data.tokenAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftMetadata.prototype, "syncedAt", {
        /**
         * @returns the date the metadata was synced.
         * @example metadata.syncedAt; // Date
         */
        get: function () {
            return this._data.syncedAt;
        },
        enumerable: false,
        configurable: true
    });
    EvmNftMetadata.parse = function (data) { return (__assign(__assign({}, data), { chain: EvmChain_1.EvmChain.create(data.chain), tokenAddress: EvmAddress_1.EvmAddress.create(data.tokenAddress), syncedAt: (0, core_1.maybe)(data.syncedAt, core_1.dateInputToDate) })); };
    return EvmNftMetadata;
}());
exports.EvmNftMetadata = EvmNftMetadata;
//# sourceMappingURL=EvmNftMetadata.js.map

/***/ }),

/***/ 7584:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(8318), exports);
__exportStar(__webpack_require__(6389), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6389:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 4064:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmNftTrade = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
var EvmNative_1 = __webpack_require__(3912);
/**
 * The EvmNftTrade is a representation of a published trade.
 *
 * Use this class any time you work with a transaction.
 *
 * @category DataType
 */
var EvmNftTrade = /** @class */ (function () {
    function EvmNftTrade(data) {
        this._data = EvmNftTrade.parse(data);
    }
    /**
     * Create a new instance of EvmNftTrade from any valid transaction input
     * @param data - the EvmNftTradeish type
     * @example
     * ```
     * const trade = EvmNftTrade.create(data);
     *```
     */
    EvmNftTrade.create = function (data) {
        if (data instanceof EvmNftTrade) {
            return data;
        }
        return new EvmNftTrade(data);
    };
    /**
     * Check the equality between two Evm trades. It compares the `chain`, `blockNumber`, `transactionIndex` and `transactionHash`
     * @param dataA - The first trade
     * @param dataB - The second trade
     * @example
     * ```ts
     * EvmNftTrade.equals(dataA, dataB)
     * ```
     * @returns true if the trades are equal, false otherwise
     */
    EvmNftTrade.equals = function (dataA, dataB) {
        var transactionA = EvmNftTrade.create(dataA);
        var transactionB = EvmNftTrade.create(dataB);
        if (!transactionA._data.chain.equals(transactionB._data.chain)) {
            return false;
        }
        if (!transactionA._data.blockNumber.equals(transactionB._data.blockNumber)) {
            return false;
        }
        if (transactionA._data.transactionHash !== transactionB._data.transactionHash) {
            return false;
        }
        if (transactionA._data.transactionIndex !== transactionB._data.transactionIndex) {
            return false;
        }
        return true;
    };
    /**
     * Checks the equality of the current trade instance with another evm trade
     * @param data - the trade to compare with
     * @example
     * ```ts
     * trade.equals(data)
     * ```
     * @returns true if the trades are equal, false otherwise
     */
    EvmNftTrade.prototype.equals = function (data) {
        return EvmNftTrade.equals(this, data);
    };
    /**
     * @returns a JSON represention of the trade.
     * @example
     * ```
     * trade.toJSON()
     * ```
     */
    EvmNftTrade.prototype.toJSON = function () {
        var data = this._data;
        return __assign(__assign({}, data), { chain: data.chain.format(), sellerAddress: data.sellerAddress.format(), buyerAddress: data.buyerAddress.format(), marketplaceAddress: data.marketplaceAddress.format(), tokenAddress: data.tokenAddress.format(), priceTokenAddress: data.priceTokenAddress ? data.priceTokenAddress.format() : undefined, blockNumber: data.blockNumber.toString(), price: data.price.toString(), blockTimestamp: data.blockTimestamp.toString() });
    };
    /**
     * @returns a JSON represention of the trade.
     * @example
     * ```
     * trade.format()
     * ```
     */
    EvmNftTrade.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmNftTrade.prototype, "result", {
        /**
         * @returns all the data without casting it to JSON.
         * @example trade.result
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "sellerAddress", {
        /**
         * @returns the trade seller address
         * @example trade.sellerAddress // EvmAddress
         */
        get: function () {
            return this._data.sellerAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "buyerAddress", {
        /**
         * @returns the trade buyer address
         * @example trade.buyerAddress // EvmAddress
         */
        get: function () {
            return this._data.buyerAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "marketplaceAddress", {
        /**
         * @returns the trade marketplace address
         * @example trade.marketplaceAddress // EvmAddress
         */
        get: function () {
            return this._data.marketplaceAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "tokenAddress", {
        /**
         * @returns the trade token address
         * @example trade.tokenAddress // EvmAddress
         */
        get: function () {
            return this._data.tokenAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "priceTokenAddress", {
        /**
         * @returns the trade price token address
         * @example trade.priceTokenAddress // EvmAddress
         */
        get: function () {
            return this._data.priceTokenAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "price", {
        /**
         * @returns the trade price
         * @example trade.price // EvmNative
         */
        get: function () {
            return this._data.price;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "blockNumber", {
        /**
         * @returns the trade block number
         * @example trade.blockNumber // BigNumber
         */
        get: function () {
            return this._data.blockNumber;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "transactionIndex", {
        /**
         * @returns the trade transaction index
         * @example trade.transactionIndex // 164
         */
        get: function () {
            return this._data.transactionIndex;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "transactionHash", {
        /**
         * @returns the trade transaction hash
         * @example trade.transactionHash // "0x4de0bcef1450492bd5c2e7693cf644c40005868d0dcc8a7a50a80ef2efa88d1e"
         */
        get: function () {
            return this._data.transactionHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "chain", {
        /**
         * @returns the trade chain
         * @example trade.chain // EvmChain
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "tokenIds", {
        /**
         * @returns the trade token Ids
         * @example trade.tokenIds // ["16404"]
         */
        get: function () {
            return this._data.tokenIds;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "blockHash", {
        /**
         * @returns the trade block hash
         * @example trade.blockHash // "0x4de0bcef1450492bd5c2e7693cf644c40005868d0dcc8a7a50a80ef2efa88d1e"
         */
        get: function () {
            return this._data.blockHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTrade.prototype, "blockTimestamp", {
        /**
         * @returns the trade block timestamp
         * @example trade.blockTimestamp // Date
         */
        get: function () {
            return this._data.blockTimestamp;
        },
        enumerable: false,
        configurable: true
    });
    EvmNftTrade.parse = function (data) { return (__assign(__assign({}, data), { chain: EvmChain_1.EvmChain.create(data.chain), sellerAddress: EvmAddress_1.EvmAddress.create(data.sellerAddress), buyerAddress: EvmAddress_1.EvmAddress.create(data.buyerAddress), marketplaceAddress: EvmAddress_1.EvmAddress.create(data.marketplaceAddress), tokenAddress: EvmAddress_1.EvmAddress.create(data.tokenAddress), priceTokenAddress: (0, core_1.maybe)(data.priceTokenAddress, EvmAddress_1.EvmAddress.create), blockNumber: core_1.BigNumber.create(data.blockNumber), price: EvmNative_1.EvmNative.create(data.price), transactionIndex: +data.transactionIndex, blockTimestamp: (0, core_1.dateInputToDate)(data.blockTimestamp) })); };
    return EvmNftTrade;
}());
exports.EvmNftTrade = EvmNftTrade;
//# sourceMappingURL=EvmNftTrade.js.map

/***/ }),

/***/ 5291:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(4064), exports);
__exportStar(__webpack_require__(425), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 425:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 6282:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmNftTransfer = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
var EvmNative_1 = __webpack_require__(3912);
/**
 * The EvmNftTransfer is a representation of a completed NFT transfer.
 *
 * @category DataType
 */
var EvmNftTransfer = /** @class */ (function () {
    function EvmNftTransfer(data) {
        this._data = EvmNftTransfer.parse(data);
    }
    /**
     * Create a new instance of EvmNftTransfer from any valid transfer input
     * @param data - the EvmNftTransferish type
     * @example
     * ```
     * const transfer = EvmNftTransfer.create(data);
     *```
     */
    EvmNftTransfer.create = function (data) {
        if (data instanceof EvmNftTransfer) {
            return data;
        }
        return new EvmNftTransfer(data);
    };
    /**
     * Check the equality between two NFT transfers. The compares the chain, blockHash, tokenId and logIndex.
     * @param dataA - The first transfer to compare
     * @param dataB - The second transfer to compare
     * @example EvmNftTransfer.equals(dataA, dataB)
     * @returns true if the transfers are equal, false otherwise
     */
    EvmNftTransfer.equals = function (dataA, dataB) {
        var transferA = EvmNftTransfer.create(dataA);
        var transferB = EvmNftTransfer.create(dataB);
        if (!transferA._data.chain.equals(transferB._data.chain)) {
            return false;
        }
        if (transferA._data.blockHash !== transferB._data.blockHash) {
            return false;
        }
        if (transferA._data.tokenId !== transferB._data.tokenId) {
            return false;
        }
        if (transferA._data.logIndex !== transferB._data.logIndex) {
            return false;
        }
        return true;
    };
    /**
     * Checks the equality of the current transfer instance with another nft transfer
     * @param data - the transfer to compare with
     * @example transaction.equals(data)
     * @returns true if the transfers are equal, false otherwise
     */
    EvmNftTransfer.prototype.equals = function (data) {
        return EvmNftTransfer.equals(this, data);
    };
    /**
     * @returns a JSON represention of the transfer.
     * @example
     * ```
     * transfer.toJSON()
     * ```
     */
    EvmNftTransfer.prototype.toJSON = function () {
        var data = this._data;
        return __assign(__assign({}, data), { chain: data.chain.format(), blockNumber: data.blockNumber.toString(), fromAddress: data.fromAddress ? data.fromAddress.format() : undefined, toAddress: data.toAddress.format(), tokenAddress: data.tokenAddress.format(), value: data.value ? data.value.format() : undefined, operator: data.operator ? data.operator.format() : undefined });
    };
    /**
     * @returns a JSON represention of the transfer.
     * @example
     * ```
     * transfer.format()
     * ```
     */
    EvmNftTransfer.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmNftTransfer.prototype, "result", {
        /**
         * @returns all the data without casting it to JSON.
         * @example transfer.result
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "chain", {
        /**
         * @returns the chain of the transfer.
         * @example transfer.chain // EvmChain
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "blockHash", {
        /**
         * @returns the block hash of the transfer.
         * @example transfer.blockHash // "0x057Ec652A4F150f7FF94f089A38008f49a0DF88e"
         */
        get: function () {
            return this._data.blockHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "blockNumber", {
        /**
         * @returns the block number of the transfer.
         * @example transfer.blockNumber // BigNumber
         */
        get: function () {
            return this._data.blockNumber;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "blockTimestamp", {
        /**
         * @returns the block timestamp of the transfer.
         * @example transfer.blockTimestamp // Date
         */
        get: function () {
            return this._data.blockTimestamp;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "fromAddress", {
        /**
         * @returns the from address of the transfer.
         * @example transfer.fromAddress // EvmAddress
         */
        get: function () {
            return this._data.fromAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "toAddress", {
        /**
         * @returns the to address of the transfer.
         * @example transfer.toAddress // EvmAddress
         */
        get: function () {
            return this._data.toAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "tokenAddress", {
        /**
         * @returns the token address of the transfer.
         * @example transfer.tokenAddress // EvmAddress
         */
        get: function () {
            return this._data.tokenAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "tokenId", {
        /**
         * @returns the token id of the transfer.
         * @example transfer.tokenId // "15"
         */
        get: function () {
            return this._data.tokenId;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "amount", {
        /**
         * @returns the amount of the transfer.
         * @example transfer.amount // 1
         */
        get: function () {
            return this._data.amount;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "value", {
        /**
         * @returns the value of the transfer.
         * @example transfer.value // EvmNative
         */
        get: function () {
            return this._data.value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "logIndex", {
        /**
         * @returns the log index of the transfer.
         * @example transfer.logIndex // 0
         */
        get: function () {
            return this._data.logIndex;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "transactionHash", {
        /**
         * @returns the transaction hash of the transfer.
         * @example transfer.transactionHash // "0x057Ec652A4F150f7FF94f089A38008f49a0DF88e"
         */
        get: function () {
            return this._data.transactionHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "transactionIndex", {
        /**
         * @returns the transaction index of the transfer.
         * @example transfer.transactionIndex // 123
         */
        get: function () {
            return this._data.transactionIndex;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "transactionType", {
        /**
         * @returns the transaction type of the transfer.
         * @example transfer.transactionType // "1"
         */
        get: function () {
            return this._data.transactionType;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "operator", {
        /**
         * @returns the operator of the transfer.
         * @example transfer.operator // EvmAddress
         */
        get: function () {
            return this._data.operator;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmNftTransfer.prototype, "contractType", {
        /**
         * @returns the contract type of the transfer.
         * @example transfer.contractType // "ERC721"
         */
        get: function () {
            return this._data.contractType;
        },
        enumerable: false,
        configurable: true
    });
    EvmNftTransfer.parse = function (data) { return (__assign(__assign({}, data), { chain: EvmChain_1.EvmChain.create(data.chain), amount: (0, core_1.maybe)(data.amount, function (amount) { return +amount; }), blockNumber: core_1.BigNumber.create(data.blockNumber), blockTimestamp: (0, core_1.dateInputToDate)(data.blockTimestamp), transactionIndex: (0, core_1.maybe)(data.transactionIndex, function (index) { return +index; }), transactionType: (0, core_1.maybe)(data.transactionType), fromAddress: (0, core_1.maybe)(data.fromAddress, EvmAddress_1.EvmAddress.create), toAddress: EvmAddress_1.EvmAddress.create(data.toAddress), tokenAddress: EvmAddress_1.EvmAddress.create(data.tokenAddress), value: (0, core_1.maybe)(data.value, EvmNative_1.EvmNative.create), operator: (0, core_1.maybe)(data.operator, EvmAddress_1.EvmAddress.create) })); };
    return EvmNftTransfer;
}());
exports.EvmNftTransfer = EvmNftTransfer;
//# sourceMappingURL=EvmNftTransfer.js.map

/***/ }),

/***/ 9290:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(6282), exports);
__exportStar(__webpack_require__(9548), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9548:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 3881:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmTransaction = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
var EvmNative_1 = __webpack_require__(3912);
var EvmTransactionLog_1 = __webpack_require__(1838);
/**
 * The EvmTranaction is a representation of a published transaction.
 *
 * Use this class any time you work with a transaction.
 *
 * @category DataType
 */
var EvmTransaction = /** @class */ (function () {
    function EvmTransaction(data, core) {
        this._data = EvmTransaction.parse(data, core);
    }
    /**
     * Create a new instance of EvmTransaction from any valid transaction input
     * @param data - the EvmTransactionish type
     * @example
     * ```
     * const transaction = EvmTransaction.create(data);
     *```
     */
    EvmTransaction.create = function (data, core) {
        if (data instanceof EvmTransaction) {
            return data;
        }
        var finalCore = core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault();
        return new EvmTransaction(data, finalCore);
    };
    /**
     * Check the equality between two Evm transactions
     * @param dataA - The first transaction
     * @param dataB - The second transaction
     * @example
     * ```ts
     * EvmTransaction.equals(dataA, dataB)
     * ```
     */
    EvmTransaction.equals = function (dataA, dataB) {
        var transactionA = EvmTransaction.create(dataA);
        var transactionB = EvmTransaction.create(dataB);
        if (!transactionA._data.chain.equals(transactionB._data.chain)) {
            return false;
        }
        if (transactionA._data.hash !== transactionB._data.hash) {
            return false;
        }
        return true;
    };
    /**
     * Checks the equality of the current transaction with another evm transaction
     * @param data - the transaction to compare with
     * @example
     * ```ts
     * transaction.equals(data)
     * ```
     */
    EvmTransaction.prototype.equals = function (data) {
        return EvmTransaction.equals(this, data);
    };
    EvmTransaction.prototype.toJSON = function () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
        var data = this._data;
        return __assign(__assign({}, data), { to: (_a = data.to) === null || _a === void 0 ? void 0 : _a.format(), from: (_b = data.from) === null || _b === void 0 ? void 0 : _b.format(), nonce: (_c = data.nonce) === null || _c === void 0 ? void 0 : _c.toString(), gas: (_d = data.gas) === null || _d === void 0 ? void 0 : _d.toString(), gasPrice: (_e = data.gasPrice) === null || _e === void 0 ? void 0 : _e.toString(), gasUsed: (_f = data.gasUsed) === null || _f === void 0 ? void 0 : _f.toString(), cumulativeGasUsed: (_g = data.cumulativeGasUsed) === null || _g === void 0 ? void 0 : _g.toString(), blockNumber: (_h = data.blockNumber) === null || _h === void 0 ? void 0 : _h.toString(), value: (_j = data.value) === null || _j === void 0 ? void 0 : _j.toString(), chain: (_k = data.chain) === null || _k === void 0 ? void 0 : _k.format(), contractAddress: (_l = data.contractAddress) === null || _l === void 0 ? void 0 : _l.format(), logs: data.logs.map(function (log) { return log.toJSON(); }), blockTimestamp: data.blockTimestamp.toString() });
    };
    /**
     * @returns a JSON represention of the transaction.
     * @example
     * ```
     * transaction.format()
     * ```
     */
    EvmTransaction.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmTransaction.prototype, "result", {
        /**
         * @returns the transaction
         * @example
         * ```
         * transaction.result
         * ```
         */
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "to", {
        /**
         * @returns the transaction to address
         * @example
         * ```
         * transaction.to // EvmAddress
         * ```
         */
        get: function () {
            return this._data.to;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "from", {
        /**
         * @returns the transaction from address
         * @example
         * ```
         * transaction.address // EvmAddress
         * ```
         */
        get: function () {
            return this._data.from;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "nonce", {
        /**
         * @returns the transaction nonce
         * @example
         * ```
         * transaction.nonce // 326595425
         * ```
         */
        get: function () {
            return this._data.nonce;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "gas", {
        /**
         * @returns the transaction gas
         * @example
         * ```
         * transaction.gas // 6721975
         * ```
         */
        get: function () {
            return this._data.gas;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "gasPrice", {
        /**
         * @returns the transaction gas price
         * @example
         * ```
         * transaction.gasPrice // 20000000000
         * ```
         */
        get: function () {
            return this._data.gasPrice;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "gasUsed", {
        /**
         * @returns the transaction gas used
         * @example
         * ```
         * transaction.gasUsed // 1340925
         * ```
         */
        get: function () {
            return this._data.gasUsed;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "cumulativeGasUsed", {
        /**
         * @returns the transaction cumulative gas used
         * @example
         * ```
         * transaction.cumulativeGasUsed // 1340925
         * ```
         */
        get: function () {
            return this._data.cumulativeGasUsed;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "blockNumber", {
        /**
         * @returns the transaction block number
         * @example
         * ```
         * transaction.blockNumber // 12526958
         * ```
         */
        get: function () {
            return this._data.blockNumber;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "value", {
        /**
         * @returns the transaction value
         * @example
         * ```
         * transaction.value // EvmNative
         * ```
         */
        get: function () {
            return this._data.value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "chain", {
        /**
         * @returns the transaction chain
         * @example
         * ```
         * transaction.chain // EvmChain
         * ```
         */
        get: function () {
            return this._data.chain;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "contractAddress", {
        /**
         * @returns the transaction contract address
         * @example
         * ```
         * transaction.contractAddress // EvmAddress
         * ```
         */
        get: function () {
            return this._data.contractAddress;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "logs", {
        /**
         * @returns the transaction logs
         * @example
         * ```
         * transaction.logs // EvmTransactionLog[]
         * ```
         */
        get: function () {
            return this._data.logs;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "receiptRoot", {
        /**
         * @returns the transaction receipt root
         * @example
         * ```
         * transaction.receiptRoot // string
         * ```
         */
        get: function () {
            return this._data.receiptRoot;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "receiptStatus", {
        /**
         * @returns the transaction receipt status
         * @example
         * ```
         * transaction.receiptStatus // 1
         * ```
         */
        get: function () {
            return this._data.receiptStatus;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "data", {
        /**
         * @returns the transaction data
         * @example
         * ```
         * transaction.data // 0x000000000000000000000000000000000000000000000000000000000000002
         * ```
         */
        get: function () {
            return this._data.data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "hash", {
        /**
         * @returns the transaction hash
         * @example
         * ```
         * transaction.hash // 0x057Ec652A4F150f7FF94f089A38008f49a0DF88e
         * ```
         */
        get: function () {
            return this._data.hash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "type", {
        /**
         * @returns the transaction type
         * @example
         * ```
         * transaction.type // 1
         * ```
         */
        get: function () {
            return this._data.type;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "blockHash", {
        /**
         * @returns the transaction black hash
         * @example
         * ```
         * transaction.blockHash // 0x0372c302e3c52e8f2e15d155e2c545e6d802e479236564af052759253b20fd86
         * ```
         */
        get: function () {
            return this._data.blockHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransaction.prototype, "blockTimestamp", {
        /**
         * @returns the transaction block timestamp
         * @example
         * ```
         * transaction.blockTimestamp // Date
         * ```
         */
        get: function () {
            return this._data.blockTimestamp;
        },
        enumerable: false,
        configurable: true
    });
    EvmTransaction.parse = function (data, core) {
        var _a;
        return ({
            from: EvmAddress_1.EvmAddress.create(data.from, core),
            to: (0, core_1.maybe)(data.to, function (to) { return EvmAddress_1.EvmAddress.create(to, core); }),
            nonce: (0, core_1.maybe)(data.nonce, core_1.BigNumber.create),
            data: (0, core_1.maybe)(data.data),
            value: (0, core_1.maybe)(data.value, function (val) { return EvmNative_1.EvmNative.create(val, 'wei'); }),
            hash: data.hash,
            type: (0, core_1.maybe)(data.type),
            chain: EvmChain_1.EvmChain.create(data.chain),
            gas: (0, core_1.maybe)(data.gas, core_1.BigNumber.create),
            gasPrice: core_1.BigNumber.create(data.gasPrice),
            index: +data.index,
            blockNumber: core_1.BigNumber.create(data.blockNumber),
            blockHash: data.blockHash,
            blockTimestamp: (0, core_1.dateInputToDate)(data.blockTimestamp),
            cumulativeGasUsed: core_1.BigNumber.create(data.cumulativeGasUsed),
            gasUsed: core_1.BigNumber.create(data.gasUsed),
            contractAddress: (0, core_1.maybe)(data.contractAddress, function (address) { return EvmAddress_1.EvmAddress.create(address, core); }),
            receiptRoot: (0, core_1.maybe)(data.receiptRoot),
            receiptStatus: (0, core_1.maybe)(data.receiptStatus, function (status) { return +status; }),
            logs: ((_a = data.logs) !== null && _a !== void 0 ? _a : []).map(function (log) { return EvmTransactionLog_1.EvmTransactionLog.create(log); }),
        });
    };
    return EvmTransaction;
}());
exports.EvmTransaction = EvmTransaction;
//# sourceMappingURL=EvmTransaction.js.map

/***/ }),

/***/ 7048:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(2447), exports);
__exportStar(__webpack_require__(3881), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2447:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 5119:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EvmTransactionLog = void 0;
var core_1 = __webpack_require__(4243);
var EvmAddress_1 = __webpack_require__(4142);
var EvmChain_1 = __webpack_require__(43);
/**
 * The EvmTransactionLog class is a MoralisData that references an EVM transaction log.
 *
 * @category DataType
 */
var EvmTransactionLog = /** @class */ (function () {
    function EvmTransactionLog(value, core) {
        this._value = EvmTransactionLog.parse(value, core);
    }
    /**
     * Create a new instance of EvmTransactionLog from any valid address input
     *
     * @example
     * ```
     * const log = EvmTransactionLog.create(value, core);
     * ```
     * @param value - A valid EvmTransactionLogish
     * @param core - The MoralisCore instance
     */
    EvmTransactionLog.create = function (value, core) {
        if (value instanceof EvmTransactionLog) {
            return value;
        }
        var finalCore = core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault();
        return new EvmTransactionLog(value, finalCore);
    };
    EvmTransactionLog.parse = function (value, core) {
        return {
            logIndex: (0, core_1.maybe)(value.logIndex),
            transactionHash: value.transactionHash,
            transactionIndex: (0, core_1.maybe)(value.transactionIndex),
            data: value.data,
            topics: value.topics,
            blockHash: value.blockHash,
            blockNumber: value.blockNumber,
            blockTimestamp: value.blockTimestamp,
            address: EvmAddress_1.EvmAddress.create(value.address, core),
            chain: EvmChain_1.EvmChain.create(value.chain, core),
        };
    };
    /**
     * Compares the log to another log for equality.
     *
     * @param value - The value to compare with
     * @returns true if the logs are equal, otherwise false
     * @example
     * ```ts
     * log.equals(log);
     * ```
     */
    EvmTransactionLog.prototype.equals = function (value) {
        return (value._value.transactionHash === this._value.transactionHash &&
            value._value.address.equals(this._value.address) &&
            value._value.logIndex === this._value.logIndex &&
            value._value.chain.equals(this._value.chain));
    };
    /**
     * Converts the log to a JSON object.
     *
     * @returns the EvmTransactionLog as a JSON object
     * @example
     * ```ts
     * log.toJSON();
     * ```
     */
    EvmTransactionLog.prototype.toJSON = function () {
        var _a;
        var value = this._value;
        return __assign(__assign({}, value), { address: value.address.format(), chain: (_a = value.chain) === null || _a === void 0 ? void 0 : _a.format() });
    };
    /**
     * Converts the log to a JSON object.
     *
     * @returns the EvmTransactionLog as a JSON object
     * @example
     * ```ts
     * log.format();
     * ```
     */
    EvmTransactionLog.prototype.format = function () {
        return this.toJSON();
    };
    Object.defineProperty(EvmTransactionLog.prototype, "result", {
        /**
         * Returns the processed Erc20Token.
         *
         * @returns the EvmTransactionLog value
         * @example
         * ```ts
         * log.result;
         *  ```
         */
        get: function () {
            return this._value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "transactionHash", {
        /**
         * @returns the transaction hash of the log.
         *
         * @example
         * ```ts
         * log.transactionHash; // "0xdd9006489e46670e0e85d1fb88823099e7f596b08aeaac023e9da0851f26fdd5"
         * ```
         */
        get: function () {
            return this._value.transactionHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "address", {
        /**
         * Returns the address of the log.
         *
         * @example
         * ```ts
         * log.address; // EvmAddress
         * ```
         */
        get: function () {
            return this._value.address;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "logIndex", {
        /**
         * @returns the log index of the log.
         *
         * @example
         * ```ts
         * log.logIndex; // 273
         * ```
         */
        get: function () {
            return this._value.logIndex;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "data", {
        /**
         * @returns the data of the log.
         *
         * @example
         * ```ts
         * log.data; // "0x00000000000000000000000000000000000000000000000de05239bccd4d537400000000000000000000000000024dbc80a9f80e3d5fc0a0ee30e2693781a443"
         * ```
         */
        get: function () {
            return this._value.data;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "topics", {
        /**
         * @returns the topics of the log.
         *
         * @example
         * ```ts
         * log.topics; // ["0x0000000000000000000000000000000000000000000000000000000000000001", "0x0000000000000000000000000000000000000000000000000000000000000002"]
         * ```
         */
        get: function () {
            return this._value.topics;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "blockHash", {
        /**
         * @returns the block hash of the log.
         *
         * @example
         * ```ts
         * log.blockHash; // "0x9b559aef7ea858608c2e554246fe4a24287e7aeeb976848df2b9a2531f4b9171"
         * ```
         */
        get: function () {
            return this._value.blockHash;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "blockNumber", {
        /**
         * @returns the block number of the log.
         *
         * @example
         * ```ts
         * log.blockNumber; // 12386788
         * ```
         */
        get: function () {
            return this._value.blockNumber;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "blockTimestamp", {
        /**
         * @returns the block timestamp of the log.
         *
         * @example
         * ```ts
         * log.blockTimestamp; // "2021-05-07T11:08:35.000Z"
         * ```
         */
        get: function () {
            return this._value.blockTimestamp;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(EvmTransactionLog.prototype, "chain", {
        /**
         * @returns the chainId for the particular log.
         *
         * @example
         * ```ts
         * log.chainId; // "1"
         * ```
         */
        get: function () {
            return this._value.chain;
        },
        enumerable: false,
        configurable: true
    });
    return EvmTransactionLog;
}());
exports.EvmTransactionLog = EvmTransactionLog;
//# sourceMappingURL=EvmTransactionLog.js.map

/***/ }),

/***/ 1838:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(5119), exports);
__exportStar(__webpack_require__(5051), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 5051:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 3457:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(1339), exports);
__exportStar(__webpack_require__(3500), exports);
__exportStar(__webpack_require__(8856), exports);
__exportStar(__webpack_require__(4142), exports);
__exportStar(__webpack_require__(7145), exports);
__exportStar(__webpack_require__(43), exports);
__exportStar(__webpack_require__(5177), exports);
__exportStar(__webpack_require__(3912), exports);
__exportStar(__webpack_require__(8703), exports);
__exportStar(__webpack_require__(4589), exports);
__exportStar(__webpack_require__(7584), exports);
__exportStar(__webpack_require__(5291), exports);
__exportStar(__webpack_require__(9290), exports);
__exportStar(__webpack_require__(7048), exports);
__exportStar(__webpack_require__(1838), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9977:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(3457), exports);
__exportStar(__webpack_require__(5438), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 924:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
var streams_1 = __webpack_require__(4354);
var api_utils_1 = __webpack_require__(3520);
var auth_1 = __webpack_require__(3228);
var evm_utils_1 = __webpack_require__(9977);
var evm_api_1 = __webpack_require__(7268);
var sol_utils_1 = __webpack_require__(6826);
var sol_api_1 = __webpack_require__(2305);
var core_1 = __webpack_require__(4243);
// Core
var core = core_1.MoralisCore.create();
// Utility modules
var evmUtils = evm_utils_1.MoralisEvmUtils.create(core);
var solUtils = sol_utils_1.MoralisSolUtils.create(core);
var apiUtils = api_utils_1.MoralisApiUtils.create(core);
// Feature modules
var auth = auth_1.MoralisAuth.create(core);
var streams = streams_1.MoralisStreams.create(core);
var evmApi = evm_api_1.MoralisEvmApi.create(core);
var solApi = sol_api_1.MoralisSolApi.create(core);
// Register all Moralis modules to MoralisCore
core.registerModules([evmUtils, solUtils, auth, apiUtils, evmApi, solApi, streams]);
core_1.MoralisCoreProvider.setDefault(core);
var Moralis = {
    Core: core,
    Auth: auth,
    Streams: streams,
    EvmApi: evmApi,
    SolApi: solApi,
    start: core.start,
};
exports.Z = Moralis;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 8964:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisSolApi = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var SolApiConfigSetup_1 = __webpack_require__(9656);
var getBalance_1 = __webpack_require__(8847);
var getNFTs_1 = __webpack_require__(8735);
var getPortfolio_1 = __webpack_require__(6398);
var getSPL_1 = __webpack_require__(7252);
var getNFTMetadata_1 = __webpack_require__(6762);
var getTokenPrice_1 = __webpack_require__(3179);
var BASE_URL = 'https://solana-gateway.moralis.io';
var MoralisSolApi = /** @class */ (function (_super) {
    __extends(MoralisSolApi, _super);
    function MoralisSolApi(core) {
        var _this = _super.call(this, MoralisSolApi.moduleName, core, BASE_URL) || this;
        _this.endpoints = new api_utils_1.Endpoints(_this.core, BASE_URL);
        _this.getBalance = _this.endpoints.createFetcher(getBalance_1.getBalance);
        _this.account = {
            getBalance: _this.getBalance,
            getNFTs: _this.endpoints.createFetcher(getNFTs_1.getNFTs),
            getPortfolio: _this.endpoints.createFetcher(getPortfolio_1.getPortfolio),
            getSPL: _this.endpoints.createFetcher(getSPL_1.getSPL),
            // Support for old naming
            /**
             * @deprecated Replaced by account.getBalance
             */
            balance: _this.getBalance,
        };
        _this.nft = {
            getNFTMetadata: _this.endpoints.createFetcher(getNFTMetadata_1.getNFTMetadata),
        };
        _this.token = {
            getTokenPrice: _this.endpoints.createFetcher(getTokenPrice_1.getTokenPrice),
        };
        return _this;
    }
    MoralisSolApi.create = function (core) {
        return new MoralisSolApi(core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault());
    };
    MoralisSolApi.prototype.setup = function () {
        SolApiConfigSetup_1.SolApiConfigSetup.register(this.core.config);
    };
    MoralisSolApi.prototype.start = function () {
        // Nothing
    };
    MoralisSolApi.moduleName = 'solApi';
    return MoralisSolApi;
}(core_1.ApiModule));
exports.MoralisSolApi = MoralisSolApi;
//# sourceMappingURL=MoralisSolApi.js.map

/***/ }),

/***/ 7427:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SolApiConfig = void 0;
exports.SolApiConfig = {
    defaultSolNetwork: {
        name: 'defaultSolNetwork',
        defaultValue: 'mainnet',
    },
};
//# sourceMappingURL=SolApiConfig.js.map

/***/ }),

/***/ 9656:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SolApiConfigSetup = void 0;
var SolApiConfig_1 = __webpack_require__(7427);
var SolApiConfigSetup = /** @class */ (function () {
    function SolApiConfigSetup() {
    }
    SolApiConfigSetup.register = function (config) {
        config.registerKey(SolApiConfig_1.SolApiConfig.defaultSolNetwork);
    };
    return SolApiConfigSetup;
}());
exports.SolApiConfigSetup = SolApiConfigSetup;
//# sourceMappingURL=SolApiConfigSetup.js.map

/***/ }),

/***/ 2305:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var MoralisSolApi_1 = __webpack_require__(8964);
__exportStar(__webpack_require__(8964), exports);
exports["default"] = { MoralisSolApi: MoralisSolApi_1.MoralisSolApi };
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7063:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SolNetworkResolver = void 0;
var sol_utils_1 = __webpack_require__(6826);
var SolApiConfig_1 = __webpack_require__(7427);
var SolNetworkResolver = /** @class */ (function () {
    function SolNetworkResolver() {
    }
    SolNetworkResolver.resolve = function (network, core) {
        if (!network) {
            network = core.config.get(SolApiConfig_1.SolApiConfig.defaultSolNetwork);
        }
        return sol_utils_1.SolNetwork.create(network).network;
    };
    return SolNetworkResolver;
}());
exports.SolNetworkResolver = SolNetworkResolver;
//# sourceMappingURL=SolNetworkResolver.js.map

/***/ }),

/***/ 8847:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getBalance = void 0;
var api_utils_1 = __webpack_require__(3520);
var sol_utils_1 = __webpack_require__(6826);
var SolNetworkResolver_1 = __webpack_require__(7063);
exports.getBalance = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getBalance',
        urlParams: ['network', 'address'],
        getUrl: function (params) {
            // TODO: here should be: const network = SolNetworkResolver.resolve(params.network, core);
            // but it's not working with Endpoints.getDescriptors(). After changes described in Endpoints
            // please replace this line.
            var network = params.network ? params.network : SolNetworkResolver_1.SolNetworkResolver.resolve(undefined, core);
            return "/account/".concat(network, "/").concat(params.address, "/balance");
        },
        apiToResult: function (data) {
            return sol_utils_1.SolNative.create(data.lamports, 'lamports');
        },
        resultToJson: function (data) {
            return data.toJSON();
        },
        parseParams: function (params) { return ({
            network: SolNetworkResolver_1.SolNetworkResolver.resolve(params.network, core),
            address: sol_utils_1.SolAddress.create(params.address).address,
        }); },
    });
});
//# sourceMappingURL=getBalance.js.map

/***/ }),

/***/ 8735:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTs = void 0;
var api_utils_1 = __webpack_require__(3520);
var sol_utils_1 = __webpack_require__(6826);
var SolNetworkResolver_1 = __webpack_require__(7063);
exports.getNFTs = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getNFTs',
        urlParams: ['network', 'address'],
        getUrl: function (params) {
            // TODO: here should be: const network = SolNetworkResolver.resolve(params.network, core);
            // but it's not working with Endpoints.getDescriptors(). After changes described in Endpoints
            // please replace this line.
            var network = params.network ? params.network : SolNetworkResolver_1.SolNetworkResolver.resolve(undefined, core);
            return "/account/".concat(network, "/").concat(params.address, "/nft");
        },
        apiToResult: function (data) {
            return data.map(function (nft) {
                return {
                    associatedTokenAddress: sol_utils_1.SolAddress.create(nft.associatedTokenAddress),
                    mint: sol_utils_1.SolAddress.create(nft.mint),
                };
            });
        },
        resultToJson: function (data) {
            return data.map(function (nft) {
                return {
                    associatedTokenAddress: nft.associatedTokenAddress.toJSON(),
                    mint: nft.mint.toJSON(),
                };
            });
        },
        parseParams: function (params) { return ({
            network: SolNetworkResolver_1.SolNetworkResolver.resolve(params.network, core),
            address: sol_utils_1.SolAddress.create(params.address).address,
        }); },
    });
});
//# sourceMappingURL=getNFTs.js.map

/***/ }),

/***/ 6398:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getPortfolio = void 0;
var api_utils_1 = __webpack_require__(3520);
var sol_utils_1 = __webpack_require__(6826);
var SolNetworkResolver_1 = __webpack_require__(7063);
exports.getPortfolio = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getPortfolio',
        urlParams: ['network', 'address'],
        getUrl: function (params) {
            // TODO: here should be: const network = SolNetworkResolver.resolve(params.network, core);
            // but it's not working with Endpoints.getDescriptors(). After changes described in Endpoints
            // please replace this line.
            var network = params.network ? params.network : SolNetworkResolver_1.SolNetworkResolver.resolve(undefined, core);
            return "/account/".concat(network, "/").concat(params.address, "/portfolio");
        },
        apiToResult: function (data) {
            return {
                nativeBalance: sol_utils_1.SolNative.create(data.nativeBalance.lamports, 'lamports'),
                nfts: data.nfts.map(function (nft) {
                    return {
                        associatedTokenAddress: sol_utils_1.SolAddress.create(nft.associatedTokenAddress),
                        mint: sol_utils_1.SolAddress.create(nft.mint),
                    };
                }),
                tokens: data.tokens.map(function (token) {
                    return {
                        associatedTokenAddress: sol_utils_1.SolAddress.create(token.associatedTokenAddress),
                        mint: sol_utils_1.SolAddress.create(token.mint),
                        amount: sol_utils_1.SolNative.create(token.amountRaw, 'lamports'),
                    };
                }),
            };
        },
        resultToJson: function (data) {
            return {
                nativeBalance: data.nativeBalance.toJSON(),
                nfts: data.nfts.map(function (nft) {
                    return {
                        associatedTokenAddress: nft.associatedTokenAddress.toJSON(),
                        mint: nft.mint.toJSON(),
                    };
                }),
                tokens: data.tokens.map(function (token) {
                    return {
                        associatedTokenAddress: token.associatedTokenAddress.toJSON(),
                        mint: token.mint.toJSON(),
                        amount: token.amount.toJSON(),
                    };
                }),
            };
        },
        parseParams: function (params) { return ({
            network: SolNetworkResolver_1.SolNetworkResolver.resolve(params.network, core),
            address: sol_utils_1.SolAddress.create(params.address).address,
        }); },
    });
});
//# sourceMappingURL=getPortfolio.js.map

/***/ }),

/***/ 7252:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getSPL = void 0;
var api_utils_1 = __webpack_require__(3520);
var sol_utils_1 = __webpack_require__(6826);
var SolNetworkResolver_1 = __webpack_require__(7063);
exports.getSPL = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getSPL',
        urlParams: ['network', 'address'],
        getUrl: function (params) {
            // TODO: here should be: const network = SolNetworkResolver.resolve(params.network, core);
            // but it's not working with Endpoints.getDescriptors(). After changes described in Endpoints
            // please replace this line.
            var network = params.network ? params.network : SolNetworkResolver_1.SolNetworkResolver.resolve(undefined, core);
            return "/account/".concat(network, "/").concat(params.address, "/tokens");
        },
        apiToResult: function (data) {
            return data.map(function (token) {
                return {
                    associatedTokenAddress: sol_utils_1.SolAddress.create(token.associatedTokenAddress),
                    mint: sol_utils_1.SolAddress.create(token.mint),
                    amount: sol_utils_1.SolNative.create(token.amountRaw, 'lamports'),
                };
            });
        },
        resultToJson: function (data) {
            return data.map(function (token) {
                return {
                    associatedTokenAddress: token.associatedTokenAddress.toJSON(),
                    mint: token.mint.toJSON(),
                    amount: token.amount.toJSON(),
                };
            });
        },
        parseParams: function (params) { return ({
            network: SolNetworkResolver_1.SolNetworkResolver.resolve(params.network, core),
            address: sol_utils_1.SolAddress.create(params.address).address,
        }); },
    });
});
//# sourceMappingURL=getSPL.js.map

/***/ }),

/***/ 6762:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getNFTMetadata = void 0;
var api_utils_1 = __webpack_require__(3520);
var sol_utils_1 = __webpack_require__(6826);
var SolNetworkResolver_1 = __webpack_require__(7063);
exports.getNFTMetadata = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getNFTMetadata',
        urlParams: ['network', 'address'],
        getUrl: function (params) {
            // TODO: here should be: const network = SolNetworkResolver.resolve(params.network, core);
            // but it's not working with Endpoints.getDescriptors(). After changes described in Endpoints
            // please replace this line.
            var network = params.network ? params.network : SolNetworkResolver_1.SolNetworkResolver.resolve(undefined, core);
            return "/nft/".concat(network, "/").concat(params.address, "/metadata");
        },
        apiToResult: function (data) {
            return {
                mint: sol_utils_1.SolAddress.create(data.mint),
                standard: data.standard,
                name: data.name,
                symbol: data.symbol,
                metaplex: {
                    metadataUri: data.metaplex.metadataUri,
                    updateAuthority: sol_utils_1.SolAddress.create(data.metaplex.updateAuthority),
                    sellerFeeBasisPoints: data.metaplex.sellerFeeBasisPoints,
                    primarySaleHappened: data.metaplex.primarySaleHappened,
                    isMutable: data.metaplex.isMutable,
                    masterEdition: data.metaplex.masterEdition,
                },
            };
        },
        resultToJson: function (data) {
            return {
                mint: data.mint.toJSON(),
                standard: data.standard,
                name: data.name,
                symbol: data.symbol,
                metaplex: {
                    metadataUri: data.metaplex.metadataUri,
                    updateAuthority: data.metaplex.updateAuthority.toJSON(),
                    sellerFeeBasisPoints: data.metaplex.sellerFeeBasisPoints,
                    primarySaleHappened: data.metaplex.primarySaleHappened,
                    isMutable: data.metaplex.isMutable,
                    masterEdition: data.metaplex.masterEdition,
                },
            };
        },
        parseParams: function (params) { return ({
            network: SolNetworkResolver_1.SolNetworkResolver.resolve(params.network, core),
            address: sol_utils_1.SolAddress.create(params.address).address,
        }); },
    });
});
//# sourceMappingURL=getNFTMetadata.js.map

/***/ }),

/***/ 3179:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokenPrice = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var sol_utils_1 = __webpack_require__(6826);
var SolNetworkResolver_1 = __webpack_require__(7063);
exports.getTokenPrice = (0, api_utils_1.createEndpointFactory)(function (core) {
    return (0, api_utils_1.createEndpoint)({
        name: 'getTokenPrice',
        urlParams: ['network', 'address'],
        getUrl: function (params) {
            // TODO: here should be: const network = SolNetworkResolver.resolve(params.network, core);
            // but it's not working with Endpoints.getDescriptors(). After changes described in Endpoints
            // please replace this line.
            var network = params.network ? params.network : SolNetworkResolver_1.SolNetworkResolver.resolve(undefined, core);
            return "/token/".concat(network, "/").concat(params.address, "/price");
        },
        apiToResult: function (data) {
            return {
                nativePrice: {
                    value: sol_utils_1.SolNative.create(data.nativePrice.value, 'solana'),
                    decimals: data.nativePrice.decimals,
                    name: data.nativePrice.name,
                    symbol: data.nativePrice.symbol,
                },
                usdPrice: data.usdPrice,
                exchangeAddress: sol_utils_1.SolAddress.create(data.exchangeAddress),
                exchangeName: data.exchangeName,
            };
        },
        resultToJson: function (data) {
            return {
                nativePrice: {
                    value: data.nativePrice.value.toJSON(),
                    decimals: data.nativePrice.decimals,
                    name: data.nativePrice.name,
                    symbol: data.nativePrice.symbol,
                },
                usdPrice: data.usdPrice,
                exchangeAddress: data.exchangeAddress.toJSON(),
                exchangeName: data.exchangeName,
            };
        },
        parseParams: function (params) {
            var network = SolNetworkResolver_1.SolNetworkResolver.resolve(params.network, core);
            if (network !== 'mainnet') {
                throw new core_1.MoralisApiError({
                    message: "Incorrct value for 'network', getTokenPrice is only available on mainnet",
                    code: core_1.ApiErrorCode.INVALID_PARAMS,
                });
            }
            return {
                network: network,
                address: sol_utils_1.SolAddress.create(params.address).address,
            };
        },
    });
});
//# sourceMappingURL=getTokenPrice.js.map

/***/ }),

/***/ 6755:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisSolUtils = void 0;
var core_1 = __webpack_require__(4243);
var MoralisSolUtils = /** @class */ (function (_super) {
    __extends(MoralisSolUtils, _super);
    function MoralisSolUtils(core) {
        return _super.call(this, MoralisSolUtils.moduleName, core) || this;
    }
    MoralisSolUtils.create = function (core) {
        return new MoralisSolUtils(core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault());
    };
    MoralisSolUtils.prototype.setup = function () {
        // Nothing
    };
    MoralisSolUtils.prototype.start = function () {
        // Nothing
    };
    MoralisSolUtils.moduleName = 'solUtils';
    return MoralisSolUtils;
}(core_1.Module));
exports.MoralisSolUtils = MoralisSolUtils;
//# sourceMappingURL=MoralisSolUtils.js.map

/***/ }),

/***/ 376:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SolAddress = void 0;
var core_1 = __webpack_require__(4243);
var web3_js_1 = __webpack_require__(9859);
/**
 * A representation of an address on the Solana network.
 *
 * Use this class any time you work with an address.
 *
 * @category DataType
 */
var SolAddress = /** @class */ (function () {
    function SolAddress(address) {
        this.address = address;
    }
    /**
     * Create a new instance of SolAddress from any valid address input.
     *
     * @example `const address = SolAddress.create("9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM")`
     * @throws an error when a passed address is invalid.
     */
    SolAddress.create = function (address) {
        return address instanceof SolAddress ? address : new SolAddress(SolAddress.parse(address));
    };
    SolAddress.parse = function (address) {
        try {
            var publicKey = new web3_js_1.PublicKey(address);
            return publicKey.toBase58();
        }
        catch (e) {
            throw new core_1.MoralisCoreError({
                code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                message: "Invalid Solana address provided: ".concat(address),
                cause: e,
            });
        }
    };
    /**
     * Formats the address to a specific format.
     * Currently returns a string representing the address.
     * @example address.format(); // "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM"
     */
    SolAddress.prototype.format = function () {
        // TODO: add `format` argument
        return this.address;
    };
    /**
     * Checks the equality of the current address with another Solana address.
     * @example `address.equals("9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM")`
     * @example `address.equals(SolAddress.create("9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM"))`
     */
    SolAddress.prototype.equals = function (address) {
        return this.address === SolAddress.create(address).address;
    };
    /**
     * @returns a string representing the address.
     * @example address.toString(); // "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM"
     */
    SolAddress.prototype.toString = function () {
        return this.address;
    };
    /**
     * @returns a string representing the address.
     * @example address.toJSON(); // "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM"
     */
    SolAddress.prototype.toJSON = function () {
        return this.address;
    };
    return SolAddress;
}());
exports.SolAddress = SolAddress;
//# sourceMappingURL=SolAddress.js.map

/***/ }),

/***/ 2136:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(376), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7515:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SolNative = void 0;
var core_1 = __webpack_require__(4243);
var unitToDecimals = {
    solana: 9,
    lamports: 0,
};
var SolNative = /** @class */ (function () {
    function SolNative(rawValue) {
        this.rawValue = rawValue;
    }
    /**
     * Create a new instance of SolNative from any valid {@link SolNativeish} value.
     * @param value - the value to create the SolNative from
     * @param unit - the unit of the value (optional), defaults to `solana`
     * @returns a new instance of SolNative
     * @example
     * ```ts
     * const native = SolNative.create(2, 'lamports');
     * const native = SolNative.create(2);
     *```
     */
    SolNative.create = function (value, unit) {
        if (value instanceof SolNative) {
            return value;
        }
        return new SolNative(SolNative.parse(value, unit));
    };
    SolNative.parse = function (value, unit) {
        if (unit === void 0) { unit = 'solana'; }
        var decimal;
        if (typeof unit === 'number') {
            decimal = unit;
        }
        else if (unitToDecimals[unit] !== undefined) {
            decimal = unitToDecimals[unit];
        }
        else {
            throw new core_1.MoralisCoreError({
                code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                message: "Not supported Solana unit: ".concat(unit),
            });
        }
        return core_1.BigNumber.fromDecimal(value.toString(), decimal);
    };
    /**
     * Compares two SolNativeish values.
     * @param valueA - the first value to compare
     * @param valueB - the second value to compare
     * @returns true if the values are equal
     * @example
     * ```ts
     * SolNative.equals(SolNative.create(1), SolNative.create(1)); // true
     * ```
     */
    SolNative.equals = function (valueA, valueB) {
        var solNativeA = SolNative.create(valueA);
        var solNativeB = SolNative.create(valueB);
        return solNativeA.lamports === solNativeB.lamports;
    };
    /**
     * Compares SolNative with current instance.
     * @param value - the value to compare with
     * @returns true if the values are equal
     * @example
     * ```ts
     * const native = SolNative.create(2, 'lamports');
     * native.equals(SolNative.create(1)); // false
     * ```
     */
    SolNative.prototype.equals = function (value) {
        return SolNative.equals(this, value);
    };
    /**
     * Converts the SolNative to a string.
     * @returns the value of the SolNative as a string
     * @example `native.format()`
     */
    SolNative.prototype.format = function () {
        // TODO: add `format` argument
        return this.lamports;
    };
    /**
     * Converts the SolNative to a string.
     * @returns the value of the SolNative as a string
     * @example `native.toJSON()`
     */
    SolNative.prototype.toJSON = function () {
        return this.lamports;
    };
    /**
     * Converts the SolNative to a string.
     * @returns the value of the SolNative as a string
     * @example `native.toString()`
     */
    SolNative.prototype.toString = function () {
        return this.lamports;
    };
    Object.defineProperty(SolNative.prototype, "value", {
        /**
         * @returns the value of the SolNative as a BigNumber
         * @example `native.value`
         */
        get: function () {
            return this.rawValue;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(SolNative.prototype, "solana", {
        /**
         * Converts the SolNative to a solana unit.
         * @returns the value of the SolNative as a solana string
         * @example `native.solana`
         */
        get: function () {
            return this.rawValue.toDecimal(unitToDecimals['solana']);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(SolNative.prototype, "lamports", {
        /**
         * Converts the SolNative to a string.
         * @returns the value of the SolNative as a string
         * @example `native.lamports`
         */
        get: function () {
            return this.rawValue.toString();
        },
        enumerable: false,
        configurable: true
    });
    return SolNative;
}());
exports.SolNative = SolNative;
//# sourceMappingURL=SolNative.js.map

/***/ }),

/***/ 5070:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(7515), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9051:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SolNetwork = void 0;
var core_1 = __webpack_require__(4243);
var solNetworkNames = ['mainnet', 'devnet'];
/**
 * A representation of a Solana network.
 *
 * @category DataType
 */
var SolNetwork = /** @class */ (function () {
    function SolNetwork(network) {
        this.network = network;
    }
    Object.defineProperty(SolNetwork, "MAINNET", {
        /**
         * Returns MAINNET network
         *
         * @example SolNetwork.MAINNET
         */
        get: function () {
            return SolNetwork.create('mainnet');
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(SolNetwork, "DEVNET", {
        /**
         * Returns DEVNET network
         *
         * @example SolNetwork.MAINNET
         */
        get: function () {
            return SolNetwork.create('devnet');
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Create a new instance of SolNetwork from any valid network input.
     *
     * @example `const network = SolNetwork.create("mainnet")`
     * @throws an error when a passed network is invalid.
     */
    SolNetwork.create = function (network) {
        return network instanceof SolNetwork ? network : new SolNetwork(SolNetwork.parse(network));
    };
    SolNetwork.parse = function (network) {
        if (typeof network === 'string') {
            if (!solNetworkNames.includes(network)) {
                throw new core_1.MoralisCoreError({
                    code: core_1.CoreErrorCode.INVALID_ARGUMENT,
                    message: "Solana network is not supported: ".concat(network),
                });
            }
        }
        return network;
    };
    /**
     * Formats the network to a specific format.
     * Currently returns a string representing the network.
     * @example network.format(); // "mainnet"
     */
    SolNetwork.prototype.format = function () {
        // TODO: add `format` argument
        return this.network;
    };
    /**
     * Checks the equality of the current network with another Solana network.
     * @example `network.equals("mainnet")`
     * @example `network.equals(SolNetwork.create("mainnet"))`
     */
    SolNetwork.prototype.equals = function (network) {
        return this.network === SolNetwork.create(network).network;
    };
    /**
     * @returns a string representing the network.
     * @example network.toJSON(); // "mainnet"
     */
    SolNetwork.prototype.toJSON = function () {
        return this.network;
    };
    /**
     * @returns a string representing the network.
     * @example network.toString(); // "mainnet"
     */
    SolNetwork.prototype.toString = function () {
        return this.network;
    };
    return SolNetwork;
}());
exports.SolNetwork = SolNetwork;
//# sourceMappingURL=SolNetwork.js.map

/***/ }),

/***/ 9005:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(9051), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 8836:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(2136), exports);
__exportStar(__webpack_require__(9005), exports);
__exportStar(__webpack_require__(5070), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6826:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(8836), exports);
__exportStar(__webpack_require__(6755), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 5779:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MoralisStreams = void 0;
var resolvers_1 = __webpack_require__(3252);
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var create_1 = __webpack_require__(1);
var update_1 = __webpack_require__(5430);
var delete_1 = __webpack_require__(5287);
var getAll_1 = __webpack_require__(9063);
var verifySignature_1 = __webpack_require__(243);
var addAddress_1 = __webpack_require__(8808);
var updateStatus_1 = __webpack_require__(4239);
var logParser_1 = __webpack_require__(6292);
var getHistory_1 = __webpack_require__(753);
var replayHistory_1 = __webpack_require__(2649);
var getAddresses_1 = __webpack_require__(8235);
var deleteAddress_1 = __webpack_require__(553);
var getById_1 = __webpack_require__(2013);
var BASE_URL = 'https://api.moralis-streams.com';
var MoralisStreams = /** @class */ (function (_super) {
    __extends(MoralisStreams, _super);
    function MoralisStreams(core) {
        var _this = _super.call(this, MoralisStreams.moduleName, core, BASE_URL) || this;
        _this.endpoints = new api_utils_1.Endpoints(_this.core, BASE_URL);
        _this.add = (0, create_1.makeCreateStream)(_this.endpoints);
        _this.update = (0, update_1.makeUpdateStream)(_this.endpoints);
        _this.delete = (0, delete_1.makeDeleteStream)(_this.endpoints);
        _this.getAll = (0, getAll_1.makeGetStreams)(_this.endpoints);
        _this.getById = (0, getById_1.makeGetStreamById)(_this.endpoints);
        _this.updateStatus = (0, updateStatus_1.makeUpdateStreamStatus)(_this.endpoints);
        _this.addAddress = (0, addAddress_1.makeAddAddress)(_this.endpoints);
        _this.getAddresses = (0, getAddresses_1.makeGetAddresses)(_this.endpoints);
        _this.deleteAddress = (0, deleteAddress_1.makeDeleteAddress)(_this.endpoints);
        _this.getHistory = _this.endpoints.createPaginatedFetcher(getHistory_1.getHistory);
        _this.retry = _this.endpoints.createFetcher(replayHistory_1.replayHistory);
        _this._getStats = _this.endpoints.createFetcher(resolvers_1.getStats);
        _this.getStats = function () { return _this._getStats({}); };
        _this.getStatsById = _this.endpoints.createFetcher(resolvers_1.getStatsById);
        _this.setSettings = _this.endpoints.createFetcher(resolvers_1.setSettings);
        _this._readSettings = _this.endpoints.createFetcher(resolvers_1.getSettings);
        _this.readSettings = function () { return _this._readSettings({}); };
        _this.verifySignature = function (options) { return (0, verifySignature_1.makeVerifySignature)(_this.core)(options); };
        _this.parsedLogs = function (webhookData) { return (0, logParser_1.parseLog)(webhookData); };
        return _this;
    }
    MoralisStreams.create = function (core) {
        return new MoralisStreams(core !== null && core !== void 0 ? core : core_1.MoralisCoreProvider.getDefault());
    };
    MoralisStreams.prototype.setup = function () {
        // Nothing
    };
    MoralisStreams.prototype.start = function () {
        // Nothing
    };
    MoralisStreams.moduleName = 'streams';
    return MoralisStreams;
}(core_1.ApiModule));
exports.MoralisStreams = MoralisStreams;
//# sourceMappingURL=MoralisStreams.js.map

/***/ }),

/***/ 4354:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var MoralisStreams_1 = __webpack_require__(5779);
__exportStar(__webpack_require__(5779), exports);
// Export SDK types
__exportStar(__webpack_require__(2870), exports);
__exportStar(__webpack_require__(7237), exports);
__exportStar(__webpack_require__(4995), exports);
__exportStar(__webpack_require__(7215), exports);
__exportStar(__webpack_require__(7863), exports);
exports["default"] = MoralisStreams_1.MoralisStreams;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2879:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CollectionNameBuilder = void 0;
var CollectionNameBuilder = /** @class */ (function () {
    function CollectionNameBuilder() {
        this.cache = {};
        this.cacheLimit = 256;
    }
    CollectionNameBuilder.prototype.build = function (tag) {
        var result = this.cache[tag];
        if (!result) {
            result = this.process(tag);
            if (this.cacheLimit > 0) {
                // Simple anti DDOS protection.
                this.cache[tag] = result;
                this.cacheLimit--;
            }
        }
        return result;
    };
    CollectionNameBuilder.prototype.process = function (tag) {
        var parts = tag
            .split(/[^a-zA-Z0-9_]/)
            .filter(function (p) { return !!p; })
            .map(function (p) {
            return p.substring(0, 1).toUpperCase() + p.substring(1).toLowerCase();
        });
        if (parts.length < 1) {
            throw new Error("Cannot build table name from value \"".concat(tag, "\""));
        }
        return parts.join('');
    };
    return CollectionNameBuilder;
}());
exports.CollectionNameBuilder = CollectionNameBuilder;
//# sourceMappingURL=CollectionNameBuilder.js.map

/***/ }),

/***/ 8863:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(2879), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7863:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(8863), exports);
__exportStar(__webpack_require__(1059), exports);
__exportStar(__webpack_require__(4997), exports);
__exportStar(__webpack_require__(328), exports);
__exportStar(__webpack_require__(9604), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6558:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InternalTxDocumentBuilder = void 0;
var InternalTxDocumentId_1 = __webpack_require__(6418);
var InternalTxDocumentBuilder = /** @class */ (function () {
    function InternalTxDocumentBuilder() {
    }
    InternalTxDocumentBuilder.build = function (tx, block, confirmed, chainId) {
        var chain = Number(chainId);
        return {
            id: InternalTxDocumentId_1.InternalTxDocumentId.create(chain, tx.transactionHash),
            hash: tx.transactionHash,
            chainId: chain,
            from: tx.from,
            to: tx.to,
            value: tx.value,
            gas: parseInt(tx.gas || '0', 10),
            blockHash: block.hash,
            blockTimestamp: parseInt(block.timestamp, 10),
            blockNumber: parseInt(block.number, 10),
            confirmed: confirmed,
        };
    };
    return InternalTxDocumentBuilder;
}());
exports.InternalTxDocumentBuilder = InternalTxDocumentBuilder;
//# sourceMappingURL=InternalTxDocumentBuilder.js.map

/***/ }),

/***/ 6418:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InternalTxDocumentId = void 0;
var ethers_1 = __webpack_require__(1307);
var InternalTxDocumentId = /** @class */ (function () {
    function InternalTxDocumentId() {
    }
    InternalTxDocumentId.create = function (chainId, transactionHash) {
        var safeTransactionHash = transactionHash.toLowerCase();
        var rawId = ethers_1.ethers.utils.toUtf8Bytes("".concat(chainId, ";").concat(safeTransactionHash));
        return ethers_1.ethers.utils.sha256(rawId);
    };
    return InternalTxDocumentId;
}());
exports.InternalTxDocumentId = InternalTxDocumentId;
//# sourceMappingURL=InternalTxDocumentId.js.map

/***/ }),

/***/ 7903:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InternalTxsProcessor = void 0;
var InternalTxDocumentBuilder_1 = __webpack_require__(6558);
var InternalTxsProcessor = /** @class */ (function () {
    function InternalTxsProcessor(collectionNameBuilder) {
        this.collectionNameBuilder = collectionNameBuilder;
    }
    InternalTxsProcessor.prototype.process = function (batch) {
        var updates = [];
        for (var _i = 0, _a = batch.txsInternal; _i < _a.length; _i++) {
            var internalTx = _a[_i];
            var document = InternalTxDocumentBuilder_1.InternalTxDocumentBuilder.build(internalTx, batch.block, batch.confirmed, batch.chainId);
            updates.push({
                collectionName: this.collectionNameBuilder.build(batch.tag),
                document: document,
            });
        }
        return updates;
    };
    return InternalTxsProcessor;
}());
exports.InternalTxsProcessor = InternalTxsProcessor;
//# sourceMappingURL=InternalTxsProcessor.js.map

/***/ }),

/***/ 4997:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(7903), exports);
__exportStar(__webpack_require__(6558), exports);
__exportStar(__webpack_require__(6418), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 168:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LogDocumentBuilder = void 0;
var LogDocumentId_1 = __webpack_require__(3728);
var LogDocumentValueFormatter_1 = __webpack_require__(9129);
var ParamNameResolver_1 = __webpack_require__(4766);
var paramNames = [
    'id',
    'name',
    'logIndex',
    'transactionHash',
    'address',
    'blockHash',
    'blockTimestamp',
    'blockNumber',
    'confirmed',
    'chainId',
];
var restrictedParamNames = __spreadArray(__spreadArray([], paramNames, true), [
    // Some extra names
    '_id',
    'uniqueId',
    'updatedAt',
    'createdAt',
    'user',
    'userId',
], false);
var LogDocumentBuilder = /** @class */ (function () {
    function LogDocumentBuilder() {
    }
    LogDocumentBuilder.build = function (log, parsedLog, block, confirmed, chainId) {
        var nameResolver = new ParamNameResolver_1.ParamNameResolver(restrictedParamNames);
        var chain = Number(chainId);
        var document = {
            id: LogDocumentId_1.LogDocumentId.create(chain, log.transactionHash, log.logIndex),
            name: parsedLog.name,
            logIndex: parseInt(log.logIndex, 10),
            transactionHash: log.transactionHash,
            address: log.address,
            blockHash: block.hash,
            blockTimestamp: parseInt(block.timestamp, 10),
            blockNumber: parseInt(block.number, 10),
            confirmed: confirmed,
            chainId: chain,
        };
        nameResolver.iterate(parsedLog.params, function (safeParamName, paramValue) {
            document[safeParamName] = LogDocumentValueFormatter_1.LogDocumentValueFormatter.format(paramValue);
        });
        return document;
    };
    return LogDocumentBuilder;
}());
exports.LogDocumentBuilder = LogDocumentBuilder;
//# sourceMappingURL=LogDocumentBuilder.js.map

/***/ }),

/***/ 3728:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LogDocumentId = void 0;
var ethers_1 = __webpack_require__(1307);
var LogDocumentId = /** @class */ (function () {
    function LogDocumentId() {
    }
    LogDocumentId.create = function (chainId, transactionHash, logIndex) {
        var safeTransactionHash = transactionHash.toLowerCase();
        var rawId = ethers_1.ethers.utils.toUtf8Bytes("".concat(chainId, ";").concat(safeTransactionHash, ";").concat(logIndex));
        return ethers_1.ethers.utils.sha256(rawId);
    };
    return LogDocumentId;
}());
exports.LogDocumentId = LogDocumentId;
//# sourceMappingURL=LogDocumentId.js.map

/***/ }),

/***/ 9129:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LogDocumentValueFormatter = void 0;
var ethers_1 = __webpack_require__(1307);
var LogDocumentValueFormatter = /** @class */ (function () {
    function LogDocumentValueFormatter() {
    }
    LogDocumentValueFormatter.format = function (param) {
        switch (param.type) {
            case 'string':
                return param.value;
            case 'address':
                return param.value.toLowerCase();
            default:
                if (ethers_1.BigNumber.isBigNumber(param.value)) {
                    return param.value.toString();
                }
                return param.value.toString();
        }
    };
    return LogDocumentValueFormatter;
}());
exports.LogDocumentValueFormatter = LogDocumentValueFormatter;
//# sourceMappingURL=LogDocumentValueFormatter.js.map

/***/ }),

/***/ 1737:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LogParser = void 0;
var abi_1 = __webpack_require__(6845);
var LogParser = /** @class */ (function () {
    function LogParser(abiItems) {
        this.abiInterface = new abi_1.Interface(abiItems);
    }
    LogParser.prototype.read = function (log) {
        // Solidity supports max 3 topics. https://docs.soliditylang.org/en/latest/contracts.html#events
        var topics = [log.topic0, log.topic1, log.topic2, log.topic3].filter(function (t) { return t !== null; });
        var result = this.abiInterface.parseLog({
            data: log.data,
            topics: topics,
        });
        var params = {};
        for (var _i = 0, _a = result.eventFragment.inputs; _i < _a.length; _i++) {
            var input = _a[_i];
            params[input.name] = {
                type: input.type,
                value: result.args[input.name],
            };
        }
        return {
            name: result.name,
            params: params,
        };
    };
    return LogParser;
}());
exports.LogParser = LogParser;
//# sourceMappingURL=LogParser.js.map

/***/ }),

/***/ 7773:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LogsProcessor = void 0;
var LogParser_1 = __webpack_require__(1737);
var LogDocumentBuilder_1 = __webpack_require__(168);
var LogsProcessor = /** @class */ (function () {
    function LogsProcessor(collectionNameBuilder) {
        this.collectionNameBuilder = collectionNameBuilder;
    }
    LogsProcessor.prototype.process = function (batch) {
        var updates = [];
        if (batch.abi.length < 1) {
            return updates;
        }
        var logParser = new LogParser_1.LogParser(batch.abi);
        for (var _i = 0, _a = batch.logs; _i < _a.length; _i++) {
            var log = _a[_i];
            var logParams = logParser.read(log);
            var document = LogDocumentBuilder_1.LogDocumentBuilder.build(log, logParams, batch.block, batch.confirmed, batch.chainId);
            updates.push({
                collectionName: this.collectionNameBuilder.build(batch.tag),
                document: document,
            });
        }
        return updates;
    };
    return LogsProcessor;
}());
exports.LogsProcessor = LogsProcessor;
//# sourceMappingURL=LogsProcessor.js.map

/***/ }),

/***/ 4766:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ParamNameResolver = void 0;
var ParamNameResolver = /** @class */ (function () {
    function ParamNameResolver(restrictedNames) {
        this.restrictedNames = restrictedNames;
        this.usedNames = [];
    }
    ParamNameResolver.prototype.iterate = function (object, callback) {
        var _this = this;
        // We need to always keep parameters in the same order
        // because the RowParamNameResolver is order-sensitive.
        var sortedNames = Object.keys(object).sort(function (a, b) { return a.localeCompare(b); });
        sortedNames.forEach(function (name) {
            var safeName = _this.resolve(name);
            callback(safeName, object[name]);
        });
    };
    ParamNameResolver.prototype.resolve = function (name) {
        if (this.isUsed(name)) {
            do {
                name = "_".concat(name);
            } while (this.isUsed(name));
        }
        this.usedNames.push(name);
        return name;
    };
    ParamNameResolver.prototype.isUsed = function (name) {
        return this.restrictedNames.includes(name) || this.usedNames.includes(name);
    };
    return ParamNameResolver;
}());
exports.ParamNameResolver = ParamNameResolver;
//# sourceMappingURL=ParamNameResolver.js.map

/***/ }),

/***/ 328:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(168), exports);
__exportStar(__webpack_require__(3728), exports);
__exportStar(__webpack_require__(9129), exports);
__exportStar(__webpack_require__(1737), exports);
__exportStar(__webpack_require__(7773), exports);
__exportStar(__webpack_require__(4766), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6678:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=Update.js.map

/***/ }),

/***/ 1059:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(6678), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 4682:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TxDocumentBuilder = void 0;
var TxDocumentId_1 = __webpack_require__(5767);
var TxDocumentBuilder = /** @class */ (function () {
    function TxDocumentBuilder() {
    }
    TxDocumentBuilder.build = function (tx, block, confirmed, chainId) {
        var chain = Number(chainId);
        return {
            id: TxDocumentId_1.TxDocumentId.create(chain, tx.hash),
            hash: tx.hash,
            chainId: chain,
            transactionIndex: parseInt(tx.transactionIndex, 10),
            gas: parseInt(tx.gas, 10),
            gasPrice: parseInt(tx.gasPrice, 10),
            nonce: parseInt(tx.nonce, 10),
            fromAddress: tx.fromAddress,
            toAddress: tx.toAddress,
            value: tx.value || '0',
            input: tx.input,
            type: parseInt(tx.type, 10),
            receiptStatus: parseInt(tx.receiptStatus, 10),
            receiptGasUsed: parseInt(tx.receiptGasUsed, 10),
            receiptCumulativeGasUsed: parseInt(tx.receiptCumulativeGasUsed, 10),
            blockHash: block.hash,
            blockTimestamp: parseInt(block.timestamp, 10),
            blockNumber: parseInt(block.number, 10),
            confirmed: confirmed,
        };
    };
    return TxDocumentBuilder;
}());
exports.TxDocumentBuilder = TxDocumentBuilder;
//# sourceMappingURL=TxDocumentBuilder.js.map

/***/ }),

/***/ 5767:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TxDocumentId = void 0;
var ethers_1 = __webpack_require__(1307);
var TxDocumentId = /** @class */ (function () {
    function TxDocumentId() {
    }
    TxDocumentId.create = function (chainId, transactionHash) {
        var safeTransactionHash = transactionHash.toLowerCase();
        var rawId = ethers_1.ethers.utils.toUtf8Bytes("".concat(chainId, ";").concat(safeTransactionHash));
        return ethers_1.ethers.utils.sha256(rawId);
    };
    return TxDocumentId;
}());
exports.TxDocumentId = TxDocumentId;
//# sourceMappingURL=TxDocumentId.js.map

/***/ }),

/***/ 1985:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TxsProcessor = void 0;
var TxDocumentBuilder_1 = __webpack_require__(4682);
var TxsProcessor = /** @class */ (function () {
    function TxsProcessor(collectionNameBuilder) {
        this.collectionNameBuilder = collectionNameBuilder;
    }
    TxsProcessor.prototype.process = function (batch) {
        var updates = [];
        for (var _i = 0, _a = batch.txs; _i < _a.length; _i++) {
            var tx = _a[_i];
            var document = TxDocumentBuilder_1.TxDocumentBuilder.build(tx, batch.block, batch.confirmed, batch.chainId);
            updates.push({
                collectionName: this.collectionNameBuilder.build(batch.tag),
                document: document,
            });
        }
        return updates;
    };
    return TxsProcessor;
}());
exports.TxsProcessor = TxsProcessor;
//# sourceMappingURL=TxsProcessor.js.map

/***/ }),

/***/ 9604:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(4682), exports);
__exportStar(__webpack_require__(5767), exports);
__exportStar(__webpack_require__(1985), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 8808:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeAddAddress = void 0;
var resolvers_1 = __webpack_require__(3252);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var makeAddAddress = function (endpoints) {
    var evmFetcher = endpoints.createFetcher(resolvers_1.addAddressEvm);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeAddAddress = makeAddAddress;
//# sourceMappingURL=addAddress.js.map

/***/ }),

/***/ 1:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeCreateStream = void 0;
var resolvers_1 = __webpack_require__(3252);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var StreamNetwork_1 = __webpack_require__(440);
var makeCreateStream = function (endpoints) {
    var evmFetcher = endpoints.createFetcher(resolvers_1.createStreamEvm);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeCreateStream = makeCreateStream;
//# sourceMappingURL=create.js.map

/***/ }),

/***/ 5287:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeDeleteStream = void 0;
var resolvers_1 = __webpack_require__(3252);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var makeDeleteStream = function (endpoints) {
    var evmFetcher = endpoints.createFetcher(resolvers_1.deleteStreamEvm);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeDeleteStream = makeDeleteStream;
//# sourceMappingURL=delete.js.map

/***/ }),

/***/ 553:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeDeleteAddress = void 0;
var deleteAddressEvm_1 = __webpack_require__(1674);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var makeDeleteAddress = function (endpoints) {
    var evmFetcher = endpoints.createFetcher(deleteAddressEvm_1.deleteAddressEvm);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeDeleteAddress = makeDeleteAddress;
//# sourceMappingURL=deleteAddress.js.map

/***/ }),

/***/ 8235:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeGetAddresses = void 0;
var getAddressesEvm_1 = __webpack_require__(9205);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var makeGetAddresses = function (endpoints) {
    var evmFetcher = endpoints.createPaginatedFetcher(getAddressesEvm_1.getAddressesEvm);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeGetAddresses = makeGetAddresses;
//# sourceMappingURL=getAddresses.js.map

/***/ }),

/***/ 9063:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeGetStreams = void 0;
var resolvers_1 = __webpack_require__(3252);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var makeGetStreams = function (endpoints) {
    var evmFetcher = endpoints.createPaginatedFetcher(resolvers_1.getStreamsEvm);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeGetStreams = makeGetStreams;
//# sourceMappingURL=getAll.js.map

/***/ }),

/***/ 2013:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeGetStreamById = void 0;
var resolvers_1 = __webpack_require__(3252);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var makeGetStreamById = function (endpoints) {
    var evmFetcher = endpoints.createFetcher(resolvers_1.getStreamEvm);
    return function (_a) {
        var network = _a.network, options = __rest(_a, ["network"]);
        switch (network) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                throw new IncorrectNetworkError_1.IncorrectNetworkError(network);
        }
    };
};
exports.makeGetStreamById = makeGetStreamById;
//# sourceMappingURL=getById.js.map

/***/ }),

/***/ 6292:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.parseLog = void 0;
var core_1 = __webpack_require__(4243);
var logDecoderUtils_1 = __webpack_require__(7717);
var mapping_1 = __webpack_require__(7863);
var parseLog = function (webhookData) {
    if (!(0, logDecoderUtils_1.isWebhook)(webhookData)) {
        throw new core_1.MoralisStreamError({
            code: core_1.StreamErrorCode.GENERIC_STREAM_ERROR,
            message: 'Cannot decode the logs. No logs found in the webhook, or invalid webhook provided.',
        });
    }
    if (!(0, logDecoderUtils_1.hasAbis)(webhookData)) {
        throw new core_1.MoralisStreamError({
            code: core_1.StreamErrorCode.GENERIC_STREAM_ERROR,
            message: 'Cannot decode the logs. No abis found in the provided webhook.',
        });
    }
    var logs = webhookData.logs, abi = webhookData.abi;
    var decodedLogs = [];
    logs.forEach(function (currentLog) {
        var params = new mapping_1.LogParser(abi).read(currentLog).params;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        var decodedLog = {};
        for (var key in params) {
            if (Object.prototype.hasOwnProperty.call(params, key)) {
                var element = params[key];
                decodedLog[key] = element.value;
            }
        }
        decodedLogs.push(decodedLog);
    });
    return decodedLogs;
};
exports.parseLog = parseLog;
//# sourceMappingURL=logParser.js.map

/***/ }),

/***/ 2870:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 5430:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeUpdateStream = void 0;
var resolvers_1 = __webpack_require__(3252);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var makeUpdateStream = function (endpoints) {
    var evmFetcher = endpoints.createFetcher(resolvers_1.updateStreamEvm);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeUpdateStream = makeUpdateStream;
//# sourceMappingURL=update.js.map

/***/ }),

/***/ 4239:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeUpdateStreamStatus = void 0;
var updateStreamEvmStatus_1 = __webpack_require__(663);
var IncorrectNetworkError_1 = __webpack_require__(5106);
var StreamNetwork_1 = __webpack_require__(440);
var makeUpdateStreamStatus = function (endpoints) {
    var evmFetcher = endpoints.createFetcher(updateStreamEvmStatus_1.updateStreamEvmStatus);
    return function (_a) {
        var networkType = _a.networkType, options = __rest(_a, ["networkType"]);
        switch (networkType) {
            case StreamNetwork_1.StreamNetwork.EVM:
                return evmFetcher(__assign({}, options));
            default:
                if (networkType === undefined) {
                    return evmFetcher(__assign({}, options));
                }
                throw new IncorrectNetworkError_1.IncorrectNetworkError(networkType);
        }
    };
};
exports.makeUpdateStreamStatus = makeUpdateStreamStatus;
//# sourceMappingURL=updateStatus.js.map

/***/ }),

/***/ 243:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.makeVerifySignature = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var sha3_1 = __webpack_require__(9138);
var makeVerifySignature = function (core) {
    return function (_a) {
        var body = _a.body, signature = _a.signature;
        var apiKey = core.config.get(api_utils_1.ApiConfig.apiKey);
        if (!apiKey) {
            throw new core_1.MoralisStreamError({
                code: core_1.StreamErrorCode.GENERIC_STREAM_ERROR,
                message: 'unable to verify signature without an api key',
            });
        }
        var generatedSignature = (0, sha3_1.sha3)(JSON.stringify(body) + apiKey);
        if (signature !== generatedSignature) {
            throw new core_1.MoralisStreamError({
                code: core_1.StreamErrorCode.INVALID_SIGNATURE,
                message: 'signature is not valid',
            });
        }
        return true;
    };
};
exports.makeVerifySignature = makeVerifySignature;
//# sourceMappingURL=verifySignature.js.map

/***/ }),

/***/ 3594:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.addAddressEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var name = 'AddAddressToStream';
var method = 'post';
var bodyParams = ['address'];
exports.addAddressEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function (params) { return "/streams/evm/".concat(params.id, "/address"); },
        apiToResult: function (apiData) {
            var data = (0, core_1.toCamelCase)(apiData);
            return __assign(__assign({}, data), { address: data.address
                    ? typeof data.address === 'string'
                        ? evm_utils_1.EvmAddress.create(data.address)
                        : data.address.map(function (address) { return evm_utils_1.EvmAddress.create(address); })
                    : undefined });
        },
        resultToJson: function (data) { return (__assign(__assign({}, data), { address: data.address
                ? Array.isArray(data.address)
                    ? data.address.map(function (address) { return address.format(); })
                    : data.address.format()
                : undefined })); },
        parseParams: function (params) { return (__assign(__assign({}, params), { address: Array.isArray(params.address)
                ? params.address.map(function (address) { return evm_utils_1.EvmAddress.create(address).lowercase; })
                : evm_utils_1.EvmAddress.create(params.address).lowercase })); },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=addAddressEvm.js.map

/***/ }),

/***/ 6295:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createStreamEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var name = 'CreateStream';
var method = 'put';
var bodyParams = [
    'webhookUrl',
    'description',
    'tag',
    'topic0',
    'allAddresses',
    'includeNativeTxs',
    'includeContractLogs',
    'includeInternalTxs',
    'chainIds',
    'abi',
    'advancedOptions',
];
var apiToResult = function (apiData) {
    var data = (0, core_1.toCamelCase)(apiData);
    return __assign(__assign({}, data), { chains: data.chainIds.map(function (chainId) { return evm_utils_1.EvmChain.create(chainId); }) });
};
exports.createStreamEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function () { return "/streams/evm"; },
        apiToResult: apiToResult,
        resultToJson: function (data) { return (__assign(__assign({}, data), { chainIds: data.chains.map(function (chain) { return chain.format(); }) })); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chainIds: params.chains.map(function (chain) { return evm_utils_1.EvmChain.create(chain).apiHex; }) })); },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=createStreamEvm.js.map

/***/ }),

/***/ 1674:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deleteAddressEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var name = 'DeleteAddressFromStream';
var method = 'delete';
var bodyParams = ['address'];
var apiToResult = function (apiData) {
    var data = (0, core_1.toCamelCase)(apiData);
    return __assign(__assign({}, data), { address: data.address
            ? typeof data.address === 'string'
                ? evm_utils_1.EvmAddress.create(data.address)
                : data.address.map(function (address) { return evm_utils_1.EvmAddress.create(address); })
            : undefined });
};
exports.deleteAddressEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function (params) { return "/streams/evm/".concat(params.id, "/address"); },
        apiToResult: apiToResult,
        resultToJson: function (data) { return (__assign(__assign({}, data), { address: data.address
                ? Array.isArray(data.address)
                    ? data.address.map(function (address) { return address.format(); })
                    : data.address.format()
                : undefined })); },
        parseParams: function (params) { return (__assign(__assign({}, params), { address: Array.isArray(params.address)
                ? params.address.map(function (address) { return evm_utils_1.EvmAddress.create(address).lowercase; })
                : evm_utils_1.EvmAddress.create(params.address).lowercase })); },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=deleteAddressEvm.js.map

/***/ }),

/***/ 1114:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deleteStreamEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var name = 'DeleteStream';
var method = 'delete';
var apiToResult = function (apiData) {
    var data = (0, core_1.toCamelCase)(apiData);
    return __assign(__assign({}, data), { chains: data.chainIds.map(function (chainId) { return evm_utils_1.EvmChain.create(chainId); }) });
};
exports.deleteStreamEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function (params) { return "/streams/evm/".concat(params.id); },
        apiToResult: apiToResult,
        resultToJson: function (data) { return (__assign(__assign({}, data), { chainIds: data.chains.map(function (chain) { return chain.format(); }) })); },
        parseParams: function (params) { return params; },
        method: method,
    });
});
//# sourceMappingURL=deleteStreamEvm.js.map

/***/ }),

/***/ 9205:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getAddressesEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var name = 'GetAddresses';
var method = 'get';
exports.getAddressesEvm = (0, api_utils_1.createPaginatedEndpointFactory)(function () {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: name,
        getUrl: function (params) { return "/streams/evm/".concat(params.id, "/address"); },
        apiToResult: function (data) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (stream) { return (__assign(__assign({}, stream), { address: stream.address ? evm_utils_1.EvmAddress.create(stream.address) : undefined })); });
        },
        resultToJson: function (data) { return data.map(function (stream) { var _a; return (__assign(__assign({}, stream), { address: (_a = stream.address) === null || _a === void 0 ? void 0 : _a.format() })); }); },
        parseParams: function (params) { return params; },
        method: method,
    });
});
//# sourceMappingURL=getAddressesEvm.js.map

/***/ }),

/***/ 9831:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getStreamEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var name = 'GetStream';
exports.getStreamEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function () { return "/streams/evm"; },
        apiToResult: function (stream) { return (__assign(__assign({}, stream), { chains: stream.chainIds.map(function (chainId) { return evm_utils_1.EvmChain.create(chainId); }) })); },
        resultToJson: function (stream) { return (__assign(__assign({}, stream), { chainIds: stream.chains.map(function (chain) { return chain.format(); }) })); },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=getStreamEvm.js.map

/***/ }),

/***/ 9554:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getStreamsEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var evm_utils_1 = __webpack_require__(9977);
var name = 'GetStreams';
exports.getStreamsEvm = (0, api_utils_1.createPaginatedEndpointFactory)(function () {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: name,
        getUrl: function () { return "/streams/evm"; },
        apiToResult: function (data) {
            var _a;
            return ((_a = data.result) !== null && _a !== void 0 ? _a : []).map(function (stream) { return (__assign(__assign({}, stream), { chains: stream.chainIds.map(function (chainId) { return evm_utils_1.EvmChain.create(chainId); }) })); });
        },
        resultToJson: function (data) {
            return data.map(function (stream) { return (__assign(__assign({}, stream), { chainIds: stream.chains.map(function (chain) { return chain.format(); }) })); });
        },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=getStreamsEvm.js.map

/***/ }),

/***/ 5285:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(3594), exports);
__exportStar(__webpack_require__(6295), exports);
__exportStar(__webpack_require__(1114), exports);
__exportStar(__webpack_require__(9205), exports);
__exportStar(__webpack_require__(9554), exports);
__exportStar(__webpack_require__(9831), exports);
__exportStar(__webpack_require__(1674), exports);
__exportStar(__webpack_require__(7936), exports);
__exportStar(__webpack_require__(663), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 7237:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 7936:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.updateStreamEvm = void 0;
var api_utils_1 = __webpack_require__(3520);
var core_1 = __webpack_require__(4243);
var evm_utils_1 = __webpack_require__(9977);
var name = 'UpdateStream';
var method = 'post';
var bodyParams = [
    'webhookUrl',
    'description',
    'tag',
    'topic0',
    'allAddresses',
    'includeNativeTxs',
    'includeContractLogs',
    'includeInternalTxs',
    'abi',
    'chainIds',
    'advancedOptions',
];
var apiToResult = function (apiData) {
    var data = (0, core_1.toCamelCase)(apiData);
    return __assign(__assign({}, data), { chains: data.chainIds.map(function (chainId) { return evm_utils_1.EvmChain.create(chainId); }) });
};
exports.updateStreamEvm = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function (params) { return "/streams/evm/".concat(params.id); },
        apiToResult: apiToResult,
        resultToJson: function (data) { return (__assign(__assign({}, data), { chainIds: data.chains.map(function (chain) { return chain.format(); }) })); },
        parseParams: function (params) { return (__assign(__assign({}, params), { chainIds: params.chains.map(function (chain) { return evm_utils_1.EvmChain.create(chain).apiHex; }) })); },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=updateStreamEvm.js.map

/***/ }),

/***/ 663:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.updateStreamEvmStatus = void 0;
var api_utils_1 = __webpack_require__(3520);
var name = 'UpdateStreamStatus';
var method = 'post';
var bodyParams = ['status'];
exports.updateStreamEvmStatus = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function (_a) {
            var id = _a.id;
            return "/streams/evm/".concat(id, "/status");
        },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
        bodyParams: bodyParams,
        method: method,
    });
});
//# sourceMappingURL=updateStreamEvmStatus.js.map

/***/ }),

/***/ 753:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getHistory = void 0;
var api_utils_1 = __webpack_require__(3520);
var name = 'GetHistory';
exports.getHistory = (0, api_utils_1.createPaginatedEndpointFactory)(function () {
    return (0, api_utils_1.createPaginatedEndpoint)({
        name: name,
        getUrl: function () { return "/history"; },
        apiToResult: function (data) { return data.result; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=getHistory.js.map

/***/ }),

/***/ 2449:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.replayHistory = exports.getHistory = void 0;
var getHistory_1 = __webpack_require__(753);
Object.defineProperty(exports, "getHistory", ({ enumerable: true, get: function () { return getHistory_1.getHistory; } }));
var replayHistory_1 = __webpack_require__(2649);
Object.defineProperty(exports, "replayHistory", ({ enumerable: true, get: function () { return replayHistory_1.replayHistory; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2649:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.replayHistory = void 0;
var api_utils_1 = __webpack_require__(3520);
var name = 'ReplayHistory';
var urlParams = ['id', 'streamId'];
var method = 'post';
exports.replayHistory = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function (_a) {
            var streamId = _a.streamId, id = _a.id;
            return "/history/replay/".concat(streamId, "/").concat(id);
        },
        urlParams: urlParams,
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
        method: method,
    });
});
//# sourceMappingURL=replayHistory.js.map

/***/ }),

/***/ 4995:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 3252:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(5285), exports);
__exportStar(__webpack_require__(2449), exports);
__exportStar(__webpack_require__(5225), exports);
__exportStar(__webpack_require__(6088), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9716:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getSettings = void 0;
var api_utils_1 = __webpack_require__(3520);
var name = 'GetSettings';
exports.getSettings = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function () { return "/settings"; },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=getSettings.js.map

/***/ }),

/***/ 5225:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.setSettings = exports.getSettings = void 0;
var getSettings_1 = __webpack_require__(9716);
Object.defineProperty(exports, "getSettings", ({ enumerable: true, get: function () { return getSettings_1.getSettings; } }));
var setSettings_1 = __webpack_require__(9137);
Object.defineProperty(exports, "setSettings", ({ enumerable: true, get: function () { return setSettings_1.setSettings; } }));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 9137:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.setSettings = void 0;
var api_utils_1 = __webpack_require__(3520);
var name = 'SetSettings';
var method = 'post';
var bodyParams = ['region'];
exports.setSettings = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function () { return "/settings"; },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
        method: method,
        bodyParams: bodyParams,
    });
});
//# sourceMappingURL=setSettings.js.map

/***/ }),

/***/ 7215:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=types.js.map

/***/ }),

/***/ 1766:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getStats = void 0;
var api_utils_1 = __webpack_require__(3520);
var name = 'GetStats';
exports.getStats = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        getUrl: function () { return "/stats"; },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=getStats.js.map

/***/ }),

/***/ 5681:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getStatsById = void 0;
var api_utils_1 = __webpack_require__(3520);
var name = 'GetStatsByStreamId';
var urlParams = ['streamId'];
exports.getStatsById = (0, api_utils_1.createEndpointFactory)(function () {
    return (0, api_utils_1.createEndpoint)({
        name: name,
        urlParams: urlParams,
        getUrl: function (_a) {
            var streamId = _a.streamId;
            return "/stats/".concat(streamId);
        },
        apiToResult: function (data) { return data; },
        resultToJson: function (data) { return data; },
        parseParams: function (params) { return params; },
    });
});
//# sourceMappingURL=getStatsById.js.map

/***/ }),

/***/ 6088:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(1766), exports);
__exportStar(__webpack_require__(5681), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 5106:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.IncorrectNetworkError = void 0;
var core_1 = __webpack_require__(4243);
var StreamNetwork_1 = __webpack_require__(440);
var IncorrectNetworkError = /** @class */ (function (_super) {
    __extends(IncorrectNetworkError, _super);
    function IncorrectNetworkError(network) {
        return _super.call(this, {
            code: core_1.StreamErrorCode.INCORRECT_NETWORK,
            message: "Incorrect network provided. Got \"".concat(network, "\", Valid values are: ").concat(Object.values(StreamNetwork_1.StreamNetwork)
                .map(function (value) { return "\"".concat(value, "\""); })
                .join(', ')),
        }) || this;
    }
    return IncorrectNetworkError;
}(core_1.MoralisStreamError));
exports.IncorrectNetworkError = IncorrectNetworkError;
//# sourceMappingURL=IncorrectNetworkError.js.map

/***/ }),

/***/ 440:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.StreamNetwork = void 0;
var StreamNetwork;
(function (StreamNetwork) {
    StreamNetwork["EVM"] = "evm";
    StreamNetwork["SOLANA"] = "solana";
})(StreamNetwork = exports.StreamNetwork || (exports.StreamNetwork = {}));
//# sourceMappingURL=StreamNetwork.js.map

/***/ }),

/***/ 7717:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.isNotEmpty = exports.isWebhook = exports.hasAbis = void 0;
var hasAbis = function (webhookData) {
    if (!webhookData.abi || webhookData.abi.length < 1) {
        return false;
    }
    return true;
};
exports.hasAbis = hasAbis;
var isWebhook = function (webhookData) {
    if (typeof webhookData !== 'object' || webhookData === null || !('logs' in webhookData)) {
        return false;
    }
    return true;
};
exports.isWebhook = isWebhook;
var isNotEmpty = function (value) { return value !== null && value !== undefined; };
exports.isNotEmpty = isNotEmpty;
//# sourceMappingURL=logDecoderUtils.js.map

/***/ }),

/***/ 9138:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.sha3 = void 0;
var ethereumjs_util_1 = __webpack_require__(9042);
var SHA3_NULL_S = '0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470';
var isHexStrict = function (hex) {
    return /^(-)?0x[0-9a-f]*$/i.test(hex);
};
var sha3 = function (value) {
    var bufferValue;
    if (isHexStrict(value) && /^0x/i.test(value.toString())) {
        bufferValue = (0, ethereumjs_util_1.toBuffer)(value);
    }
    else {
        // Assume value is an arbitrary string
        bufferValue = Buffer.from(value, 'utf-8');
    }
    var returnValue = (0, ethereumjs_util_1.bufferToHex)((0, ethereumjs_util_1.keccak256)(bufferValue));
    if (returnValue === SHA3_NULL_S) {
        return null;
    }
    return returnValue;
};
exports.sha3 = sha3;
//# sourceMappingURL=sha3.js.map

/***/ })

};
;