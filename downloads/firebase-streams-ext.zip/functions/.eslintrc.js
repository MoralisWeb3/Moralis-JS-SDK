module.exports = {
  extends: ['@moralisweb3'],
  ignorePatterns: ['**/lib/**/*', '**/scripts/**/*'],
};
