# Webpack App Demo

This project contains a simple webpack app.

## 🚀 How to Start

1. Build the app: `yarn build`
2. Start the HTTP server: `yarn serve`
3. Open `http://localhost:7777/public/` in your browser.
