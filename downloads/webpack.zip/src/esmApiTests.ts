import Moralis from 'moralis';
import { mount } from './apiTests';

mount(Moralis);
