module.exports = {
  extends: ['@moralisweb3'],
  ignorePatterns: ['**/build/**/*'],
  env: {
    browser: true,
    jest: true,
  },
};
